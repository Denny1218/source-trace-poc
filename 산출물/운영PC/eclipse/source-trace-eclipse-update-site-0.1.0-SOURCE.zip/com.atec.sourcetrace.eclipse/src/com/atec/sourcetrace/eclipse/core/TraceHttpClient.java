package com.atec.sourcetrace.eclipse.core;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

/**
 * Plain HTTP client for Backend v2.6 — no Eclipse API dependency.
 */
public final class TraceHttpClient {

	public static final class HttpResult {
		public final int status;
		public final String body;
		public final String error;

		public HttpResult(int status, String body, String error) {
			this.status = status;
			this.body = body;
			this.error = error;
		}

		public boolean ok() {
			return error == null && status >= 200 && status < 300;
		}
	}

	public static final class EquipmentItem {
		public final int id;
		public final String name;

		public EquipmentItem(int id, String name) {
			this.id = id;
			this.name = name;
		}

		@Override
		public String toString() {
			return name + " (ID " + id + ")";
		}
	}

	public static final class RepoItem {
		public final int id;
		public final String name;
		public final String status;

		public RepoItem(int id, String name, String status) {
			this.id = id;
			this.name = name;
			this.status = status;
		}

		@Override
		public String toString() {
			return name + " (#" + id + ")" + (status != null ? " [" + status + "]" : "");
		}
	}

	private final HttpClient client;
	private final Duration timeout;

	public TraceHttpClient(Duration timeout) {
		this.timeout = timeout == null ? Duration.ofSeconds(180) : timeout;
		this.client = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(10)).build();
	}

	public TraceHttpClient() {
		this(Duration.ofSeconds(180));
	}

	public HttpResult get(String url) {
		try {
			HttpRequest req = HttpRequest.newBuilder(URI.create(url))
					.timeout(timeout)
					.header("Accept", "application/json")
					.GET()
					.build();
			HttpResponse<String> res = client.send(req, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
			return new HttpResult(res.statusCode(), res.body(), null);
		} catch (Exception e) {
			return new HttpResult(-1, null, e.getMessage() == null ? e.toString() : e.getMessage());
		}
	}

	public HttpResult postJson(String url, String jsonBody) {
		try {
			HttpRequest req = HttpRequest.newBuilder(URI.create(url))
					.timeout(timeout)
					.header("Content-Type", "application/json; charset=utf-8")
					.header("Accept", "application/json")
					.POST(HttpRequest.BodyPublishers.ofString(jsonBody == null ? "{}" : jsonBody, StandardCharsets.UTF_8))
					.build();
			HttpResponse<String> res = client.send(req, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
			return new HttpResult(res.statusCode(), res.body(), null);
		} catch (Exception e) {
			return new HttpResult(-1, null, e.getMessage() == null ? e.toString() : e.getMessage());
		}
	}

	public HttpResult health(String serverUrl) {
		return get(ServerUrlUtil.buildApiUrl(serverUrl, ApiPaths.HEALTH));
	}

	public List<EquipmentItem> listEquipment(String serverUrl) throws Exception {
		HttpResult r = get(ServerUrlUtil.buildApiUrl(serverUrl, ApiPaths.EQUIPMENT_LIST));
		if (!r.ok()) {
			throw new Exception(formatHttpError("장비 목록 조회", r));
		}
		List<EquipmentItem> out = new ArrayList<>();
		for (String obj : JsonUtil.getObjectArrayItems(r.body, null)) {
			Integer id = JsonUtil.getIntField(obj, "id");
			String name = JsonUtil.getStringField(obj, "name");
			if (id != null) {
				out.add(new EquipmentItem(id.intValue(), name == null ? "" : name));
			}
		}
		return out;
	}

	public List<RepoItem> listRepositories(String serverUrl, int equipmentId) throws Exception {
		HttpResult r = get(ServerUrlUtil.buildApiUrl(serverUrl, ApiPaths.equipmentRepositories(equipmentId)));
		if (!r.ok()) {
			throw new Exception(formatHttpError("Repository 목록 조회", r));
		}
		List<RepoItem> out = new ArrayList<>();
		for (String obj : JsonUtil.getObjectArrayItems(r.body, null)) {
			Integer id = JsonUtil.getIntField(obj, "id");
			String name = JsonUtil.getStringField(obj, "name");
			String status = JsonUtil.getStringField(obj, "status");
			if (id != null) {
				out.add(new RepoItem(id.intValue(), name == null ? "" : name, status));
			}
		}
		return out;
	}

	public HttpResult postReport(String serverUrl, String jsonBody) {
		return postJson(ServerUrlUtil.buildApiUrl(serverUrl, ApiPaths.TRACE_REPORT), jsonBody);
	}

	public HttpResult postSelection(String serverUrl, String jsonBody) {
		return postJson(ServerUrlUtil.buildApiUrl(serverUrl, ApiPaths.TRACE_SELECTION), jsonBody);
	}

	public static String formatHttpError(String action, HttpResult r) {
		if (r.error != null) {
			return action + " 실패: 서버에 연결할 수 없습니다. (" + r.error + ")";
		}
		String detail = r.body == null ? "" : r.body;
		String msg = JsonUtil.getStringField(detail, "detail");
		if (msg == null || msg.isEmpty()) {
			msg = JsonUtil.getStringField(detail, "content");
		}
		if (msg == null || msg.isEmpty()) {
			msg = detail.length() > 300 ? detail.substring(0, 300) : detail;
		}
		return action + " 실패 (HTTP " + r.status + "): " + msg;
	}

	public static String userFacingConnectionError(String detail) {
		return "Backend 서버에 연결할 수 없습니다. Source Trace 서버 URL 설정을 확인하세요."
				+ (detail != null && !detail.isEmpty() ? "\n원인: " + detail : "");
	}
}
