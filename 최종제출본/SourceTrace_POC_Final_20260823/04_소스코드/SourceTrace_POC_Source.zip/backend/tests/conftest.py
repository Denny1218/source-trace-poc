import subprocess
import sys
from pathlib import Path

import pytest

from app.db.database import init_database


@pytest.fixture(autouse=True)
def yona_default_username(monkeypatch):
    """Tests that touch remote Git validation expect a configured default account."""
    monkeypatch.setattr("app.core.config.YONA_DEFAULT_USERNAME", "source_trace")


@pytest.fixture
def test_db(tmp_path, monkeypatch):
    db_path = tmp_path / "test.db"
    monkeypatch.setattr("app.db.database.DATABASE_PATH", str(db_path))
    init_database()
    yield db_path


@pytest.fixture
def client(test_db):
    from fastapi.testclient import TestClient
    from app.main import app

    return TestClient(app)


@pytest.fixture(scope="session")
def project_root():
    return Path(__file__).resolve().parents[2]


@pytest.fixture(scope="session")
def setup_repos(project_root):
    """문서 폴더 및 공유 테스트 데이터 최초 준비 (Git repo는 테스트별 격리)."""
    test_data = project_root / "tests" / "test-data"
    sys.path.insert(0, str(test_data))

    for device in ("device-a", "device-b"):
        docs = test_data / device / "documents"
        docs.mkdir(parents=True, exist_ok=True)
        if not (docs / "sample.pptx").exists():
            (docs / "sample.pptx").write_text("placeholder", encoding="utf-8")

    repo_a = test_data / "device-a" / "repository"
    repo_b = test_data / "device-b" / "repository"
    if not (repo_a / ".git").exists() or not (repo_b / ".git").exists():
        from setup_repositories import setup_device_a, setup_device_b

        try:
            if not (repo_a / ".git").exists():
                setup_device_a(repo_a)
            if not (repo_b / ".git").exists():
                setup_device_b(repo_b)
        except (PermissionError, subprocess.CalledProcessError):
            pass


def _load_setup_module():
    test_data = Path(__file__).resolve().parents[2] / "tests" / "test-data"
    sys.path.insert(0, str(test_data))
    import setup_repositories

    return setup_repositories


@pytest.fixture
def isolated_device_a_repo(tmp_path):
    setup = _load_setup_module()
    repo = tmp_path / "device-a-repo"
    setup._apply_commits(repo, setup._device_a_commits)
    return repo


@pytest.fixture
def isolated_device_b_repo(tmp_path):
    setup = _load_setup_module()
    repo = tmp_path / "device-b-repo"
    setup._apply_commits(repo, setup._device_b_commits)
    return repo


@pytest.fixture(scope="session")
def ppt_fixtures_ready(project_root):
    test_data = project_root / "tests" / "test-data"
    sys.path.insert(0, str(test_data))
    from setup_ppt_fixtures import setup_all_fixtures

    setup_all_fixtures(test_data / "ppt-fixtures")


@pytest.fixture
def ppt_documents_ready(project_root, ppt_fixtures_ready):
    test_data = project_root / "tests" / "test-data"
    sys.path.insert(0, str(test_data))
    from setup_ppt_documents import setup_device_a_documents, setup_device_b_documents

    setup_device_a_documents(test_data / "device-a" / "documents")
    setup_device_b_documents(test_data / "device-b" / "documents")


def local_path_to_test_unc(local_path: str | Path) -> str:
    """Map a local test folder to UNC localhost admin share (Windows tests)."""
    import sys

    path = Path(local_path).resolve()
    if sys.platform != "win32":
        return str(path)
    drive = path.drive.rstrip(":").lower()
    suffix = str(path)[len(path.drive) + 1 :]
    return f"\\\\localhost\\{drive}$\\{suffix}"


@pytest.fixture
def device_a_paths(project_root, setup_repos, ppt_documents_ready):
    base = project_root / "tests" / "test-data" / "device-a"
    docs = base / "documents"
    return {
        "name": "TEST_DEVICE_A",
        "git_path": str(base / "repository"),
        "document_path": local_path_to_test_unc(docs),
        "document_path_local": str(docs),
    }


@pytest.fixture
def device_b_paths(project_root, setup_repos, ppt_documents_ready):
    base = project_root / "tests" / "test-data" / "device-b"
    docs = base / "documents"
    return {
        "name": "TEST_DEVICE_B",
        "git_path": str(base / "repository"),
        "document_path": local_path_to_test_unc(docs),
        "document_path_local": str(docs),
    }


@pytest.fixture
def isolated_device_a_paths(isolated_device_a_repo, project_root, setup_repos):
    docs = project_root / "tests" / "test-data" / "device-a" / "documents"
    return {
        "name": "TEST_DEVICE_A",
        "git_path": str(isolated_device_a_repo),
        "document_path": local_path_to_test_unc(docs),
        "document_path_local": str(docs),
    }


@pytest.fixture
def isolated_device_b_paths(isolated_device_b_repo, project_root, setup_repos):
    docs = project_root / "tests" / "test-data" / "device-b" / "documents"
    return {
        "name": "TEST_DEVICE_B",
        "git_path": str(isolated_device_b_repo),
        "document_path": local_path_to_test_unc(docs),
        "document_path_local": str(docs),
    }


def register_equipment(client, paths: dict) -> dict:
    payload = {
        "name": paths["name"],
        "document_path": paths["document_path"],
    }
    response = client.post("/api/equipment", json=payload)
    assert response.status_code == 201, response.text
    return response.json()


def register_local_repository(
    client, equipment_id: int, name: str, local_path: str
) -> dict:
    response = client.post(
        f"/api/equipment/{equipment_id}/repositories",
        json={
            "name": name,
            "source_type": "local",
            "local_path": local_path,
        },
    )
    assert response.status_code == 201, response.text
    return response.json()


def equipment_payload(paths: dict) -> dict:
    return {
        "name": paths["name"],
        "document_path": paths["document_path"],
    }


def register_equipment_with_repo(client, paths: dict, repo_name: str = "test_repo") -> dict:
    equipment = register_equipment(client, paths)
    register_local_repository(client, equipment["id"], repo_name, paths["git_path"])
    return equipment


def count_commits_for_equipment(conn, equipment_id: int) -> int:
    return conn.execute(
        """
        SELECT COUNT(*) AS cnt
        FROM git_commit gc
        JOIN git_repository gr ON gr.id = gc.repository_id
        WHERE gr.equipment_id = ?
        """,
        (equipment_id,),
    ).fetchone()["cnt"]


@pytest.fixture
def registered_device_a(client, isolated_device_a_paths):
    equipment = register_equipment(client, isolated_device_a_paths)
    register_local_repository(
        client,
        equipment["id"],
        "test_repo",
        isolated_device_a_paths["git_path"],
    )
    return equipment


@pytest.fixture
def synced_device_a(client, registered_device_a):
    equipment_id = registered_device_a["id"]
    response = client.post(f"/api/equipment/{equipment_id}/sync/git")
    assert response.status_code == 200, response.text
    return registered_device_a
