# sample_trace_function 변경 이력

## 한눈에 보기

| 항목 | 결과 |
|---|---|
| 최초 확인 | 2020-02-26 · `aaaaaaaa` |
| 이후 Git 이력 | 0건 |
| 관련 문서 | 1건 |
| 조회 파일 | `src/a.c` |

## 변경 이력

| 날짜 | Commit | 변경 내용 |
|---|---|---|
| 2020-02-26 | `aaaaaaaa` | 함수 최초 확인 |

## 변경 상세

<details>
<summary>2020-02-26 · <code>aaaaaaaa</code> · 함수 최초 확인</summary>

- Commit 메시지: `add fn`
- 코드에서 확인:
  - 함수 원형과 구현이 새로 추가되었습니다.

</details>


## 관련 문서

**샘플 적용**

| 항목 | 내용 |
|---|---|
| 문서 | `프로그램변경내역서_sample.pptx` |
| Slide | 2 |

**주요 변경 내용**

- 변경


## 전체 참조 근거

<details>
<summary>Git Commit 및 변경내역서 전체 보기</summary>

### Git Commit

- `aaaaaaaa`

### 변경내역서

- `프로그램변경내역서_sample.pptx`, Slide 2

</details>


---
조회: 2026-08-26 15:36
