"""STEP 8: `POST /api/trace/analyze` integration tests (synthetic only).

Reuses the same synthetic device-a Git fixture as `test_evidence_api.py`.
Ollama is never called over the network — `ollama_service._call_ollama_raw`
is monkeypatched.
"""

from __future__ import annotations

import json
from pathlib import Path

from app.services import ollama_service


def _insert_document(equipment_id: int, file_path: str, file_name: str) -> int:
    from app.db.database import get_connection

    conn = get_connection()
    try:
        cursor = conn.execute(
            """
            INSERT INTO document_cache
                (equipment_id, file_path, file_name, file_hash, modified_at, parsed_at, slide_count)
            VALUES (?, ?, ?, 'hash', datetime('now'), datetime('now'), 1)
            """,
            (equipment_id, file_path, file_name),
        )
        conn.commit()
        return int(cursor.lastrowid)
    finally:
        conn.close()


def _insert_change_item(
    document_cache_id: int,
    change_title: str | None = None,
    source_functions: list[dict] | None = None,
) -> int:
    from app.db.database import get_connection

    conn = get_connection()
    try:
        cursor = conn.execute(
            """
            INSERT INTO change_item_cache
                (document_cache_id, slide_no, item_no, change_title, csr_no,
                 business_background, current_status, as_is, to_be,
                 source_functions_json, test_cases_json, applicable_scopes_json,
                 raw_text, parser_version, created_at)
            VALUES (?, 1, '1', ?, NULL, NULL, NULL, NULL, NULL, ?, '[]', '[]', ?, 1, datetime('now'))
            """,
            (
                document_cache_id,
                change_title,
                json.dumps(source_functions or [], ensure_ascii=False),
                change_title or "",
            ),
        )
        conn.commit()
        return int(cursor.lastrowid)
    finally:
        conn.close()


def _seed_linked_change_item(equipment_id: int, docs_dir: Path) -> int:
    doc_id = _insert_document(
        equipment_id,
        str(docs_dir / "TEST_DEVICE_A_fare_change.pptx"),
        "TEST_DEVICE_A_fare_change.pptx",
    )
    return _insert_change_item(
        doc_id,
        change_title="CalcFare 요금 계산 정책 변경",
        source_functions=[{"file_path": "FareCalc.c", "functions": ["CalcFare"]}],
    )


def _fake_ollama_success(prompt: str) -> str:
    return (
        '{"summary": "CalcFare 요금 정책 변경", "reason": "요금 계산 정책 수정", '
        '"confidence": "high", "inference": false, "evidence": []}'
    )


def test_analyze_normal_grounded_answer(monkeypatch, client, synced_device_a, device_a_paths):
    monkeypatch.setattr(ollama_service, "_call_ollama_raw", _fake_ollama_success)

    eid = synced_device_a["id"]
    _seed_linked_change_item(eid, Path(device_a_paths["document_path_local"]))

    response = client.post(
        "/api/trace/analyze",
        json={"equipment_id": eid, "query": "CalcFare 함수가 왜 변경됐어?"},
    )
    assert response.status_code == 200
    data = response.json()

    assert data["ai_available"] is True
    assert data["summary"] == "CalcFare 요금 정책 변경"
    assert data["confidence"] == "high"
    assert len(data["evidence"]) >= 1
    assert any(e["type"] == "git" for e in data["evidence"])
    assert any(e["type"] == "document" for e in data["evidence"])
    # STEP 7 Evidence must still be present alongside the AI summary.
    assert len(data["git_candidates"]) >= 1
    assert len(data["evidence_links"]) >= 1
    assert "debug" in data


def test_analyze_no_evidence_skips_ollama(monkeypatch, client, registered_device_a):
    def _fail(prompt: str) -> str:
        raise AssertionError("Ollama must not be called with no evidence")

    monkeypatch.setattr(ollama_service, "_call_ollama_raw", _fail)

    eid = registered_device_a["id"]
    response = client.post(
        "/api/trace/analyze",
        json={"equipment_id": eid, "query": "CalcFare 함수가 왜 변경됐어?"},
    )
    assert response.status_code == 200
    data = response.json()
    assert data["ai_available"] is True
    assert data["evidence"] == []
    assert data["git_candidates"] == []


def test_analyze_ollama_unavailable_still_returns_evidence(
    monkeypatch, client, synced_device_a, device_a_paths
):
    def _raise(prompt: str) -> str:
        raise ollama_service.OllamaCallError("Ollama 서버에 연결할 수 없습니다.")

    monkeypatch.setattr(ollama_service, "_call_ollama_raw", _raise)

    eid = synced_device_a["id"]
    _seed_linked_change_item(eid, Path(device_a_paths["document_path_local"]))

    response = client.post(
        "/api/trace/analyze",
        json={"equipment_id": eid, "query": "CalcFare 함수가 왜 변경됐어?"},
    )
    # AI failure must never turn into a 500 — Evidence search stays available.
    assert response.status_code == 200
    data = response.json()
    assert data["ai_available"] is False
    assert data["ai_error"]
    assert len(data["git_candidates"]) >= 1
    assert len(data["evidence_links"]) >= 1


def test_analyze_malformed_json_response_returns_200(
    monkeypatch, client, synced_device_a, device_a_paths
):
    # Meaningful plain text (not a broken JSON blob) is accepted as the answer.
    monkeypatch.setattr(
        ollama_service,
        "_call_ollama_raw",
        lambda prompt: "CalcFare 요금 정책이 변경된 것으로 확인됩니다. (plain text)",
    )

    eid = synced_device_a["id"]
    _seed_linked_change_item(eid, Path(device_a_paths["document_path_local"]))

    response = client.post(
        "/api/trace/analyze",
        json={"equipment_id": eid, "query": "CalcFare 함수가 왜 변경됐어?"},
    )
    assert response.status_code == 200
    data = response.json()
    assert data["ai_available"] is True
    assert "CalcFare" in data["answer"] or "요금" in data["answer"]
    assert data["confidence"] in {"high", "medium", "low"}
    assert data["confidence"] != "unknown"
    assert len(data["evidence_links"]) >= 1
    assert len(data["evidence"]) >= 1


def test_analyze_empty_ollama_uses_fallback(monkeypatch, client, synced_device_a, device_a_paths):
    monkeypatch.setattr(ollama_service, "_call_ollama_raw", lambda prompt: "")

    eid = synced_device_a["id"]
    _seed_linked_change_item(eid, Path(device_a_paths["document_path_local"]))

    response = client.post(
        "/api/trace/analyze",
        json={"equipment_id": eid, "query": "CalcFare 함수가 왜 변경됐어?"},
    )
    assert response.status_code == 200
    data = response.json()
    assert data["parse_error"] is True
    assert data["answer_status"] in {"ollama_empty_response", "ollama_parse_error"}
    assert data["summary"]
    assert data["answer"]
    assert len(data["evidence_links"]) >= 1


def test_analyze_timeout_uses_fallback(monkeypatch, client, synced_device_a, device_a_paths):
    def _raise(prompt: str) -> str:
        raise ollama_service.OllamaCallError("timeout", kind="timeout")

    monkeypatch.setattr(ollama_service, "_call_ollama_raw", _raise)

    eid = synced_device_a["id"]
    _seed_linked_change_item(eid, Path(device_a_paths["document_path_local"]))

    response = client.post(
        "/api/trace/analyze",
        json={"equipment_id": eid, "query": "CalcFare 함수가 왜 변경됐어?"},
    )
    assert response.status_code == 200
    data = response.json()
    assert data["ai_available"] is False
    assert data["answer_status"] == "ollama_timeout"
    assert data["summary"]
    assert len(data["evidence_links"]) >= 1


def test_analyze_use_ollama_true_calls_ollama(
    monkeypatch, client, synced_device_a, device_a_paths
):
    called = {"value": False}

    def _fake_raw(prompt: str) -> str:
        called["value"] = True
        return _fake_ollama_success(prompt)

    monkeypatch.setattr(ollama_service, "_call_ollama_raw", _fake_raw)

    eid = synced_device_a["id"]
    _seed_linked_change_item(eid, Path(device_a_paths["document_path_local"]))

    response = client.post(
        "/api/trace/analyze",
        json={
            "equipment_id": eid,
            "query": "CalcFare 함수가 왜 변경됐어?",
            "use_ollama": True,
        },
    )
    assert response.status_code == 200
    data = response.json()
    assert called["value"] is True
    assert data["ai_used"] is True
    assert data["use_ollama"] is True
    assert data["ai_answer"]


def test_analyze_use_ollama_false_skips_ollama_call(
    monkeypatch, client, synced_device_a, device_a_paths
):
    def _fail(prompt: str) -> str:
        raise AssertionError("Ollama must not be called when use_ollama=false")

    monkeypatch.setattr(ollama_service, "_call_ollama_raw", _fail)

    eid = synced_device_a["id"]
    _seed_linked_change_item(eid, Path(device_a_paths["document_path_local"]))

    response = client.post(
        "/api/trace/analyze",
        json={
            "equipment_id": eid,
            "query": "CalcFare 함수가 왜 변경됐어?",
            "use_ollama": False,
        },
    )
    assert response.status_code == 200
    data = response.json()
    assert data["use_ollama"] is False
    assert data["ai_used"] is False
    assert data["ai_answer"] is None
    assert data["answer_status"] == "ollama_skipped_by_user"


def test_analyze_use_ollama_false_still_returns_server_evidence_summary(
    monkeypatch, client, synced_device_a, device_a_paths
):
    monkeypatch.setattr(
        ollama_service,
        "_call_ollama_raw",
        lambda prompt: (_ for _ in ()).throw(AssertionError("must not call Ollama")),
    )

    eid = synced_device_a["id"]
    _seed_linked_change_item(eid, Path(device_a_paths["document_path_local"]))

    response = client.post(
        "/api/trace/analyze",
        json={
            "equipment_id": eid,
            "query": "CalcFare 함수가 왜 변경됐어?",
            "use_ollama": False,
        },
    )
    assert response.status_code == 200
    data = response.json()
    assert data["evidence_summary"]
    assert data["evidence_answer"]
    assert data["confidence"] in {"high", "medium", "low"}
    assert len(data["evidence"]) >= 1
    assert len(data["git_candidates"]) >= 1
    assert len(data["evidence_links"]) >= 1


def test_analyze_no_evidence_use_ollama_false_stays_no_evidence(
    monkeypatch, client, registered_device_a
):
    def _fail(prompt: str) -> str:
        raise AssertionError("Ollama must not be called with no evidence")

    monkeypatch.setattr(ollama_service, "_call_ollama_raw", _fail)

    eid = registered_device_a["id"]
    response = client.post(
        "/api/trace/analyze",
        json={
            "equipment_id": eid,
            "query": "CalcFare 함수가 왜 변경됐어?",
            "use_ollama": False,
        },
    )
    assert response.status_code == 200
    data = response.json()
    assert data["answer_status"] == "no_evidence"
    assert data["ai_used"] is False


def test_analyze_use_ollama_true_failure_still_returns_server_evidence_summary(
    monkeypatch, client, synced_device_a, device_a_paths
):
    def _raise(prompt: str) -> str:
        raise ollama_service.OllamaCallError("timeout", kind="timeout")

    monkeypatch.setattr(ollama_service, "_call_ollama_raw", _raise)

    eid = synced_device_a["id"]
    _seed_linked_change_item(eid, Path(device_a_paths["document_path_local"]))

    response = client.post(
        "/api/trace/analyze",
        json={
            "equipment_id": eid,
            "query": "CalcFare 함수가 왜 변경됐어?",
            "use_ollama": True,
        },
    )
    assert response.status_code == 200
    data = response.json()
    assert data["ai_used"] is True
    assert data["ai_answer"] is None
    assert data["evidence_summary"]
    assert data["answer_status"] == "ollama_timeout"


def test_analyze_default_use_ollama_is_true(monkeypatch, client, synced_device_a, device_a_paths):
    """Omitting use_ollama in the request must default to true (AI 보조 설명 기본 ON)."""
    called = {"value": False}

    def _fake_raw(prompt: str) -> str:
        called["value"] = True
        return _fake_ollama_success(prompt)

    monkeypatch.setattr(ollama_service, "_call_ollama_raw", _fake_raw)

    eid = synced_device_a["id"]
    _seed_linked_change_item(eid, Path(device_a_paths["document_path_local"]))

    response = client.post(
        "/api/trace/analyze",
        json={"equipment_id": eid, "query": "CalcFare 함수가 왜 변경됐어?"},
    )
    assert response.status_code == 200
    data = response.json()
    assert called["value"] is True
    assert data["use_ollama"] is True


def test_analyze_invalid_equipment(client):
    response = client.post(
        "/api/trace/analyze",
        json={"equipment_id": 99999, "query": "test"},
    )
    assert response.status_code == 404


def test_analyze_empty_query_rejected(client, synced_device_a):
    eid = synced_device_a["id"]
    response = client.post(
        "/api/trace/analyze",
        json={"equipment_id": eid, "query": ""},
    )
    assert response.status_code == 422


def test_analyze_does_not_change_link_score_or_gate(
    monkeypatch, client, synced_device_a, device_a_paths
):
    """Evidence Link content from /analyze must match /evidence exactly."""
    monkeypatch.setattr(ollama_service, "_call_ollama_raw", _fake_ollama_success)

    eid = synced_device_a["id"]
    _seed_linked_change_item(eid, Path(device_a_paths["document_path_local"]))
    payload = {"equipment_id": eid, "query": "CalcFare 함수가 왜 변경됐어?"}

    evidence_resp = client.post("/api/trace/evidence", json=payload)
    analyze_resp = client.post("/api/trace/analyze", json=payload)

    assert evidence_resp.status_code == 200
    assert analyze_resp.status_code == 200
    evidence_links = evidence_resp.json()["evidence_links"]
    analyze_links = analyze_resp.json()["evidence_links"]
    assert len(evidence_links) == len(analyze_links)
    for a, b in zip(evidence_links, analyze_links):
        assert a["link_score"] == b["link_score"]
        assert a["final_rank_score"] == b["final_rank_score"]
