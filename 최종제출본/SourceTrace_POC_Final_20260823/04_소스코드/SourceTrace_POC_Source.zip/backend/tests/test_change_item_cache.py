"""STEP 6 change-item cache + candidate search integration tests."""

from __future__ import annotations

import pytest

from app.services.change_item_cache_service import (
    ensure_change_items_for_document,
    list_change_items_for_document,
    list_change_items_for_equipment,
    parse_and_store_change_items,
)
from app.services.change_item_candidate_service import (
    merge_change_item_candidates,
    search_change_item_candidates,
)
from app.db.database import get_connection
from app.services.ppt_cache_service import get_or_parse_document


@pytest.fixture(scope="session")
def fixtures_dir(project_root):
    return project_root / "tests" / "test-data" / "ppt-fixtures"


def _create_equipment(name: str = "CI_TEST_DEVICE") -> int:
    conn = get_connection()
    try:
        cursor = conn.execute(
            """
            INSERT INTO equipment (name, git_path, document_path, created_at, updated_at)
            VALUES (?, ?, ?, datetime('now'), datetime('now'))
            """,
            (name, "C:/tmp/ci-test-repo", "C:/tmp/ci-test-docs"),
        )
        conn.commit()
        return int(cursor.lastrowid)
    finally:
        conn.close()


def _seed_document(equipment_id: int, fixtures_dir):
    path = str(fixtures_dir / "change_item.pptx")
    cached, _hit, failed = get_or_parse_document(equipment_id, path)
    assert cached is not None and not failed
    return cached


def test_parse_and_store_then_list(test_db, ppt_fixtures_ready, fixtures_dir):
    eq_id = _create_equipment("CI_DEVICE_1")
    cached = _seed_document(eq_id, fixtures_dir=fixtures_dir)
    parse_and_store_change_items(cached.document, file_path=cached.document.file_path)

    rows = list_change_items_for_document(cached.document.id)
    assert len(rows) == 1
    assert rows[0].change_title == "동기화 타임아웃 조건 보정"
    assert rows[0].file_name == "change_item.pptx"


def test_lazy_ensure_is_idempotent(test_db, ppt_fixtures_ready, fixtures_dir):
    eq_id = _create_equipment("CI_DEVICE_2")
    cached = _seed_document(eq_id, fixtures_dir=fixtures_dir)
    first = ensure_change_items_for_document(
        cached.document.id, file_path=cached.document.file_path
    )
    second = ensure_change_items_for_document(
        cached.document.id, file_path=cached.document.file_path
    )
    assert len(first) == len(second) == 1
    # Same cache rows reused (no duplicate insert on second lazy pass).
    assert {r.id for r in first} == {r.id for r in second}


def test_keyword_search_matches_change_item(test_db, ppt_fixtures_ready, fixtures_dir):
    eq_id = _create_equipment("CI_DEVICE_3")
    cached = _seed_document(eq_id, fixtures_dir=fixtures_dir)
    parse_and_store_change_items(cached.document, file_path=cached.document.file_path)

    rows = list_change_items_for_equipment(eq_id)
    hits = search_change_item_candidates(rows, ["RetrySync"])
    assert len(hits) == 1
    assert "RetrySync" in hits[0].matched_keywords
    assert hits[0].candidate_score > 0


def test_keyword_search_no_match(test_db, ppt_fixtures_ready, fixtures_dir):
    eq_id = _create_equipment("CI_DEVICE_4")
    cached = _seed_document(eq_id, fixtures_dir=fixtures_dir)
    parse_and_store_change_items(cached.document, file_path=cached.document.file_path)

    rows = list_change_items_for_equipment(eq_id)
    hits = search_change_item_candidates(rows, ["존재하지않는키워드XYZ"])
    assert hits == []


def test_merge_dedupes_by_cache_id(test_db, ppt_fixtures_ready, fixtures_dir):
    eq_id = _create_equipment("CI_DEVICE_5")
    cached = _seed_document(eq_id, fixtures_dir=fixtures_dir)
    parse_and_store_change_items(cached.document, file_path=cached.document.file_path)

    rows = list_change_items_for_equipment(eq_id)
    a = search_change_item_candidates(rows, ["동기화"])
    b = search_change_item_candidates(rows, ["동기화"], from_cache_search=True)
    merged = merge_change_item_candidates(a, b)
    assert len(merged) == 1
