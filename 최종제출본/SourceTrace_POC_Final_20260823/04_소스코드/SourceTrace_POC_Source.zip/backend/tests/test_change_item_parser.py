"""STEP 6 change-item parser unit tests (synthetic fixtures only)."""

from __future__ import annotations

import pytest

from app.services.change_item_parser_service import (
    PARSER_VERSION,
    parse_change_items_from_file,
    parse_source_functions,
)


@pytest.fixture(scope="session")
def fixtures_dir(project_root):
    return project_root / "tests" / "test-data" / "ppt-fixtures"


def test_change_item_extracted_fields(ppt_fixtures_ready, fixtures_dir):
    items = parse_change_items_from_file(str(fixtures_dir / "change_item.pptx"))
    # Only the valid change-item slide is recognized; deployment + appendix excluded.
    assert len(items) == 1
    item = items[0]
    assert item.slide_no == 1
    assert item.item_no == "CHG-001"
    assert item.change_title == "동기화 타임아웃 조건 보정"
    assert item.csr_no == "CSR-2099-001"
    assert item.business_background is not None
    assert item.current_status == "타임아웃 5초 고정"
    assert "재시도 없이" in (item.as_is or "")
    assert "동적 계산" in (item.to_be or "")


def test_change_item_source_functions(ppt_fixtures_ready, fixtures_dir):
    items = parse_change_items_from_file(str(fixtures_dir / "change_item.pptx"))
    sources = items[0].source_functions
    assert len(sources) == 1
    assert sources[0].file_path == "SyncEngine.c"
    assert "CalcTimeout" in sources[0].functions
    assert "RetrySync" in sources[0].functions


def test_change_item_test_cases_and_scope(ppt_fixtures_ready, fixtures_dir):
    items = parse_change_items_from_file(str(fixtures_dir / "change_item.pptx"))
    item = items[0]
    assert "SYNC-TC-001" in item.test_cases
    assert "SYNC-TC-002" in item.test_cases
    assert "공통모듈" in item.applicable_scopes


def test_negative_and_plain_slides_excluded(ppt_fixtures_ready, fixtures_dir):
    items = parse_change_items_from_file(str(fixtures_dir / "change_item.pptx"))
    slide_numbers = {i.slide_no for i in items}
    assert 2 not in slide_numbers  # deployment plan
    assert 3 not in slide_numbers  # appendix text


def test_parser_version_positive():
    assert PARSER_VERSION >= 1


def test_parse_source_functions_path_dash_functions():
    entries = parse_source_functions("Foo.c - Alpha, Beta")
    assert len(entries) == 1
    assert entries[0].file_path == "Foo.c"
    assert entries[0].functions == ["Alpha", "Beta"]


def test_parse_source_functions_multiple_chunks():
    entries = parse_source_functions("A.c - f1\nB.cpp - f2")
    paths = {e.file_path for e in entries}
    assert paths == {"A.c", "B.cpp"}
