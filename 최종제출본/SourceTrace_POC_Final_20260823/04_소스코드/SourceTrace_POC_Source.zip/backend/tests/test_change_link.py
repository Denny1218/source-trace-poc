"""STEP 7: change_link cache persistence, reuse, and cascade-invalidation tests.

All Git/Change Item content below is synthetic (no real repository/PPT data)."""

from __future__ import annotations

import json

import pytest

from app.core.link_score_config import LINKER_VERSION
from app.db.database import get_connection
from app.schemas.trace import GitCandidate
from app.services.change_item_cache_service import ChangeItemCacheRow
from app.services.change_link_service import get_or_compute_change_link


def _insert_equipment(name: str = "CI_LINK_DEVICE") -> int:
    conn = get_connection()
    try:
        cursor = conn.execute(
            """
            INSERT INTO equipment (name, git_path, document_path, created_at, updated_at)
            VALUES (?, ?, ?, datetime('now'), datetime('now'))
            """,
            (name, "C:/tmp/ci-link-repo", "C:/tmp/ci-link-docs"),
        )
        conn.commit()
        return int(cursor.lastrowid)
    finally:
        conn.close()


def _insert_repository(equipment_id: int, name: str = "repo") -> int:
    conn = get_connection()
    try:
        cursor = conn.execute(
            """
            INSERT INTO git_repository
                (equipment_id, name, source_type, local_path, status, created_at, updated_at)
            VALUES (?, ?, 'local', 'C:/tmp/ci-link-repo', 'ready', datetime('now'), datetime('now'))
            """,
            (equipment_id, name),
        )
        conn.commit()
        return int(cursor.lastrowid)
    finally:
        conn.close()


def _insert_commit(
    repository_id: int,
    commit_hash: str = "abc1234",
    commit_date: str = "2025-06-15",
    message: str = "테스트 커밋",
) -> int:
    conn = get_connection()
    try:
        cursor = conn.execute(
            """
            INSERT INTO git_commit (repository_id, commit_hash, commit_date, author, message)
            VALUES (?, ?, ?, 'tester', ?)
            """,
            (repository_id, commit_hash, commit_date, message),
        )
        conn.commit()
        return int(cursor.lastrowid)
    finally:
        conn.close()


def _insert_change(commit_id: int, file_path: str, diff: str = "") -> int:
    conn = get_connection()
    try:
        cursor = conn.execute(
            """
            INSERT INTO git_change (commit_id, file_path, change_type, additions, deletions, diff)
            VALUES (?, ?, 'modified', 1, 0, ?)
            """,
            (commit_id, file_path, diff),
        )
        conn.commit()
        return int(cursor.lastrowid)
    finally:
        conn.close()


def _insert_document(equipment_id: int, file_path: str, file_name: str) -> int:
    conn = get_connection()
    try:
        cursor = conn.execute(
            """
            INSERT INTO document_cache
                (equipment_id, file_path, file_name, file_hash, modified_at, parsed_at, slide_count)
            VALUES (?, ?, ?, 'hash', datetime('now'), datetime('now'), 1)
            """,
            (equipment_id, file_path, file_name),
        )
        conn.commit()
        return int(cursor.lastrowid)
    finally:
        conn.close()


def _insert_change_item(
    document_cache_id: int,
    change_title: str | None = None,
    csr_no: str | None = None,
    source_functions: list[dict] | None = None,
) -> int:
    conn = get_connection()
    try:
        cursor = conn.execute(
            """
            INSERT INTO change_item_cache
                (document_cache_id, slide_no, item_no, change_title, csr_no,
                 business_background, current_status, as_is, to_be,
                 source_functions_json, test_cases_json, applicable_scopes_json,
                 raw_text, parser_version, created_at)
            VALUES (?, 1, '1', ?, ?, NULL, NULL, NULL, NULL, ?, '[]', '[]', '', 1, datetime('now'))
            """,
            (
                document_cache_id,
                change_title,
                csr_no,
                json.dumps(source_functions or [], ensure_ascii=False),
            ),
        )
        conn.commit()
        return int(cursor.lastrowid)
    finally:
        conn.close()


def _git_candidate(commit_id: int, file_path: str, message: str, commit_date: str) -> GitCandidate:
    return GitCandidate(
        repository_id=1,
        repository_name="repo",
        commit_id=commit_id,
        commit_hash="abc1234",
        commit_date=commit_date,
        message=message,
        file_path=file_path,
        score=0,
        match_reasons=[],
    )


def _change_item_row(change_item_cache_id: int, **kwargs) -> ChangeItemCacheRow:
    defaults = dict(
        id=change_item_cache_id,
        document_cache_id=1,
        slide_no=1,
        item_no="1",
        change_title=None,
        csr_no=None,
        business_background=None,
        current_status=None,
        as_is=None,
        to_be=None,
        source_functions_json="[]",
        test_cases_json="[]",
        applicable_scopes_json="[]",
        raw_text="",
        parser_version=1,
        created_at="2025-01-01T00:00:00+00:00",
        file_path="src/fare_calc.c",
        file_name="fare_calc.pptx",
    )
    defaults.update(kwargs)
    return ChangeItemCacheRow(**defaults)


@pytest.fixture
def link_fixture(test_db):
    equipment_id = _insert_equipment()
    repo_id = _insert_repository(equipment_id)
    commit_id = _insert_commit(repo_id, message="C20250101_001 요금 계산 반영")
    _insert_change(commit_id, "src/fare_calc.c", diff="+int calculate_fare(int x) {")
    document_id = _insert_document(equipment_id, "C:/docs/change.pptx", "change.pptx")
    change_item_id = _insert_change_item(
        document_id,
        change_title="요금 계산 정책 변경",
        csr_no="C20250101_001",
        source_functions=[{"file_path": "src/fare_calc.c", "functions": ["calculate_fare"]}],
    )
    return {
        "equipment_id": equipment_id,
        "commit_id": commit_id,
        "change_item_id": change_item_id,
    }


def test_compute_and_cache_row_created(link_fixture):
    conn = get_connection()
    try:
        before = conn.execute("SELECT COUNT(*) AS c FROM change_link").fetchone()["c"]
    finally:
        conn.close()
    assert before == 0

    git = _git_candidate(
        link_fixture["commit_id"], "src/fare_calc.c", "C20250101_001 요금 계산 반영", "2025-06-15"
    )
    row = _change_item_row(
        link_fixture["change_item_id"],
        change_title="요금 계산 정책 변경",
        csr_no="C20250101_001",
        source_functions_json=json.dumps(
            [{"file_path": "src/fare_calc.c", "functions": ["calculate_fare"]}]
        ),
    )
    result = get_or_compute_change_link(git, row)
    assert result.score > 0
    assert result.passes_gate is True

    conn = get_connection()
    try:
        after = conn.execute("SELECT COUNT(*) AS c FROM change_link").fetchone()["c"]
        stored = conn.execute(
            "SELECT link_score, linker_version FROM change_link"
        ).fetchone()
    finally:
        conn.close()
    assert after == 1
    assert stored["link_score"] == result.score
    assert stored["linker_version"] == LINKER_VERSION


def test_cache_reused_on_second_call(link_fixture):
    git = _git_candidate(
        link_fixture["commit_id"], "src/fare_calc.c", "C20250101_001 요금 계산 반영", "2025-06-15"
    )
    row = _change_item_row(
        link_fixture["change_item_id"],
        change_title="요금 계산 정책 변경",
        csr_no="C20250101_001",
        source_functions_json=json.dumps(
            [{"file_path": "src/fare_calc.c", "functions": ["calculate_fare"]}]
        ),
    )
    first = get_or_compute_change_link(git, row)
    second = get_or_compute_change_link(git, row)
    assert first.score == second.score
    assert [r.type for r in first.match_reasons] == [r.type for r in second.match_reasons]

    conn = get_connection()
    try:
        count = conn.execute("SELECT COUNT(*) AS c FROM change_link").fetchone()["c"]
    finally:
        conn.close()
    assert count == 1


def test_same_commit_different_file_path_no_collision(link_fixture):
    """A single commit touching 2 files must not let one file's score
    silently overwrite the other's cached row."""
    row = _change_item_row(link_fixture["change_item_id"])
    git_a = _git_candidate(link_fixture["commit_id"], "src/fare_calc.c", "msg", "2025-06-15")
    git_b = _git_candidate(link_fixture["commit_id"], "src/other_file.c", "msg", "2025-06-15")

    get_or_compute_change_link(git_a, row)
    get_or_compute_change_link(git_b, row)

    conn = get_connection()
    try:
        count = conn.execute("SELECT COUNT(*) AS c FROM change_link").fetchone()["c"]
    finally:
        conn.close()
    assert count == 2


def test_cascade_delete_on_git_commit_removal(link_fixture):
    git = _git_candidate(link_fixture["commit_id"], "src/fare_calc.c", "msg", "2025-06-15")
    row = _change_item_row(link_fixture["change_item_id"])
    get_or_compute_change_link(git, row)

    conn = get_connection()
    try:
        conn.execute("DELETE FROM git_commit WHERE id = ?", (link_fixture["commit_id"],))
        conn.commit()
        count = conn.execute("SELECT COUNT(*) AS c FROM change_link").fetchone()["c"]
    finally:
        conn.close()
    assert count == 0


def test_cascade_delete_on_change_item_removal(link_fixture):
    git = _git_candidate(link_fixture["commit_id"], "src/fare_calc.c", "msg", "2025-06-15")
    row = _change_item_row(link_fixture["change_item_id"])
    get_or_compute_change_link(git, row)

    conn = get_connection()
    try:
        conn.execute(
            "DELETE FROM change_item_cache WHERE id = ?", (link_fixture["change_item_id"],)
        )
        conn.commit()
        count = conn.execute("SELECT COUNT(*) AS c FROM change_link").fetchone()["c"]
    finally:
        conn.close()
    assert count == 0


def test_linker_version_lazy_rebuild_keeps_old_row(link_fixture):
    """A future weight/rule change bumps LINKER_VERSION; old rows are left in
    place (no forced migration) and a new row is lazily computed for the
    current version on next access."""
    conn = get_connection()
    try:
        conn.execute(
            """
            INSERT INTO change_link
                (git_commit_id, git_file_path, change_item_cache_id, link_score,
                 match_reasons_json, linker_version, created_at, updated_at)
            VALUES (?, ?, ?, 999, '[]', 'rule-v0', datetime('now'), datetime('now'))
            """,
            (link_fixture["commit_id"], "src/fare_calc.c", link_fixture["change_item_id"]),
        )
        conn.commit()
    finally:
        conn.close()

    git = _git_candidate(link_fixture["commit_id"], "src/fare_calc.c", "msg", "2025-06-15")
    row = _change_item_row(link_fixture["change_item_id"])
    result = get_or_compute_change_link(git, row)
    assert result.score != 999  # not the stale rule-v0 row

    conn = get_connection()
    try:
        rows = conn.execute(
            "SELECT linker_version, link_score FROM change_link ORDER BY linker_version"
        ).fetchall()
    finally:
        conn.close()
    versions = {r["linker_version"]: r["link_score"] for r in rows}
    assert versions["rule-v0"] == 999
    assert versions[LINKER_VERSION] == result.score
