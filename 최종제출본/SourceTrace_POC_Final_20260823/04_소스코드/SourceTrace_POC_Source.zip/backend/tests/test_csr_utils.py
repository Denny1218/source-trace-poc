"""STEP 7 CSR boundary-match utility tests (synthetic CSR values only)."""

from app.services.csr_utils import csr_appears_in_text


def test_csr_exact_plain():
    assert csr_appears_in_text("SR260529_42025", "SR260529_42025 반영") is True


def test_csr_case_insensitive():
    assert csr_appears_in_text("SR260529_42025", "sr260529_42025 반영") is True
    assert csr_appears_in_text("C20250101_001", "c20250101_001 반영") is True


def test_csr_brackets_around():
    assert csr_appears_in_text("SR260529_42025", "[SR260529_42025]") is True


def test_csr_colon_before():
    assert csr_appears_in_text("SR260529_42025", "CSR:SR260529_42025") is True


def test_csr_longer_suffix_false_positive_blocked():
    """SR260529_420251 must NOT match CSR SR260529_42025 (identifier suffix)."""
    assert csr_appears_in_text("SR260529_42025", "SR260529_420251 수정") is False


def test_csr_leading_identifier_false_positive_blocked():
    assert csr_appears_in_text("SR260529_42025", "XSR260529_42025") is False


def test_csr_different_value_no_match():
    assert csr_appears_in_text("SR260529_42025", "SR260529_99999 반영") is False


def test_csr_empty_or_none_no_match():
    assert csr_appears_in_text(None, "SR260529_42025") is False
    assert csr_appears_in_text("", "SR260529_42025") is False
    assert csr_appears_in_text("SR260529_42025", None) is False
    assert csr_appears_in_text("SR260529_42025", "") is False


def test_csr_underscore_boundary_preserved():
    """CSR containing underscores still matches when fully bounded."""
    assert csr_appears_in_text("C20250101_001", "반영 C20250101_001 완료") is True
    assert csr_appears_in_text("C20250101_001", "C20250101_0019") is False
