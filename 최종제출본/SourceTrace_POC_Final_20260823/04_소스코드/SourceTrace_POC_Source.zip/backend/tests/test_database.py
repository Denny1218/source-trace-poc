def test_database_init_and_check(tmp_path, monkeypatch):
    import app.db.database as db_module

    db_path = tmp_path / "test.db"
    monkeypatch.setattr(db_module, "DATABASE_PATH", str(db_path))

    db_module.init_database()
    assert db_module.check_database() == "ok"
    assert db_path.exists()
