# PROJECT_SPEC v2.5.1 — Diff evidence tiers / related list display
from __future__ import annotations

from app.services.function_git_lifecycle_service import (
    EVIDENCE_DIRECT_BODY,
    EVIDENCE_FUNCTION_CONTEXT,
    EVIDENCE_MESSAGE_ONLY,
    EVIDENCE_SYMBOL_ONLY,
    _parse_diff_stats,
    analyze_function_commit,
)
from app.services.lifecycle_markdown import (
    _entry_git_basis,
    _prioritize_for_display,
    _symbols_match_display,
)

FN = "fare_is_xfer"


def test_direct_body_allman_style():
    diff = "\n".join(
        [
            "@@ -10,8 +10,8 @@",
            f" bool {FN}(void)",
            " {",
            "-    if (elapsed > TEN_MIN)",
            "+    if (elapsed > FIFTEEN_MIN) /* 재승차 */",
            "         return TRUE;",
            " }",
        ]
    )
    stats = _parse_diff_stats(diff, FN)
    assert stats["evidence_tier"] == EVIDENCE_DIRECT_BODY
    assert stats["function_range_confirmed"] is True
    _ct, desc, _c, reason, is_core = analyze_function_commit(
        diff=diff,
        symbol=FN,
        message="재승차 시간 조정",
        parent_has_function=True,
        diff_available=True,
    )
    assert is_core is True
    assert reason.startswith("body_change") or reason.startswith("function_context")
    assert "Diff상" not in desc


def test_direct_body_knr_style():
    diff = "\n".join(
        [
            "@@ -1,6 +1,6 @@",
            f" int {FN}(a)",
            " int a;",
            " {",
            "-  return a < 10;",
            "+  return a < 15; /* 재승차 */",
            " }",
        ]
    )
    stats = _parse_diff_stats(diff, FN)
    assert stats["evidence_tier"] == EVIDENCE_DIRECT_BODY
    _ct, _d, _c, reason, is_core = analyze_function_commit(
        diff=diff,
        symbol=FN,
        message="knr",
        parent_has_function=True,
        diff_available=True,
    )
    assert is_core is True
    assert "body_change" in reason or "function_context" in reason


def test_multiline_signature_body_change():
    diff = "\n".join(
        [
            "@@ -1,10 +1,10 @@",
            f" bool {FN}(",
            "     int a,",
            "     int b)",
            " {",
            "-    return a;",
            "+    return b; /* 재승차 */",
            " }",
        ]
    )
    stats = _parse_diff_stats(diff, FN)
    assert stats["function_range_confirmed"] is True
    _ct, _d, _c, _reason, is_core = analyze_function_commit(
        diff=diff,
        symbol=FN,
        message="sig",
        parent_has_function=True,
        diff_available=True,
    )
    assert is_core is True


def test_function_context_from_hunk_header():
    diff = "\n".join(
        [
            f"@@ -120,4 +120,4 @@ bool {FN}(void)",
            "-    threshold = 10;",
            "+    threshold = 15; /* 재승차 */",
            "     return TRUE;",
        ]
    )
    stats = _parse_diff_stats(diff, FN)
    assert stats["hunk_header_scoped"] is True
    assert stats["evidence_tier"] in {
        EVIDENCE_FUNCTION_CONTEXT,
        EVIDENCE_DIRECT_BODY,
    }
    assert stats["function_range_confirmed"] is True
    ct, desc, _conf, reason, is_core = analyze_function_commit(
        diff=diff,
        symbol=FN,
        message="재승차 개선",
        parent_has_function=True,
        diff_available=True,
    )
    assert is_core is True
    assert reason.startswith("function_context") or reason.startswith("body_change")
    assert "Diff상" not in desc

    class E:
        section = "core"
        diff_state = "ok"
        debug_item = {
            "classification_reason": reason,
            "evidence_tier": stats["evidence_tier"],
        }
        change_type = ct

    basis = _entry_git_basis(E())
    assert basis in {"함수 Diff", "함수 변경 구간 확인"}


def test_prototype_only_no_diff_claimed_feature_wording():
    diff = "\n".join(
        [
            "@@ -1,3 +1,3 @@",
            f"-bool {FN}(void);",
            f"+bool {FN}(int flag);",
        ]
    )
    _ct, desc, _c, _reason, _is_core = analyze_function_commit(
        diff=diff,
        symbol=FN,
        message="proto",
        parent_has_function=True,
        diff_available=True,
    )
    assert "Diff상" not in desc


def test_call_site_only():
    diff = "\n".join(
        [
            "@@ -50,3 +50,3 @@ void other(void)",
            f"-    {FN}();",
            f"+    {FN}(1);",
        ]
    )
    ct, desc, _c, reason, is_core = analyze_function_commit(
        diff=diff,
        symbol=FN,
        message="call",
        parent_has_function=True,
        diff_available=True,
    )
    assert is_core is False
    assert ct == "call_site_change" or reason in {
        "call_site_only",
        "symbol_only",
        "symbol_in_diff_scope_unknown",
    }
    assert "Diff상" not in desc


def test_message_only_not_core():
    _ct, desc, _c, reason, is_core = analyze_function_commit(
        diff=None,
        symbol=FN,
        message="재승차 10분 환승 판정 개선",
        parent_has_function=None,
        diff_available=False,
    )
    assert is_core is False
    assert reason in {"message_topic", "diff_unavailable", "message_only"}
    assert "Diff상" not in desc


def test_symbol_only_git_basis_label():
    class E:
        section = "unconfirmed"
        diff_state = "ok"
        debug_item = {
            "classification_reason": "symbol_only",
            "evidence_tier": EVIDENCE_SYMBOL_ONLY,
        }
        change_type = "related_candidate"

    assert _entry_git_basis(E()) == "Symbol만 확인"


def test_message_only_tier_when_no_symbol_in_diff():
    stats = _parse_diff_stats("@@ -1 +1 @@\n-old\n+new\n", FN)
    assert stats["evidence_tier"] == EVIDENCE_MESSAGE_ONLY


def test_prioritize_display_keeps_query_symbol():
    items = [f"fn{i}" for i in range(30)]
    items[25] = FN
    shown, omitted = _prioritize_for_display(
        items, preferred=FN, limit=8, match_fn=_symbols_match_display
    )
    assert shown[0] == FN
    assert omitted == 22
    assert FN in shown


def test_prioritize_does_not_invent_missing_symbol():
    items = [f"fn{i}" for i in range(10)]
    shown, omitted = _prioritize_for_display(
        items, preferred=FN, limit=5, match_fn=_symbols_match_display
    )
    assert FN not in shown
    assert omitted == 5
