"""Document applicable-equipment detection (shared document_path safe)."""

from __future__ import annotations

from app.services.change_item_candidate_service import ChangeItemCandidate
from app.services.equipment_name_utils import (
    MATCH_CLEAR,
    MATCH_MISMATCH,
    MATCH_MULTI,
    MATCH_UNKNOWN,
    analyze_document_equipment_match,
    normalize_equipment_name,
    text_mentions_equipment,
)
from app.services.lifecycle_ppt import (
    extract_related_symbols,
    item_matches_request_equipment,
)
from app.services.symbol_utils import (
    drop_suffix_symbol_duplicates,
    is_suffix_only_symbol,
    join_underscore_wrapped_lines,
    normalize_symbol,
)

FN = "card_mif_post_check_valid_birthday_usertype"
KNOWN = [(1, "휴대용정산기"), (2, "개집표기")]


def _item(
    *,
    file_name: str,
    title: str = "청소년 후불카드 적용",
    functions: list[str] | None = None,
    scopes: list[str] | None = None,
    equipment_id: int = 1,
) -> ChangeItemCandidate:
    return ChangeItemCandidate(
        change_item_cache_id=1,
        document_cache_id=1,
        slide_no=2,
        file_path=file_name,
        file_name=file_name,
        item_no="1",
        change_title=title,
        csr_no="C2020",
        business_background=title,
        current_status=None,
        as_is=None,
        to_be=title,
        source_functions=[
            {
                "file_path": "Card/mif_post/src/card_mif_postpay.c",
                "functions": functions or [FN],
            }
        ],
        test_cases=[],
        applicable_scopes=scopes or [],
        raw_text=title,
        matched_keywords=[],
        candidate_score=1,
        equipment_id=equipment_id,
    )


def test_normalize_strips_separators_and_parens():
    assert normalize_equipment_name("휴대용 정산기") == normalize_equipment_name(
        "휴대용_정산기"
    )
    assert normalize_equipment_name("Portable(Device)") == "portabledevice"


def test_clear_match_from_filename():
    item = _item(file_name="프로그램변경내역서_20200224_V129_V208_휴대용정산기.pptx")
    m = analyze_document_equipment_match(
        item,
        request_equipment_id=1,
        request_equipment_name="휴대용정산기",
        known_equipment=KNOWN,
    )
    assert m.match_type == MATCH_CLEAR


def test_clear_mismatch_other_equipment_same_discovery_id():
    item = _item(
        file_name="프로그램변경내역서 20200228_V1.37_개집표기.pptx",
        equipment_id=1,  # shared document_path discovery
    )
    m = analyze_document_equipment_match(
        item,
        request_equipment_id=1,
        request_equipment_name="휴대용정산기",
        known_equipment=KNOWN,
    )
    assert m.match_type == MATCH_MISMATCH
    assert not item_matches_request_equipment(
        item,
        1,
        request_equipment_name="휴대용정산기",
        known_equipment=KNOWN,
        symbol=FN,
        for_official=True,
    )


def test_multi_equipment_document_allowed_for_each():
    item = _item(
        file_name="프로그램변경내역서_20200224_공통.pptx",
        title="휴대용정산기 및 개집표기 청소년 후불카드 적용",
        scopes=["휴대용정산기", "개집표기"],
    )
    for req_id, req_name in KNOWN:
        m = analyze_document_equipment_match(
            item,
            request_equipment_id=req_id,
            request_equipment_name=req_name,
            known_equipment=KNOWN,
        )
        assert m.match_type == MATCH_MULTI
        assert item_matches_request_equipment(
            item,
            req_id,
            request_equipment_name=req_name,
            known_equipment=KNOWN,
            symbol=FN,
        )


def test_gate_query_uses_other_equipment_document():
    item = _item(file_name="프로그램변경내역서 20200228_V1.37_개집표기.pptx")
    m = analyze_document_equipment_match(
        item,
        request_equipment_id=2,
        request_equipment_name="개집표기",
        known_equipment=KNOWN,
    )
    assert m.match_type == MATCH_CLEAR
    assert item_matches_request_equipment(
        item,
        2,
        request_equipment_name="개집표기",
        known_equipment=KNOWN,
        symbol=FN,
    )


def test_unknown_equipment_without_strong_grounds_denied():
    item = _item(
        file_name="memo_notes.pptx",
        title="일반 메모",
        functions=[FN],
    )
    m = analyze_document_equipment_match(
        item,
        request_equipment_id=1,
        request_equipment_name="휴대용정산기",
        known_equipment=KNOWN,
    )
    assert m.match_type == MATCH_UNKNOWN
    assert not item_matches_request_equipment(
        item,
        1,
        request_equipment_name="휴대용정산기",
        known_equipment=KNOWN,
        symbol=FN,
        file_path="Card/mif_post/src/card_mif_postpay.c",
        for_official=True,
    )


def test_change_history_filename_missing_request_is_mismatch():
    item = _item(file_name="프로그램변경내역서 20200228_V1.37_개집표기.pptx")
    m = analyze_document_equipment_match(
        item,
        request_equipment_id=1,
        request_equipment_name="휴대용정산기",
        known_equipment=[(1, "휴대용정산기")],  # other not registered
    )
    assert m.match_type == MATCH_MISMATCH
    assert "request_absent" in m.equipment_match_reason


def test_text_mentions_equipment_alias_forms():
    assert text_mentions_equipment("대상: 휴대용_정산기", "휴대용정산기")
    assert not text_mentions_equipment("개집표기 적용", "휴대용정산기")


def test_suffix_only_usertype_rejected():
    assert is_suffix_only_symbol("_usertype")
    assert normalize_symbol("_usertype()") == "_usertype"
    cleaned = drop_suffix_symbol_duplicates(
        [FN, "_usertype", "usertype"]
    )
    assert FN in cleaned
    assert "_usertype" not in cleaned
    assert "usertype" not in cleaned


def test_orphan_leading_underscore_line_rejoins():
    joined = join_underscore_wrapped_lines(
        [
            "card_mif_post_check_valid_birthday",
            "_usertype()",
        ]
    )
    assert any(normalize_symbol(p) == FN for p in joined)


def test_extract_related_symbols_drops_usertype_suffix():
    item = _item(
        file_name="프로그램변경내역서_20200224_V129_V208_휴대용정산기.pptx",
        functions=[
            "card_mif_post_check_valid_birthday_\nusertype()",
            "_usertype()",
        ],
    )
    item.source_functions = [
        {
            "file_path": "Card/mif_post/src/card_mif_postpay.c",
            "functions": [
                "card_mif_post_check_valid_birthday_\nusertype()",
                "_usertype()",
            ],
            "raw_text": (
                "Card/mif_post/src/card_mif_postpay.c\n"
                "card_mif_post_check_valid_birthday_\n"
                "usertype()\n"
                "_usertype()\n"
            ),
        }
    ]
    symbols = extract_related_symbols(item)
    assert FN in symbols
    assert "_usertype" not in symbols
    assert "usertype" not in {s.lower() for s in symbols}
