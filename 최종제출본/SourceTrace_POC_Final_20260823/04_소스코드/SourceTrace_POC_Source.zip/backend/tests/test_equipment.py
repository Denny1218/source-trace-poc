from pathlib import Path

from app.services.path_validation_service import (
    NOT_GIT_REPO_MESSAGE,
    PATH_NOT_FOUND_MESSAGE,
    validate_document_path,
    validate_document_path_basic,
    validate_git_path,
)

from tests.conftest import equipment_payload


def test_validate_git_path_success(device_a_paths):
    valid, message = validate_git_path(device_a_paths["git_path"])
    assert valid is True
    assert "유효" in message


def test_validate_git_path_not_a_repo(tmp_path):
    folder = tmp_path / "not-a-repo"
    folder.mkdir()
    valid, message = validate_git_path(str(folder))
    assert valid is False
    assert message == NOT_GIT_REPO_MESSAGE


def test_validate_git_path_not_found():
    valid, message = validate_git_path(r"C:\does-not-exist\path")
    assert valid is False
    assert message == PATH_NOT_FOUND_MESSAGE


def test_validate_document_path_success(device_a_paths):
    valid, message, count = validate_document_path(device_a_paths["document_path"])
    assert valid is True
    assert count >= 1
    assert "PPTX" in message


def test_validate_document_path_basic_skips_pptx_count(device_a_paths):
    valid, message = validate_document_path_basic(device_a_paths["document_path"])
    assert valid is True
    assert "PPTX" not in message


def test_create_equipment_uses_basic_document_validation(
    client, device_a_paths, monkeypatch
):
    import app.services.equipment_service as equipment_service

    calls: list[str] = []

    def track(path: str):
        calls.append(path)
        return True, "ok"

    monkeypatch.setattr(equipment_service, "validate_document_path_basic", track)
    response = client.post("/api/equipment", json=equipment_payload(device_a_paths))
    assert response.status_code == 201
    assert len(calls) == 1


def test_validate_document_path_rejects_local_drive():
    valid, message, count = validate_document_path(r"D:\ChangeDocuments\HHD200")
    assert valid is False
    assert "네트워크 공유" in message
    assert count == 0


def test_validate_document_path_not_found():
    valid, message, count = validate_document_path(r"\\server\missing\documents")
    assert valid is False
    assert count == 0


def test_create_equipment_success(client, device_a_paths):
    response = client.post("/api/equipment", json=equipment_payload(device_a_paths))
    assert response.status_code == 201
    data = response.json()
    assert data["name"] == "TEST_DEVICE_A"
    assert "git_path" not in data
    assert "id" in data
    assert "created_at" in data


def test_create_repository_invalid_local_path(client, device_a_paths, tmp_path):
    not_repo = tmp_path / "plain-folder"
    not_repo.mkdir()
    equipment = client.post(
        "/api/equipment", json=equipment_payload(device_a_paths)
    ).json()
    response = client.post(
        f"/api/equipment/{equipment['id']}/repositories",
        json={
            "name": "bad_repo",
            "source_type": "local",
            "local_path": str(not_repo),
        },
    )
    assert response.status_code == 400
    assert response.json()["detail"] == NOT_GIT_REPO_MESSAGE


def test_create_equipment_missing_document_path(client, device_a_paths):
    payload = equipment_payload(device_a_paths)
    payload["document_path"] = r"\\server\missing\documents"
    response = client.post("/api/equipment", json=payload)
    assert response.status_code == 400
    assert "찾을 수 없" in response.json()["detail"] or "네트워크" in response.json()["detail"]


def test_create_two_equipment(client, device_a_paths, device_b_paths):
    r1 = client.post("/api/equipment", json=equipment_payload(device_a_paths))
    r2 = client.post("/api/equipment", json=equipment_payload(device_b_paths))
    assert r1.status_code == 201
    assert r2.status_code == 201
    assert r1.json()["id"] != r2.json()["id"]


def test_duplicate_equipment_name(client, device_a_paths):
    client.post("/api/equipment", json=equipment_payload(device_a_paths))
    response = client.post("/api/equipment", json=equipment_payload(device_a_paths))
    assert response.status_code == 409
    assert "장비명" in response.json()["detail"]


def test_update_equipment(client, device_a_paths):
    created = client.post(
        "/api/equipment", json=equipment_payload(device_a_paths)
    ).json()
    updated_payload = {
        **equipment_payload(device_a_paths),
        "name": "TEST_DEVICE_A_UPDATED",
    }
    response = client.put(f"/api/equipment/{created['id']}", json=updated_payload)
    assert response.status_code == 200
    assert response.json()["name"] == "TEST_DEVICE_A_UPDATED"


def test_delete_equipment(client, device_a_paths):
    created = client.post(
        "/api/equipment", json=equipment_payload(device_a_paths)
    ).json()
    response = client.delete(f"/api/equipment/{created['id']}")
    assert response.status_code == 204
    assert client.get(f"/api/equipment/{created['id']}").status_code == 404


def test_equipment_persists_after_reinit(test_db, device_a_paths):
    from fastapi.testclient import TestClient

    from app.db.database import init_database
    from app.main import app

    client = TestClient(app)
    created = client.post(
        "/api/equipment", json=equipment_payload(device_a_paths)
    ).json()

    init_database()

    client2 = TestClient(app)
    response = client2.get(f"/api/equipment/{created['id']}")
    assert response.status_code == 200
    assert response.json()["name"] == "TEST_DEVICE_A"


def test_validate_git_api(client, device_a_paths):
    response = client.post(
        "/api/equipment/validate/git", json={"path": device_a_paths["git_path"]}
    )
    assert response.status_code == 200
    assert response.json()["valid"] is True


def test_validate_document_api(client, device_a_paths):
    response = client.post(
        "/api/equipment/validate/document",
        json={"path": device_a_paths["document_path"]},
    )
    assert response.status_code == 200
    data = response.json()
    assert data["valid"] is True
    assert data["pptx_count"] >= 1


def test_git_path_with_spaces(tmp_path):
    """한글 및 공백 경로에서 Git 검증이 동작하는지 확인."""
    repo_path = tmp_path / "path with spaces" / "repo"
    repo_path.mkdir(parents=True)

    import subprocess

    subprocess.run(["git", "init"], cwd=repo_path, check=True, capture_output=True)
    (repo_path / "README.md").write_text("# test\n", encoding="utf-8")
    subprocess.run(["git", "add", "."], cwd=repo_path, check=True, capture_output=True)
    subprocess.run(
        [
            "git",
            "-c",
            "user.email=test@example.com",
            "-c",
            "user.name=Test User",
            "commit",
            "-m",
            "initial",
        ],
        cwd=repo_path,
        check=True,
        capture_output=True,
        encoding="utf-8",
    )

    valid, _ = validate_git_path(str(repo_path))
    assert valid is True


def test_create_equipment_with_zero_repositories(client, device_a_paths):
    response = client.post("/api/equipment", json=equipment_payload(device_a_paths))
    assert response.status_code == 201
    repos = client.get(f"/api/equipment/{response.json()['id']}/repositories").json()
    assert repos == []


def test_create_equipment_with_multiple_repositories(client, device_a_paths):
    equipment = client.post(
        "/api/equipment", json=equipment_payload(device_a_paths)
    ).json()
    for name in ("repo_a", "repo_b"):
        res = client.post(
            f"/api/equipment/{equipment['id']}/repositories",
            json={
                "name": name,
                "source_type": "local",
                "local_path": device_a_paths["git_path"],
            },
        )
        assert res.status_code == 201
    listed = client.get(f"/api/equipment/{equipment['id']}/repositories").json()
    assert len(listed) == 2
