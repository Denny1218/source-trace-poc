"""Equipment filename hard-filter tests for PPT / Change Item / Evidence."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import patch

from app.db.database import get_connection
from app.services.ppt_analysis_service import analyze_ppt
from app.services.ppt_candidate_service import (
    PptCandidateResult,
    list_scored_ppt_files_for_fallback,
    search_ppt_candidates,
)
from tests.conftest import local_path_to_test_unc


def _touch(path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(b"PK\x03\x04placeholder")


def _create_equipment(name: str, document_path: str) -> int:
    conn = get_connection()
    try:
        cursor = conn.execute(
            """
            INSERT INTO equipment (name, git_path, document_path, created_at, updated_at)
            VALUES (?, ?, ?, datetime('now'), datetime('now'))
            """,
            (name, "C:/tmp/filter-test-repo", document_path),
        )
        conn.commit()
        return int(cursor.lastrowid)
    finally:
        conn.close()


def _insert_document(equipment_id: int, file_path: str, file_name: str) -> int:
    conn = get_connection()
    try:
        cursor = conn.execute(
            """
            INSERT INTO document_cache
                (equipment_id, file_path, file_name, file_hash, modified_at, parsed_at, slide_count)
            VALUES (?, ?, ?, 'hash', datetime('now'), datetime('now'), 1)
            """,
            (equipment_id, file_path, file_name),
        )
        conn.commit()
        return int(cursor.lastrowid)
    finally:
        conn.close()


def _insert_change_item(document_cache_id: int, change_title: str, source_path: str) -> int:
    conn = get_connection()
    try:
        cursor = conn.execute(
            """
            INSERT INTO change_item_cache
                (document_cache_id, slide_no, item_no, change_title, csr_no,
                 business_background, current_status, as_is, to_be,
                 source_functions_json, test_cases_json, applicable_scopes_json,
                 raw_text, parser_version, created_at)
            VALUES (?, 1, '1', ?, NULL, ?, NULL, NULL, NULL, ?, '[]', '[]', ?, 1, datetime('now'))
            """,
            (
                document_cache_id,
                change_title,
                change_title,
                json.dumps(
                    [{"file_path": source_path, "functions": ["calculate_fare"]}],
                    ensure_ascii=False,
                ),
                change_title,
            ),
        )
        conn.commit()
        return int(cursor.lastrowid)
    finally:
        conn.close()


def test_filename_contains_equipment_included(test_db, tmp_path):
    docs = tmp_path / "docs"
    _touch(docs / "program_change_PortableDevice_feature_a.pptx")
    _touch(docs / "program_change_GateDevice_feature_a.pptx")
    eq_id = _create_equipment("PortableDevice", local_path_to_test_unc(docs))

    result = search_ppt_candidates(eq_id, ["feature"], "2020-01-01", "2030-12-31")
    names = [c.file_name for c in result.ppt_candidates]
    assert any("PortableDevice" in n for n in names)
    assert not any("GateDevice" in n for n in names)
    assert result.equipment_filter_excluded >= 1


def test_folder_contains_equipment_but_filename_other_excluded(test_db, tmp_path):
    docs = tmp_path / "docs"
    shared = docs / "PortableDevice_folder"
    _touch(shared / "program_change_GateDevice_feature_a.pptx")
    eq_id = _create_equipment("PortableDevice", local_path_to_test_unc(docs))

    result = search_ppt_candidates(
        eq_id, ["feature", "GateDevice"], "2020-01-01", "2030-12-31"
    )
    assert result.ppt_candidates == []
    assert result.equipment_filter_excluded >= 1


def test_same_folder_different_equipment_filename_excluded(test_db, tmp_path):
    docs = tmp_path / "docs" / "shared"
    _touch(docs / "program_change_20250101_PortableDevice_feature.pptx")
    _touch(docs / "program_change_20250101_GateDevice_feature.pptx")
    eq_id = _create_equipment("PortableDevice", local_path_to_test_unc(docs))

    result = search_ppt_candidates(eq_id, ["feature"], "2020-01-01", "2030-12-31")
    names = [c.file_name for c in result.ppt_candidates]
    assert names == ["program_change_20250101_PortableDevice_feature.pptx"]


def test_cached_change_item_other_equipment_excluded(test_db, tmp_path):
    docs = tmp_path / "docs"
    _touch(docs / "program_change_PortableDevice_feature_a.pptx")
    eq_id = _create_equipment("PortableDevice", local_path_to_test_unc(docs))

    own_doc = _insert_document(
        eq_id,
        str(docs / "program_change_PortableDevice_feature_a.pptx"),
        "program_change_PortableDevice_feature_a.pptx",
    )
    other_doc = _insert_document(
        eq_id,
        str(docs / "program_change_GateDevice_feature_a.pptx"),
        "program_change_GateDevice_feature_a.pptx",
    )
    _insert_change_item(own_doc, "PortableDevice feature change", "src/a.c")
    _insert_change_item(other_doc, "GateDevice feature change", "src/b.c")

    analysis = analyze_ppt(
        eq_id,
        keywords=["feature"],
        date_from="2020-01-01",
        date_to="2030-12-31",
    )
    titles = [c.change_title for c in analysis.change_item_candidates]
    assert any(t and "PortableDevice" in t for t in titles)
    assert not any(t and "GateDevice" in t for t in titles)
    names = [c.file_name for c in analysis.change_item_candidates]
    assert not any("GateDevice" in n for n in names)
    assert analysis.equipment_filter_excluded >= 1


def test_cached_path_folder_equipment_filename_other_excluded(test_db, tmp_path):
    """Cache row whose full path folder has equipment name must still fail on basename."""
    docs = tmp_path / "docs"
    _touch(docs / "program_change_PortableDevice_feature_a.pptx")
    eq_id = _create_equipment("PortableDevice", local_path_to_test_unc(docs))

    own_doc = _insert_document(
        eq_id,
        str(docs / "program_change_PortableDevice_feature_a.pptx"),
        "program_change_PortableDevice_feature_a.pptx",
    )
    # Simulate shared-folder cache: folder looks like PortableDevice, file is GateDevice.
    other_path = str(
        tmp_path / "PortableDevice" / "program_change_GateDevice_feature_a.pptx"
    )
    other_doc = _insert_document(
        eq_id,
        other_path,
        "program_change_GateDevice_feature_a.pptx",
    )
    _insert_change_item(own_doc, "PortableDevice feature change", "src/a.c")
    _insert_change_item(other_doc, "GateDevice feature change", "src/b.c")

    analysis = analyze_ppt(
        eq_id,
        keywords=["feature"],
        date_from="2020-01-01",
        date_to="2030-12-31",
    )
    names = [c.file_name for c in analysis.change_item_candidates]
    assert all("PortableDevice" in n for n in names)
    assert not any("GateDevice" in n for n in names)


def test_ppt_candidate_excludes_different_equipment(test_db, tmp_path):
    docs = tmp_path / "docs"
    _touch(docs / "program_change_20250101_PortableDevice_feature.pptx")
    _touch(docs / "program_change_20250101_GateDevice_feature.pptx")
    eq_id = _create_equipment("PortableDevice", local_path_to_test_unc(docs))
    result = search_ppt_candidates(eq_id, ["feature"], "2020-01-01", "2030-12-31")
    assert all("PortableDevice" in c.file_name for c in result.ppt_candidates)
    assert not any("GateDevice" in c.file_name for c in result.ppt_candidates)


def test_change_item_candidate_excludes_different_equipment(test_db, tmp_path):
    docs = tmp_path / "docs"
    _touch(docs / "program_change_PortableDevice_feature_a.pptx")
    eq_id = _create_equipment("PortableDevice", local_path_to_test_unc(docs))
    own = _insert_document(
        eq_id,
        str(docs / "program_change_PortableDevice_feature_a.pptx"),
        "program_change_PortableDevice_feature_a.pptx",
    )
    other = _insert_document(
        eq_id,
        str(docs / "program_change_GateDevice_feature_a.pptx"),
        "program_change_GateDevice_feature_a.pptx",
    )
    _insert_change_item(own, "PortableDevice feature change", "src/a.c")
    _insert_change_item(other, "GateDevice feature change", "src/b.c")
    analysis = analyze_ppt(eq_id, ["feature"], "2020-01-01", "2030-12-31")
    assert all(
        "PortableDevice" in (c.file_name or "") for c in analysis.change_item_candidates
    )


def test_evidence_api_excludes_other_equipment_document(test_db, tmp_path, client):
    docs = tmp_path / "docs"
    _touch(docs / "program_change_PortableDevice_feature_a.pptx")
    eq_id = _create_equipment("PortableDevice", local_path_to_test_unc(docs))
    own_doc = _insert_document(
        eq_id,
        str(docs / "program_change_PortableDevice_feature_a.pptx"),
        "program_change_PortableDevice_feature_a.pptx",
    )
    other_doc = _insert_document(
        eq_id,
        str(docs / "program_change_GateDevice_feature_a.pptx"),
        "program_change_GateDevice_feature_a.pptx",
    )
    _insert_change_item(own_doc, "PortableDevice feature change", "src/a.c")
    _insert_change_item(other_doc, "GateDevice feature change", "src/b.c")

    response = client.post(
        "/api/trace/evidence",
        json={"equipment_id": eq_id, "query": "feature change"},
    )
    assert response.status_code == 200
    data = response.json()
    names = [c["file_name"] for c in data["change_item_candidates"]]
    assert all("PortableDevice" in n for n in names)
    assert not any("GateDevice" in n for n in names)
    assert data["debug"]["equipment_filter_excluded"] >= 1
    assert data["debug"]["equipment_filter_reason"] == "filename equipment mismatch"


def test_progressive_fallback_also_filtered(test_db, tmp_path):
    docs = tmp_path / "docs"
    _touch(docs / "program_change_PortableDevice_feature_a.pptx")
    _touch(docs / "program_change_GateDevice_feature_a.pptx")
    eq_id = _create_equipment("PortableDevice", local_path_to_test_unc(docs))

    scored = list_scored_ppt_files_for_fallback(
        eq_id, ["feature"], "2020-01-01", "2030-12-31"
    )
    assert all("PortableDevice" in c.file_name for c in scored)
    assert not any("GateDevice" in c.file_name for c in scored)

    # Even if a mismatched candidate were injected into fallback scoring, analysis
    # must still drop GateDevice change items from cache.
    other = _insert_document(
        eq_id,
        str(docs / "program_change_GateDevice_feature_a.pptx"),
        "program_change_GateDevice_feature_a.pptx",
    )
    _insert_change_item(other, "GateDevice feature change", "src/b.c")

    with patch(
        "app.services.ppt_analysis_service.PPT_FALLBACK_RESULT_LIMIT",
        99,
    ):
        analysis = analyze_ppt(eq_id, ["feature"], "2020-01-01", "2030-12-31")
    names = [c.file_name for c in analysis.change_item_candidates]
    assert not any("GateDevice" in n for n in names)


def test_whitespace_normalized_equipment_include(test_db, tmp_path):
    docs = tmp_path / "docs"
    _touch(docs / "program_change_휴대용정산기_feature.pptx")
    eq_id = _create_equipment("휴대용 정산기", local_path_to_test_unc(docs))
    result = search_ppt_candidates(eq_id, ["feature"], "2020-01-01", "2030-12-31")
    assert len(result.ppt_candidates) == 1


def test_english_case_insensitive_include(test_db, tmp_path):
    docs = tmp_path / "docs"
    _touch(docs / "program_change_PORTABLEDEVICE_feature.pptx")
    eq_id = _create_equipment("PortableDevice", local_path_to_test_unc(docs))
    result = search_ppt_candidates(eq_id, ["feature"], "2020-01-01", "2030-12-31")
    assert len(result.ppt_candidates) == 1


def test_final_filter_drops_mismatched_injected_candidates(test_db, tmp_path):
    """Return-path filter must drop mismatched items even if upstream merges them."""
    docs = tmp_path / "docs"
    _touch(docs / "program_change_GateDevice_feature_a.pptx")
    eq_id = _create_equipment("PortableDevice", local_path_to_test_unc(docs))
    other = _insert_document(
        eq_id,
        str(docs / "program_change_GateDevice_feature_a.pptx"),
        "program_change_GateDevice_feature_a.pptx",
    )
    _insert_change_item(other, "GateDevice feature change", "src/b.c")

    # Inject a GateDevice PPT candidate that bypassed the filesystem filter.
    leaked = PptCandidateResult(
        file_path=str(docs / "program_change_GateDevice_feature_a.pptx"),
        file_name="program_change_GateDevice_feature_a.pptx",
        modified_at="2020-01-01T00:00:00+00:00",
        file_size=10,
        candidate_score=90,
        match_reasons=["filename_keyword"],
    )

    from app.services.ppt_analysis_service import _analyze_from_candidates

    analysis = _analyze_from_candidates(
        eq_id,
        [leaked],
        ["feature"],
        date_from="2020-01-01",
        date_to="2030-12-31",
        equipment_name="PortableDevice",
        equipment_filter_excluded=0,
    )

    assert analysis.change_item_candidates == []
    assert analysis.ppt_candidate_count == 0
    assert analysis.equipment_filter_excluded >= 1
