"""Equipment filename filter unit tests (synthetic names only)."""

from app.services.equipment_name_utils import (
    document_basename,
    filename_matches_equipment,
    is_document_for_equipment,
    normalize_equipment_name,
)


def test_normalize_strips_and_collapses_separators():
    assert normalize_equipment_name("  Portable Device  ") == "portabledevice"
    assert normalize_equipment_name("휴대용 정산기") == "휴대용정산기"
    assert normalize_equipment_name("Portable_Device") == "portabledevice"
    assert normalize_equipment_name("Portable-Device") == "portabledevice"
    assert normalize_equipment_name("Portable.Device") == "portabledevice"
    assert normalize_equipment_name("Portable(Device)") == "portabledevice"


def test_filename_contains_selected_equipment_include():
    assert (
        filename_matches_equipment(
            "program_change_PortableDevice_feature_a.pptx",
            "PortableDevice",
        )
        is True
    )


def test_filename_different_equipment_exclude():
    assert (
        filename_matches_equipment(
            "program_change_GateDevice_feature_a.pptx",
            "PortableDevice",
        )
        is False
    )


def test_whitespace_normalized_equipment_include():
    assert (
        filename_matches_equipment(
            "program_change_휴대용정산기_feature.pptx",
            "휴대용 정산기",
        )
        is True
    )


def test_case_insensitive_english_include():
    assert (
        filename_matches_equipment(
            "program_change_PORTABLEDEVICE_feature.pptx",
            "PortableDevice",
        )
        is True
    )


def test_folder_name_ignored_filename_different_exclude():
    """Folder containing equipment name must not pass a different-equipment file."""
    assert (
        is_document_for_equipment(
            r"\\share\PortableDevice\program_change_GateDevice_feature.pptx",
            "PortableDevice",
        )
        is False
    )
    assert (
        is_document_for_equipment(
            r"C:/docs/PortableDevice_folder/program_change_GateDevice_feature.pptx",
            "PortableDevice",
        )
        is False
    )


def test_is_document_for_equipment_basename_include():
    assert (
        is_document_for_equipment(
            r"\\share\mixed\program_change_20250101_PortableDevice_feature.pptx",
            "PortableDevice",
        )
        is True
    )


def test_document_basename_strips_folder():
    assert (
        document_basename(r"\\share\PortableDevice\GateDevice_feature.pptx")
        == "GateDevice_feature.pptx"
    )


def test_empty_or_short_equipment_exclude():
    assert filename_matches_equipment("anything.pptx", "") is False
    assert filename_matches_equipment("anything.pptx", "A") is False
    assert filename_matches_equipment("", "PortableDevice") is False
    assert is_document_for_equipment("", "PortableDevice") is False
