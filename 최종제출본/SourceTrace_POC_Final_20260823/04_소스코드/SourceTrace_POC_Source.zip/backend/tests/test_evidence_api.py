"""STEP 7: `POST /api/trace/evidence` integration tests.

Git side reuses the existing synthetic device-a repository fixture
(FareCalc.c / CalcFare / CHILD_FARE — already used by STEP 4 trace tests).
Change Item side is inserted directly into `change_item_cache` (synthetic,
no real PPT content) — same approach already used by test_change_item_cache.py
/ test_change_link.py."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from app.db.database import get_connection


def _insert_document(equipment_id: int, file_path: str, file_name: str) -> int:
    conn = get_connection()
    try:
        cursor = conn.execute(
            """
            INSERT INTO document_cache
                (equipment_id, file_path, file_name, file_hash, modified_at, parsed_at, slide_count)
            VALUES (?, ?, ?, 'hash', datetime('now'), datetime('now'), 1)
            """,
            (equipment_id, file_path, file_name),
        )
        conn.commit()
        return int(cursor.lastrowid)
    finally:
        conn.close()


def _insert_change_item(
    document_cache_id: int,
    change_title: str | None = None,
    csr_no: str | None = None,
    business_background: str | None = None,
    source_functions: list[dict] | None = None,
    raw_text: str = "",
) -> int:
    conn = get_connection()
    try:
        cursor = conn.execute(
            """
            INSERT INTO change_item_cache
                (document_cache_id, slide_no, item_no, change_title, csr_no,
                 business_background, current_status, as_is, to_be,
                 source_functions_json, test_cases_json, applicable_scopes_json,
                 raw_text, parser_version, created_at)
            VALUES (?, 1, '1', ?, ?, ?, NULL, NULL, NULL, ?, '[]', '[]', ?, 1, datetime('now'))
            """,
            (
                document_cache_id,
                change_title,
                csr_no,
                business_background,
                json.dumps(source_functions or [], ensure_ascii=False),
                raw_text,
            ),
        )
        conn.commit()
        return int(cursor.lastrowid)
    finally:
        conn.close()


def _seed_linked_change_item(equipment_id: int, docs_dir: Path) -> int:
    doc_id = _insert_document(
        equipment_id,
        str(docs_dir / "TEST_DEVICE_A_fare_change.pptx"),
        "TEST_DEVICE_A_fare_change.pptx",
    )
    return _insert_change_item(
        doc_id,
        change_title="CalcFare 요금 계산 정책 변경",
        source_functions=[{"file_path": "FareCalc.c", "functions": ["CalcFare"]}],
    )


def _seed_weak_only_change_item(equipment_id: int, docs_dir: Path) -> int:
    doc_id = _insert_document(
        equipment_id,
        str(docs_dir / "TEST_DEVICE_A_notes.pptx"),
        "TEST_DEVICE_A_notes.pptx",
    )
    return _insert_change_item(
        doc_id,
        business_background="어린이 카드 정책 변경 안내",
        source_functions=[{"file_path": "unrelated/other.c", "functions": ["UnrelatedFn"]}],
    )


def test_evidence_normal_result(client, synced_device_a, device_a_paths):
    eid = synced_device_a["id"]
    _seed_linked_change_item(eid, Path(device_a_paths["document_path_local"]))

    response = client.post(
        "/api/trace/evidence",
        json={"equipment_id": eid, "query": "CalcFare 함수가 왜 변경됐어?"},
    )
    assert response.status_code == 200
    data = response.json()

    assert data["equipment_id"] == eid
    assert len(data["git_candidates"]) >= 1
    assert len(data["change_item_candidates"]) >= 1
    assert len(data["evidence_links"]) >= 1

    link = data["evidence_links"][0]
    assert link["link_score"] > 0
    assert len(link["match_reasons"]) >= 1
    reason_types = {r["type"] for r in link["match_reasons"]}
    assert reason_types & {"same_function_exact", "same_file_path"}
    assert "change_item_cache_id" in link
    assert "git_commit_id" in link


def test_evidence_no_git_candidates(client, registered_device_a):
    """Equipment registered but never synced -> no Git commits at all."""
    eid = registered_device_a["id"]
    response = client.post(
        "/api/trace/evidence",
        json={"equipment_id": eid, "query": "CalcFare 함수가 왜 변경됐어?"},
    )
    assert response.status_code == 200
    data = response.json()
    assert data["git_candidates"] == []
    assert data["evidence_links"] == []


def test_evidence_no_change_item_candidates(client, synced_device_a):
    """Git candidates exist, but no change_item_cache row matches the query."""
    eid = synced_device_a["id"]
    response = client.post(
        "/api/trace/evidence",
        json={"equipment_id": eid, "query": "CalcFare 함수가 왜 변경됐어?"},
    )
    assert response.status_code == 200
    data = response.json()
    assert len(data["git_candidates"]) >= 1
    assert data["change_item_candidates"] == []
    assert data["evidence_links"] == []


def test_evidence_candidates_without_link(client, synced_device_a, device_a_paths):
    """Both candidate lists are non-empty but the only shared evidence is a
    single Weak type (message vs business_background) — Gate excludes it."""
    eid = synced_device_a["id"]
    _seed_weak_only_change_item(eid, Path(device_a_paths["document_path_local"]))

    response = client.post(
        "/api/trace/evidence",
        json={"equipment_id": eid, "query": "어린이 카드 요금 변경"},
    )
    assert response.status_code == 200
    data = response.json()
    assert len(data["git_candidates"]) >= 1
    assert len(data["change_item_candidates"]) >= 1
    assert data["evidence_links"] == []


def test_evidence_invalid_equipment(client):
    response = client.post(
        "/api/trace/evidence",
        json={"equipment_id": 99999, "query": "test"},
    )
    assert response.status_code == 404


def test_evidence_empty_query_rejected(client, synced_device_a):
    eid = synced_device_a["id"]
    response = client.post(
        "/api/trace/evidence",
        json={"equipment_id": eid, "query": ""},
    )
    assert response.status_code == 422


def test_evidence_service_has_no_ollama_dependency():
    """STEP 7 must not depend on Ollama availability at all (STEP 8 scope)."""
    source = Path("app/services/evidence_service.py").read_text(encoding="utf-8")
    assert "ollama" not in source.lower()


@pytest.mark.parametrize("field", ["git_candidates", "change_item_candidates", "evidence_links", "debug"])
def test_evidence_response_shape(client, synced_device_a, device_a_paths, field):
    eid = synced_device_a["id"]
    _seed_linked_change_item(eid, Path(device_a_paths["document_path_local"]))
    response = client.post(
        "/api/trace/evidence",
        json={"equipment_id": eid, "query": "CalcFare 함수가 왜 변경됐어?"},
    )
    assert response.status_code == 200
    assert field in response.json()


def test_evidence_query_relevance_includes_core_match(client, synced_device_a, device_a_paths):
    eid = synced_device_a["id"]
    _seed_linked_change_item(eid, Path(device_a_paths["document_path_local"]))
    response = client.post(
        "/api/trace/evidence",
        json={"equipment_id": eid, "query": "CalcFare 함수가 왜 변경됐어?"},
    )
    assert response.status_code == 200
    data = response.json()
    assert "CalcFare" in data["request_functions"]
    assert data["weak_query_terms"]  # 함수가 / 변경됐어 등 intent filler
    assert "CalcFare" not in data["weak_query_terms"]
    assert len(data["evidence_links"]) >= 1
    link = data["evidence_links"][0]
    assert "query_match_reasons" in link
    assert link["query_relevance_level"] in {"높음", "보통", "낮음"}
    assert link["final_rank_score"] >= link["link_score"]
    assert any(
        r.get("keyword") == "CalcFare" for r in link["query_match_reasons"]
    ) or link["query_relevance_score"] > 0
    git = data["git_candidates"][0]
    assert "query_match_reasons" in git
    ci = data["change_item_candidates"][0]
    assert "query_match_reasons" in ci
    assert "query_relevance_excluded_links" in data["debug"]


def test_evidence_excludes_strong_link_without_core_query(client, synced_device_a, device_a_paths):
    """Strong file/function link must not appear when core query keyword is absent."""
    eid = synced_device_a["id"]
    docs = Path(device_a_paths["document_path_local"])
    # Strong structural link target (CalcFare / FareCalc.c) — unrelated to "receipt".
    _seed_linked_change_item(eid, docs)

    response = client.post(
        "/api/trace/evidence",
        json={"equipment_id": eid, "query": "receipt change"},
    )
    assert response.status_code == 200
    data = response.json()
    assert "receipt" in [k.lower() for k in data["query_keywords"]]
    assert any(t.lower() == "change" for t in data["weak_query_terms"])
    # No Evidence Link may claim receipt relevance without a receipt match.
    for link in data["evidence_links"]:
        assert any(
            r["keyword"].lower() == "receipt" and r["strength"] == "core"
            for r in link["query_match_reasons"]
        )
    # If Git Top5 somehow still pairs with CalcFare, Query Relevance Gate must drop them.
    if data["git_candidates"] and data["change_item_candidates"]:
        assert (
            data["debug"]["query_relevance_excluded_links"] >= 1
            or all(
                any(r["keyword"].lower() == "receipt" for r in link["query_match_reasons"])
                for link in data["evidence_links"]
            )
        )
