"""Ensure Extension user README has no legacy STEP/POC wording."""

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
README_CANDIDATES = [
    ROOT / "vscode-extension" / "README.md",
    ROOT / "산출물" / "운영PC" / "VSCode-Extension" / "참고_README.md",
]

FORBIDDEN = [
    "STEP 9",
    "STEP 9-2",
    "STEP 4",
    "STEP 7",
    "POC",
    "MVP",
    "Continue를 대체",
    "Continue 설정 스니펫",
    "Continue 사이드바",
    "continueSnippet",
    "continueProgress",
    "config.yaml",
    "@호출명",
    "equipmentId` | `1`",
    "equipmentId` | 1",
]


def test_readme_is_user_guide_without_poc_step_jargon():
    found = [p for p in README_CANDIDATES if p.is_file()]
    assert found, "README files missing"
    for path in found:
        text = path.read_text(encoding="utf-8")
        assert "Source Trace" in text
        assert "서버 및 장비 설정" in text
        for token in FORBIDDEN:
            assert token not in text, f"{path.name} still contains '{token}'"


def test_readme_documents_continue_removal_not_usage():
    """PROJECT_SPEC v2.3: Continue integration is removed — Extension direct query
    is the sole official path. The README may only mention Continue once, as a
    short legacy-config removal notice (no setup/usage instructions)."""
    for path in README_CANDIDATES:
        if not path.is_file():
            continue
        text = path.read_text(encoding="utf-8")
        assert "PROJECT_SPEC v2.3" in text
        assert "Continue 연동은 지원하지 않습니다" in text
        assert text.count("Continue") <= 4


def test_readme_settings_match_current_keys():
    pkg = (ROOT / "vscode-extension" / "package.json").read_text(encoding="utf-8")
    readme = (ROOT / "vscode-extension" / "README.md").read_text(encoding="utf-8")
    for key in (
        "sourceTrace.serverUrl",
        "sourceTrace.equipmentId",
        "sourceTrace.backendUrl",
        "sourceTrace.useOllama",
        "sourceTrace.diagnosticLogging",
    ):
        assert key in pkg
        assert key in readme
    assert "sourceTrace.setup" in pkg or "서버 및 장비 설정" in pkg
