"""Frontend static file serving tests."""

from __future__ import annotations

import re
from pathlib import Path

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient

from app.core.frontend_static import configure_frontend_static, get_frontend_dist_dir


def _make_test_app(dist_dir: Path | None) -> FastAPI:
    app = FastAPI()

    @app.get("/api/health")
    def health():
        return {"status": "ok"}

    @app.get("/api/sample")
    def sample():
        return {"sample": True}

    if dist_dir is not None:
        configure_frontend_static(app, dist_dir=dist_dir)
    else:
        configure_frontend_static(app)

    return app


@pytest.fixture
def sample_dist(tmp_path):
    dist = tmp_path / "dist"
    assets = dist / "assets"
    brand = dist / "brand"
    assets.mkdir(parents=True)
    brand.mkdir(parents=True)
    (dist / "index.html").write_text(
        '<html><head><link rel="stylesheet" href="/assets/app.css">'
        '<link rel="icon" href="/static/brand/favicon.ico">'
        '<script src="/assets/app.js"></script></head><body>UI</body></html>',
        encoding="utf-8",
    )
    (assets / "app.js").write_text("console.log('ok');", encoding="utf-8")
    (assets / "app.css").write_text("body { margin: 0; }", encoding="utf-8")
    (brand / "favicon.ico").write_bytes(b"\x00\x00\x01\x00")
    (brand / "favicon_32.png").write_bytes(b"\x89PNG\r\n\x1a\n")
    (brand / "logo_web_header.png").write_bytes(b"\x89PNG\r\n\x1a\n")
    return dist


def test_brand_assets_return_200(sample_dist):
    client = TestClient(_make_test_app(sample_dist))
    logo = client.get("/static/brand/logo_web_header.png")
    ico = client.get("/static/brand/favicon.ico")
    png = client.get("/static/brand/favicon_32.png")
    root_ico = client.get("/favicon.ico")
    assert logo.status_code == 200
    assert ico.status_code == 200
    assert png.status_code == 200
    assert root_ico.status_code == 200


def test_get_frontend_dist_dir_from_project_root(project_root):
    dist = get_frontend_dist_dir()
    assert dist == (project_root / "frontend" / "dist").resolve()


def test_dist_exists_root_returns_html(sample_dist):
    client = TestClient(_make_test_app(sample_dist))
    response = client.get("/")
    assert response.status_code == 200
    assert "text/html" in response.headers["content-type"]
    assert "UI" in response.text


def test_vite_assets_return_200(sample_dist):
    client = TestClient(_make_test_app(sample_dist))
    js = client.get("/assets/app.js")
    css = client.get("/assets/app.css")
    assert js.status_code == 200
    assert "javascript" in js.headers["content-type"].lower()
    assert css.status_code == 200
    assert "text/css" in css.headers["content-type"]


def test_api_health_unaffected(sample_dist):
    client = TestClient(_make_test_app(sample_dist))
    response = client.get("/api/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"


def test_unknown_api_returns_json_404_not_index(sample_dist):
    client = TestClient(_make_test_app(sample_dist))
    response = client.get("/api/not-found-route")
    assert response.status_code == 404
    content_type = response.headers.get("content-type", "")
    assert "text/html" not in content_type


def test_no_dist_startup_and_api_health(tmp_path, monkeypatch):
    missing = tmp_path / "no-dist"
    monkeypatch.setattr(
        "app.core.frontend_static.get_frontend_dist_dir",
        lambda: missing,
    )

    app = FastAPI()

    @app.get("/api/health")
    def health():
        return {"status": "ok"}

    enabled = configure_frontend_static(app)
    assert enabled is False

    @app.get("/")
    def root():
        return {"message": "Equipment Change Trace API"}

    client = TestClient(app)
    assert client.get("/api/health").status_code == 200
    assert client.get("/").json()["message"] == "Equipment Change Trace API"


def test_main_app_with_project_dist(client, project_root):
    dist = project_root / "frontend" / "dist"
    if not (dist / "index.html").is_file():
        pytest.skip("frontend/dist not built")

    response = client.get("/")
    assert response.status_code == 200
    assert "text/html" in response.headers["content-type"]

    html = (dist / "index.html").read_text(encoding="utf-8")
    js_match = re.search(r'src="(/assets/[^"]+\.js)"', html)
    css_match = re.search(r'href="(/assets/[^"]+\.css)"', html)
    assert js_match and css_match

    js_resp = client.get(js_match.group(1))
    css_resp = client.get(css_match.group(1))
    assert js_resp.status_code == 200
    assert css_resp.status_code == 200


def test_api_clients_use_same_origin_base():
    """Verify no localhost hardcoding in frontend API modules."""
    root = Path(__file__).resolve().parents[2]
    api_dir = root.parent / "frontend" / "src" / "api"
    for path in api_dir.glob("*.ts"):
        text = path.read_text(encoding="utf-8")
        assert "localhost:8010" not in text
        assert "127.0.0.1:8010" not in text
        assert 'import.meta.env.VITE_API_BASE ?? ""' in text or "VITE_API_BASE" in text
