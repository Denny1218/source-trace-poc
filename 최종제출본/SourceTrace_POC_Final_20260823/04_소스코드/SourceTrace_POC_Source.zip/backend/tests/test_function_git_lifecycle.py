"""Tests for function Git lifecycle Extension answers (STEP 9 adapter)."""

from __future__ import annotations

from app.schemas.trace import GitCandidate
from app.services import ollama_service, trace_extension_service
from app.services.change_item_candidate_service import ChangeItemCandidate
from app.services.evidence_service import EvidenceLink, EvidenceResult
from app.services.function_git_lifecycle_service import (
    analyze_function_commit,
    classify_symbol_diff,
    resolve_function_git_lifecycle,
)


FN = "card_mif_post_check_valid_birthday_usertype"


def _git(
    *,
    commit_hash: str,
    commit_date: str,
    message: str,
    commit_id: int,
    file_path: str = "card_mif.c",
) -> GitCandidate:
    return GitCandidate.model_construct(
        repository_id=1,
        repository_name="repo",
        commit_id=commit_id,
        commit_hash=commit_hash,
        commit_date=commit_date,
        message=message,
        file_path=file_path,
        score=10,
        match_reasons=["diff_symbol"],
        query_match_reasons=[],
        query_relevance_score=0,
        query_relevance_level="높음",
    )


def _item(title: str, functions: list[str] | None = None) -> ChangeItemCandidate:
    return ChangeItemCandidate(
        change_item_cache_id=1,
        document_cache_id=1,
        slide_no=2,
        file_path="doc.pptx",
        file_name="프로그램변경내역서_20210226.pptx",
        item_no="1",
        change_title=title,
        csr_no=None,
        business_background=None,
        current_status=None,
        as_is=None,
        to_be=None,
        source_functions=[
            {"file_path": "card_mif.c", "functions": list(functions or [])}
        ],
        test_cases=[],
        applicable_scopes=[],
        raw_text=title,
        matched_keywords=[],
        candidate_score=1,
    )


def _evidence(links: list, gits: list) -> EvidenceResult:
    return EvidenceResult(
        equipment_id=1,
        query=f"{FN} 변경 이력",
        query_keywords=[],
        weak_query_terms=[],
        request_functions=[FN],
        request_files=["card_mif.c"],
        path_scopes=[],
        git_candidates=gits,
        change_item_candidates=[],
        evidence_links=links,
        change_item_link_candidate_count=0,
        fallback_documents_parsed=0,
        change_item_total=0,
    )


def _git_change_record(diff: str | None) -> dict | None:
    if diff is None:
        return None
    return {
        "id": 1,
        "commit_id": 1,
        "file_path": "card_mif.c",
        "diff": diff,
        "additions": 1,
        "deletions": 1,
        "change_type": "modified",
    }


def _patch_git_records(monkeypatch, records: dict) -> None:
    def _resolve(commit_id, file_path, **kwargs):
        rec = records.get((commit_id, file_path))
        if rec:
            return rec, "exact_git_change"
        return None, "unavailable"

    monkeypatch.setattr(
        "app.services.function_git_lifecycle_service.resolve_git_change_record",
        _resolve,
    )
    monkeypatch.setattr(
        "app.services.function_git_lifecycle_service.fetch_symbol_git_rows",
        lambda *a, **k: [],
    )


def test_classify_whole_function_add_as_creation():
    diff = "\n".join(
        [
            f"+int {FN}(int a)",
            "+{",
            "+    if (a > 0) {",
            "+        return 1;",
            "+    }",
            "+    return 0;",
            "+}",
        ]
    )
    change_type, _summary, priority = classify_symbol_diff(diff, FN)
    assert change_type in {"function_creation", "function_creation_estimated"}
    assert priority >= 95


def test_body_change_not_creation_when_parent_has_function():
    creation_diff = "\n".join(
        [f"+void {FN}(void)", "+{", "+    return;", "+    x++;", "+}"]
    )
    body_diff = "\n".join(
        [
            f" void {FN}(void)",
            " {",
            "-    user_type = ADULT;",
            "+    user_type = TEEN;",
            " }",
        ]
    )
    ct_create, _, _, _, _ = analyze_function_commit(
        diff=creation_diff,
        symbol=FN,
        message="add",
        parent_has_function=False,
        diff_available=True,
    )
    ct_body, desc, conf, reason, is_core = analyze_function_commit(
        diff=body_diff,
        symbol=FN,
        message="card usertype",
        parent_has_function=True,
        diff_available=True,
    )
    assert ct_create == "function_creation"
    assert ct_body != "function_creation"
    assert ct_body in {"body_change", "card_type_setting", "branch_change"}
    assert "키워드" not in desc
    assert is_core is True


def test_only_one_creation_in_lifecycle(monkeypatch):
    creation = _git(
        commit_hash="aaaa1111111111",
        commit_date="2020-05-01T10:00:00+09:00",
        message="청소년 후불 적용 카드라이브러리",
        commit_id=10,
    )
    followup = _git(
        commit_hash="bbbb2222222222",
        commit_date="2020-06-01T10:00:00+09:00",
        message="카드 유저타입 설정 변경",
        commit_id=20,
    )
    creation_diff = "\n".join(
        [f"+void {FN}(void)", "+{", "+    return;", "+    x++;", "+}"]
    )
    # Would be misclassified as creation without parent check — only + lines
    follow_diff = "\n".join(
        [
            f"+void {FN}(void)",
            "+{",
            "+    user_type = TEEN;",
            "+    return;",
            "+}",
        ]
    )
    records = {
        (10, "card_mif.c"): _git_change_record(creation_diff),
        (20, "card_mif.c"): _git_change_record(follow_diff),
    }

    monkeypatch.setattr(
        "app.services.function_git_lifecycle_service.ancestor_file_has_function_definition",
        lambda cid, path, sym: True if cid == 20 else False,
    )
    _patch_git_records(monkeypatch, records)

    lifecycle = resolve_function_git_lifecycle(_evidence([], [creation, followup]), FN)
    creations = [
        e
        for e in lifecycle.entries
        if e.change_type in {"function_creation", "function_creation_estimated"}
    ]
    assert len(creations) == 1
    assert creations[0].commit_hash.startswith("aaaa")


def test_distinct_diff_summaries_per_commit(monkeypatch):
    g1 = _git(
        commit_hash="aaaa1111111111",
        commit_date="2020-05-01T10:00:00+09:00",
        message="add lib",
        commit_id=10,
    )
    g2 = _git(
        commit_hash="bbbb2222222222",
        commit_date="2020-06-01T10:00:00+09:00",
        message="usertype tweak",
        commit_id=20,
    )
    d1 = "\n".join([f"+void {FN}(void)", "+{", "+ return;", "+ a;", "+}"])
    d2 = "\n".join(
        [
            f" void {FN}(void)",
            " {",
            "-    user_type = ADULT;",
            "+    user_type = TEEN;",
            " }",
        ]
    )
    records = {
        (10, "card_mif.c"): _git_change_record(d1),
        (20, "card_mif.c"): _git_change_record(d2),
    }
    monkeypatch.setattr(
        "app.services.function_git_lifecycle_service.ancestor_file_has_function_definition",
        lambda cid, path, sym: cid == 20,
    )
    _patch_git_records(monkeypatch, records)

    lifecycle = resolve_function_git_lifecycle(_evidence([], [g1, g2]), FN)
    assert lifecycle.entries[0].change_description != lifecycle.entries[1].change_description
    text = lifecycle.document_text
    assert "관련 Diff 라인 확인" not in text
    assert "키워드 일치" not in text


def test_feature_doc_attaches_even_without_exact_hash_pair(monkeypatch):
    """Apply-era docs attach without hash; delete-era docs do not become creation release proof."""
    later = _git(
        commit_hash="cccc3333333333",
        commit_date="2021-12-10T10:00:00+09:00",
        message="날짜 하드코딩 부분 삭제",
        commit_id=30,
    )
    creation = _git(
        commit_hash="aaaa1111111111",
        commit_date="2020-05-01T10:00:00+09:00",
        message="add",
        commit_id=10,
    )
    apply_item = _item("청소년 후불카드 적용", functions=[FN])
    apply_item.file_name = "프로그램변경내역서_20200501_V129.pptx"
    apply_item.file_path = apply_item.file_name
    delete_item = _item("후불 청소년 카드 날짜비교 로직 삭제", functions=[FN])
    delete_item.file_name = "프로그램변경내역서_20211218_V225.pptx"
    delete_item.file_path = delete_item.file_name
    delete_item.change_item_cache_id = 2
    link = EvidenceLink(
        git_candidate=later,
        change_item=delete_item,
        link_score=90,
    )
    d_create = "\n".join([f"+void {FN}(void)", "+{", "+ return;", "+ x;", "+}"])
    d_later = f" {FN}()\n- if (date == HARDCODED) {{\n+ {{\n"
    records = {
        (10, "card_mif.c"): _git_change_record(d_create),
        (30, "card_mif.c"): _git_change_record(d_later),
    }
    monkeypatch.setattr(
        "app.services.function_git_lifecycle_service.ancestor_file_has_function_definition",
        lambda cid, path, sym: cid != 10,
    )
    monkeypatch.setattr(
        "app.services.change_item_cache_service.list_change_items_for_equipment",
        lambda *a, **k: [],
    )
    _patch_git_records(monkeypatch, records)

    er = _evidence([link], [creation, later])
    er.change_item_candidates = [apply_item, delete_item]
    lifecycle = resolve_function_git_lifecycle(er, FN)
    by_hash = {e.commit_hash[:4]: e for e in lifecycle.entries}
    if by_hash["aaaa"].ppt_link is not None:
        assert by_hash["aaaa"].ppt_link.change_action != "delete"
        assert by_hash["aaaa"].ppt_link_level in {"direct", "indirect"}
    assert "주요 기능: 후불 청소년" not in lifecycle.document_text
    assert lifecycle.debug["lifecycle_summary"]["ppt_official_doc_count"] >= 1



def test_log_commit_not_direct_ppt_for_unrelated_title(monkeypatch):
    log_git = _git(
        commit_hash="dddd4444444444",
        commit_date="2021-04-01T10:00:00+09:00",
        message="테스트 로그 삭제",
        commit_id=40,
    )
    link = EvidenceLink(
        git_candidate=log_git,
        change_item=_item("후불 청소년 카드 날짜비교 로직 삭제", functions=[FN]),
        link_score=90,
    )
    diff = f" {FN}()\n-    printf(\"test\");\n+\n"
    monkeypatch.setattr(
        "app.services.function_git_lifecycle_service.ancestor_file_has_function_definition",
        lambda *a, **k: True,
    )
    _patch_git_records(monkeypatch, {(40, "card_mif.c"): _git_change_record(diff)})

    lifecycle = resolve_function_git_lifecycle(_evidence([link], [log_git]), FN)
    entry = lifecycle.entries[0]
    assert entry.change_type == "comment_or_log"
    assert entry.ppt_link_level in {"indirect", "none"}
    assert entry.ppt_link_level != "direct"


def test_markdown_lifecycle_format_and_confidence(monkeypatch):
    creation = _git(
        commit_hash="aaaa1111111111",
        commit_date="2020-05-01T10:00:00+09:00",
        message="add",
        commit_id=10,
    )
    later = _git(
        commit_hash="bbbb2222222222",
        commit_date="2021-03-01T10:00:00+09:00",
        message="change",
        commit_id=20,
    )
    records = {
        (10, "card_mif.c"): _git_change_record(
            "\n".join([f"+void {FN}(void)", "+{", "+ return;", "+ x;", "+}"])
        ),
        (20, "card_mif.c"): _git_change_record(f" {FN}()\n-old\n+new\n"),
    }
    monkeypatch.setattr(
        "app.services.function_git_lifecycle_service.ancestor_file_has_function_definition",
        lambda cid, path, sym: cid == 20,
    )
    _patch_git_records(monkeypatch, records)

    analysis = ollama_service.OllamaAnalysisResult(
        ai_available=False,
        summary="x",
        reason=None,
        confidence="high",
        inference=False,
        answer="x",
        answer_status="ok",
        evidence_refs=[],
        evidence_summary="x",
        evidence_answer="x",
        evidence_reason=None,
        ai_answer=None,
        ai_used=False,
    )
    md, dbg = trace_extension_service.build_markdown_answer(
        _evidence([], [creation, later]),
        analysis,
        use_ollama=False,
        primary_symbol=FN,
        file_path="card_mif.c",
    )
    assert f"# {FN} 변경 이력" in md
    assert "## 한눈에 보기" in md
    assert "## 변경 이력" in md
    assert "## 변경 상세" in md
    assert "## 관련 문서" in md
    assert "### 초기 개발 및 주요 기능 변경" not in md
    assert "### 개발 및 보조 변경" not in md
    assert "주요 개발" not in md
    assert "분석 신뢰도" not in md
    assert "## 확인 필요 후보" not in md
    assert "### 1. 확인 필요" not in md
    assert "aaaa" in md and "bbbb" in md
    assert dbg.get("final_history_count") == 2


def test_user_markdown_has_no_internal_keyword_label():
    _ct, desc, _, _, _ = analyze_function_commit(
        diff=None,
        symbol=FN,
        message=f"touch {FN}",
        parent_has_function=None,
        diff_available=False,
    )
    assert "키워드 일치" not in desc
    assert "함수 정의 미확인" not in desc


def test_reclassified_creation_regenerates_body_description(monkeypatch):
    creation = _git(
        commit_hash="822e92eaaaaaaa1",
        commit_date="2020-05-01T10:00:00+09:00",
        message="청소년 후불 적용",
        commit_id=10,
    )
    followup = _git(
        commit_hash="6d427d2bbbbbbb2",
        commit_date="2020-06-01T10:00:00+09:00",
        message="카드 유저타입 설정 변경",
        commit_id=20,
    )
    creation_diff = "\n".join(
        [f"+void {FN}(void)", "+{", "+    return;", "+    x++;", "+}"]
    )
    body_diff = "\n".join(
        [
            f" void {FN}(void)",
            " {",
            "-    user_type = ADULT;",
            "+    user_type = TEEN;",
            " }",
        ]
    )
    records = {
        (10, "card_mif.c"): _git_change_record(creation_diff),
        (20, "card_mif.c"): _git_change_record(body_diff),
    }
    monkeypatch.setattr(
        "app.services.function_git_lifecycle_service.ancestor_file_has_function_definition",
        lambda cid, path, sym: True if cid == 20 else False,
    )
    _patch_git_records(monkeypatch, records)

    lifecycle = resolve_function_git_lifecycle(_evidence([], [creation, followup]), FN)
    demoted = next(e for e in lifecycle.entries if e.commit_hash.startswith("6d427d2"))
    assert demoted.change_type in {"body_change", "card_type_setting", "branch_change"}
    assert "함수 원형과 구현이 새로 추가" not in demoted.change_description
    assert "최초 추가 후보" not in lifecycle.document_text
    assert "카드 사용자 유형" in demoted.change_description or "기존 함수 내부" in demoted.change_description


def test_symbol_not_in_diff_no_contradictory_description():
    _ct, desc, _, reason, _ = analyze_function_commit(
        diff="@@\n-old line\n+new line\n",
        symbol=FN,
        message="unrelated",
        parent_has_function=None,
        diff_available=True,
    )
    assert reason == "symbol_not_in_diff"
    assert "Diff에 있으나" not in desc
    assert "직접 변경을 확인하지 못했습니다" in desc


def test_message_topic_not_used_when_diff_lacks_symbol():
    """Diff available but no symbol → do not promote Commit-message topic."""
    ct, _desc, _conf, reason, is_core = analyze_function_commit(
        diff="@@\n-other_fn();\n+another_fn();\n",
        symbol=FN,
        message="재승차 10분 환승 판정 개선",
        parent_has_function=True,
        diff_available=True,
    )
    assert ct == "related_candidate"
    assert reason == "symbol_not_in_diff"
    assert is_core is False


def test_lifecycle_excludes_message_only_false_positive(monkeypatch):
    """Same-file unrelated Diff + business message must not enter function history."""
    creation = _git(
        commit_hash="crea11111111111",
        commit_date="2020-01-01T10:00:00+09:00",
        message="add fn",
        commit_id=1,
    )
    fp = _git(
        commit_hash="fals22222222222",
        commit_date="2020-02-01T10:00:00+09:00",
        message="재승차 10분 환승 판정 개선",
        commit_id=2,
    )
    records = {
        (1, "card_mif.c"): _git_change_record(
            "\n".join([f"+void {FN}(void)", "+{", "+ return;", "+}", "+x;"])
        ),
        (2, "card_mif.c"): _git_change_record("@@\n-other();\n+another();\n"),
    }
    monkeypatch.setattr(
        "app.services.function_git_lifecycle_service.ancestor_file_has_function_definition",
        lambda cid, path, sym: cid != 1,
    )
    _patch_git_records(monkeypatch, records)
    lifecycle = resolve_function_git_lifecycle(_evidence([], [creation, fp]), FN)
    hashes = {e.commit_hash for e in lifecycle.entries}
    assert any(h.startswith("crea") for h in hashes)
    assert not any(h.startswith("fals") for h in hashes)
    assert any(
        x.get("reason") == "symbol_not_in_diff"
        for x in lifecycle.debug.get("excluded_commits") or []
    )


def test_lifecycle_keeps_symbol_in_diff_even_if_message_topic(monkeypatch):
    """Symbol/alias in Diff (body scope unclear) must stay — not message-only drop."""
    git = _git(
        commit_hash="sym33333333333",
        commit_date="2020-03-01T10:00:00+09:00",
        message="재승차 10분 환승 판정 개선",
        commit_id=3,
    )
    # Symbol appears in Diff (call/mention) without confirmed function-body hunk.
    diff = "\n".join(
        [
            "@@ void helper(void) @@",
            " void helper(void)",
            " {",
            f"+    {FN}();",
            " }",
        ]
    )
    _patch_git_records(monkeypatch, {(3, "card_mif.c"): _git_change_record(diff)})
    monkeypatch.setattr(
        "app.services.function_git_lifecycle_service.ancestor_file_has_function_definition",
        lambda *a, **k: True,
    )
    lifecycle = resolve_function_git_lifecycle(_evidence([], [git]), FN)
    assert any(e.commit_hash.startswith("sym") for e in lifecycle.entries)
    assert not any(
        x.get("commit_hash", "").startswith("sym")
        for x in lifecycle.debug.get("excluded_commits") or []
    )


def test_symbol_in_diff_scope_unknown_message():
    diff = "\n".join(
        [
            f"@@ void {FN}(void) @@",
            f" void {FN}(void)",
            " {",
            "-    old_logic();",
            "+    new_logic();",
            " }",
        ]
    )
    _ct, desc, _, reason, _ = analyze_function_commit(
        diff=diff,
        symbol=FN,
        message="change",
        parent_has_function=True,
        diff_available=True,
    )
    if reason == "symbol_in_diff_scope_unknown":
        assert "본문 변경 여부" in desc
    else:
        assert _ct in {"body_change", "card_type_setting", "branch_change"}


def test_f355272_style_body_change_not_symbol_not_in_diff(monkeypatch):
    body_git = _git(
        commit_hash="f355272ccccccc3",
        commit_date="2021-01-15T10:00:00+09:00",
        message="카드 유형 판정 로직 수정",
        commit_id=30,
        file_path="mif_post/src/card_mif_postpay.c",
    )
    body_diff = "\n".join(
        [
            f"@@ void {FN}(int x) @@",
            f" void {FN}(int x)",
            " {",
            "-    if (card_type == TEEN) {",
            "+    if (card_type == TEEN || card_type == CHILD) {",
            "         return 1;",
            "     }",
            " }",
        ]
    )
    records = {
        (30, "mif_post/src/card_mif_postpay.c"): {
            **_git_change_record(body_diff),
            "file_path": "mif_post/src/card_mif_postpay.c",
        }
    }
    monkeypatch.setattr(
        "app.services.function_git_lifecycle_service.ancestor_file_has_function_definition",
        lambda *a, **k: True,
    )
    _patch_git_records(monkeypatch, records)

    lifecycle = resolve_function_git_lifecycle(
        _evidence([], [body_git]), FN, file_path="mif_post/src/card_mif_postpay.c"
    )
    entry = lifecycle.entries[0]
    assert entry.debug_item.get("classification_reason") != "symbol_not_in_diff"
    assert entry.section == "core"
    assert entry.change_type in {"body_change", "card_type_setting", "branch_change"}


def test_merge_commit_excluded_without_function_change(monkeypatch):
    merge_git = _git(
        commit_hash="6bfc8b9ddddddd4",
        commit_date="2021-02-26T12:00:00+09:00",
        message="Merge branch 'feature' into main",
        commit_id=40,
    )
    diff = "@@\n-unrelated();\n+other();\n"
    _patch_git_records(monkeypatch, {(40, "card_mif.c"): _git_change_record(diff)})
    monkeypatch.setattr(
        "app.services.function_git_lifecycle_service.ancestor_file_has_function_definition",
        lambda *a, **k: True,
    )

    lifecycle = resolve_function_git_lifecycle(_evidence([], [merge_git]), FN)
    assert len(lifecycle.entries) == 0
    assert any(
        e.get("reason") == "merge_no_function_change" for e in lifecycle.excluded
    )


def test_merge_commit_kept_with_function_body_change(monkeypatch):
    merge_git = _git(
        commit_hash="6bfc8b9eeeeeee5",
        commit_date="2021-02-26T12:00:00+09:00",
        message="Merge branch 'feature' into main",
        commit_id=50,
    )
    diff = "\n".join(
        [
            f" void {FN}(void)",
            " {",
            "-    user_type = ADULT;",
            "+    user_type = TEEN;",
            " }",
        ]
    )
    _patch_git_records(monkeypatch, {(50, "card_mif.c"): _git_change_record(diff)})
    monkeypatch.setattr(
        "app.services.function_git_lifecycle_service.ancestor_file_has_function_definition",
        lambda *a, **k: True,
    )

    lifecycle = resolve_function_git_lifecycle(_evidence([], [merge_git]), FN)
    assert len(lifecycle.entries) == 1
    assert lifecycle.entries[0].section == "core"


def test_lifecycle_summary_counts_match_sections(monkeypatch):
    creation = _git(
        commit_hash="aaaa1111111111",
        commit_date="2020-05-01T10:00:00+09:00",
        message="add",
        commit_id=10,
    )
    body = _git(
        commit_hash="bbbb2222222222",
        commit_date="2020-06-01T10:00:00+09:00",
        message="change",
        commit_id=20,
    )
    unconf = _git(
        commit_hash="cccc3333333333",
        commit_date="2020-07-01T10:00:00+09:00",
        message="touch file",
        commit_id=30,
    )
    records = {
        (10, "card_mif.c"): _git_change_record(
            "\n".join([f"+void {FN}(void)", "+{", "+ return;", "+ x;", "+}"])
        ),
        (20, "card_mif.c"): _git_change_record(
            "\n".join(
                [
                    f" void {FN}(void)",
                    " {",
                    "- old",
                    "+ new",
                    " }",
                ]
            )
        ),
        (30, "card_mif.c"): _git_change_record("@@\n-other();\n+another();\n"),
    }
    monkeypatch.setattr(
        "app.services.function_git_lifecycle_service.ancestor_file_has_function_definition",
        lambda cid, path, sym: cid != 10,
    )
    _patch_git_records(monkeypatch, records)

    lifecycle = resolve_function_git_lifecycle(_evidence([], [creation, body, unconf]), FN)
    summary = lifecycle.debug["lifecycle_summary"]
    core_n = sum(1 for e in lifecycle.entries if e.section == "core")
    other_n = sum(1 for e in lifecycle.entries if e.section == "other")
    unconf_n = sum(1 for e in lifecycle.entries if e.section == "unconfirmed")
    assert summary["creation_count"] + summary["core_followup_count"] == core_n
    assert summary["other_count"] == other_n
    assert summary["unconfirmed_count"] == unconf_n
    assert summary["direct_confirmed_count"] == core_n + other_n


def test_reboarding_commit_not_classified_as_card_type():
    """PROJECT_SPEC v2.4 §9 — a reboarding/transfer commit must not be mislabeled
    as a card-usertype change just because the same function/diff happens to
    contain unrelated usertype tokens elsewhere."""
    diff = "\n".join(
        [
            f" bool {FN}(void)",
            " {",
            "-    if (elapsed > TEN_MIN) return false;",
            "+    if (elapsed > FIFTEEN_MIN) return false;",
            "     user_type = ADULT;",
            " }",
        ]
    )
    change_type, desc, _conf, _reason, _is_core = analyze_function_commit(
        diff=diff,
        symbol=FN,
        message="15분 재승차 시간 변경 및 기관 추가",
        parent_has_function=True,
        diff_available=True,
    )
    assert change_type != "card_type_setting"
    assert change_type != "date_logic_change"
    assert change_type == "transfer_reboarding_change"
    assert "카드" not in desc


def test_reboarding_time_institution_change_generic_label():
    change_type, desc, _conf, reason, is_core = analyze_function_commit(
        diff=None,
        symbol=FN,
        message="10분 재승차 시간 변경 및 기관 추가",
        parent_has_function=None,
        diff_available=False,
    )
    assert change_type == "transfer_reboarding_change"
    assert reason == "message_topic"
    assert is_core is False  # v2.5: message-only → 연관 Git 이력
    assert "환승" in desc or "재승차" in desc


def test_climate_penalty_condition_not_classified_as_birthday():
    """PROJECT_SPEC v2.4 §9 — climate-card penalty condition changes must not be
    mislabeled as a birthday/date-of-birth comparison change."""
    diff = "\n".join(
        [
            f" bool {FN}(void)",
            " {",
            "-    if (init_flag == CLEAR_PENALTY_OLD) return false;",
            "+    if (init_flag == CLIMATE_CLEAR_PENALTY) return false;",
            " }",
        ]
    )
    change_type, desc, _conf, _reason, _is_core = analyze_function_commit(
        diff=diff,
        symbol=FN,
        message="기후동행 후불카드 추가",
        parent_has_function=True,
        diff_available=True,
    )
    assert change_type != "date_logic_change"
    assert change_type == "climate_condition_change"
    assert "생년월일" not in desc


def test_diff_unavailable_uses_conservative_wording_when_no_topic():
    change_type, desc, conf, reason, is_core = analyze_function_commit(
        diff=None,
        symbol=FN,
        message="O&M 현행화",
        parent_has_function=None,
        diff_available=False,
    )
    assert change_type == "diff_unavailable"
    assert reason == "diff_unavailable"
    assert conf == "low"
    assert is_core is False
    assert "카드" not in desc
    assert "생년월일" not in desc


def test_generic_date_word_alone_does_not_trigger_birthday_classification():
    """A bare '날짜'/'date'/'비교' token (e.g. from an unrelated adjacent
    condition) must not be enough to classify a change as a birthday/date
    comparison — only birthday-specific tokens should (PROJECT_SPEC v2.4 §9)."""
    diff = "\n".join(
        [
            f" bool {FN}(void)",
            " {",
            "-    if (compare_date(a, b) > 0) return false;",
            "+    if (compare_date(a, b) >= 0) return false;",
            " }",
        ]
    )
    change_type, _desc, _conf, _reason, _is_core = analyze_function_commit(
        diff=diff,
        symbol=FN,
        message="적용일 비교 조건 조정",
        parent_has_function=True,
        diff_available=True,
    )
    assert change_type != "date_logic_change"


def test_diff_topic_wins_over_conflicting_commit_message():
    """PROJECT_SPEC v2.4 §10.3 — when Diff and Commit message imply different
    change nature, the function-scoped Diff must win."""
    diff = "\n".join(
        [
            f" bool {FN}(void)",
            " {",
            "-    if (init_flag == CLEAR_PENALTY_OLD) return false;",
            "+    if (init_flag == CLIMATE_CLEAR_PENALTY) return false;",
            " }",
        ]
    )
    change_type, desc, _conf, _reason, _is_core = analyze_function_commit(
        diff=diff,
        symbol=FN,
        message="청소년 카드 유형 설정 변경",
        parent_has_function=True,
        diff_available=True,
    )
    assert change_type == "climate_condition_change"
    assert change_type != "card_type_setting"
    assert "기후동행" in desc or "climate" in desc.lower() or "패널티" in desc


def test_user_markdown_has_no_internal_enums(monkeypatch):
    creation = _git(
        commit_hash="aaaa1111111111",
        commit_date="2020-05-01T10:00:00+09:00",
        message="add",
        commit_id=10,
    )
    _patch_git_records(
        monkeypatch,
        {
            (10, "card_mif.c"): _git_change_record(
                "\n".join([f"+void {FN}(void)", "+{", "+ return;", "+ x;", "+}"])
            )
        },
    )
    monkeypatch.setattr(
        "app.services.function_git_lifecycle_service.ancestor_file_has_function_definition",
        lambda *a, **k: False,
    )
    lifecycle = resolve_function_git_lifecycle(_evidence([], [creation]), FN)
    text = lifecycle.document_text
    for forbidden in (
        "symbol_not_in_diff",
        "weak_overlap",
        "keyword_only",
        "fn_in_item",
        "demoted_duplicate_creation",
    ):
        assert forbidden not in text
