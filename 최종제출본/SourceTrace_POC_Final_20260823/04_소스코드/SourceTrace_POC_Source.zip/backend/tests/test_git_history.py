import pytest

from app.schemas.git_history import MAX_PAGE_SIZE, normalize_page_size
from app.schemas.git_history import CommitSearchParams
from app.services.git_history_service import get_commit_detail, search_commits
from tests.conftest import register_equipment_with_repo


@pytest.fixture
def synced_device_a(client, registered_device_a):
    equipment_id = registered_device_a["id"]
    response = client.post(f"/api/equipment/{equipment_id}/sync/git")
    assert response.status_code == 200
    return registered_device_a


@pytest.fixture
def two_equipment_same_commit_hashes(client, isolated_device_a_repo, project_root, tmp_path):
    """동일 .git 복사로 equipment A/B에 같은 commit_hash 생성."""
    import shutil

    repo2 = tmp_path / "repo-copy"
    shutil.copytree(isolated_device_a_repo, repo2)

    docs_a = project_root / "tests" / "test-data" / "device-a" / "documents"
    docs_b = project_root / "tests" / "test-data" / "device-b" / "documents"

    from tests.conftest import local_path_to_test_unc

    eq_a = register_equipment_with_repo(
        client,
        {
            "name": "SAME_HASH_A",
            "git_path": str(isolated_device_a_repo),
            "document_path": local_path_to_test_unc(docs_a),
        },
        "repo_a",
    )
    eq_b = register_equipment_with_repo(
        client,
        {
            "name": "SAME_HASH_B",
            "git_path": str(repo2),
            "document_path": local_path_to_test_unc(docs_b),
        },
        "repo_b",
    )

    client.post(f"/api/equipment/{eq_a['id']}/sync/git")
    client.post(f"/api/equipment/{eq_b['id']}/sync/git")
    return eq_a, eq_b


def test_list_commits(synced_device_a, client):
    eid = synced_device_a["id"]
    response = client.get(f"/api/equipment/{eid}/git/commits")
    assert response.status_code == 200
    data = response.json()
    assert data["total"] == 5
    assert len(data["items"]) == 5
    assert data["page"] == 1


def test_list_commits_sorted_by_date_desc(synced_device_a, client):
    eid = synced_device_a["id"]
    data = client.get(f"/api/equipment/{eid}/git/commits").json()
    dates = [item["commit_date"] for item in data["items"]]
    assert dates == sorted(dates, reverse=True)


def test_pagination(synced_device_a, client):
    eid = synced_device_a["id"]
    data = client.get(
        f"/api/equipment/{eid}/git/commits", params={"page": 1, "page_size": 2}
    ).json()
    assert len(data["items"]) == 2
    assert data["total"] == 5
    assert data["total_pages"] == 3

    page2 = client.get(
        f"/api/equipment/{eid}/git/commits", params={"page": 2, "page_size": 2}
    ).json()
    assert len(page2["items"]) == 2
    assert page2["page"] == 2


def test_page_size_max_limit():
    assert normalize_page_size(500) == MAX_PAGE_SIZE


def test_search_child_fare(synced_device_a, client):
    eid = synced_device_a["id"]
    data = client.get(
        f"/api/equipment/{eid}/git/commits", params={"q": "CHILD_FARE"}
    ).json()
    assert data["total"] >= 1
    assert all(
        "CHILD_FARE" in item["message"]
        or True  # matched via diff
        for item in data["items"]
    )
    # At least one result from FareCalc diff
    assert len(data["items"]) >= 1


def test_search_calcfare(synced_device_a, client):
    eid = synced_device_a["id"]
    data = client.get(
        f"/api/equipment/{eid}/git/commits", params={"q": "CalcFare"}
    ).json()
    assert data["total"] >= 1


def test_search_korean_message(synced_device_a, client):
    eid = synced_device_a["id"]
    data = client.get(
        f"/api/equipment/{eid}/git/commits", params={"q": "어린이 카드"}
    ).json()
    assert data["total"] >= 1
    assert any("어린이" in item["message"] for item in data["items"])


def test_filter_file_path(synced_device_a, client):
    eid = synced_device_a["id"]
    data = client.get(
        f"/api/equipment/{eid}/git/commits", params={"file_path": "FareCalc.c"}
    ).json()
    assert data["total"] >= 1


def test_filter_author(synced_device_a, client):
    eid = synced_device_a["id"]
    all_data = client.get(f"/api/equipment/{eid}/git/commits").json()
    author = all_data["items"][0]["author"]
    data = client.get(
        f"/api/equipment/{eid}/git/commits", params={"author": author}
    ).json()
    assert data["total"] >= 1


def test_filter_date_range(synced_device_a, client):
    eid = synced_device_a["id"]
    all_items = client.get(f"/api/equipment/{eid}/git/commits").json()["items"]
    mid_date = sorted(i["commit_date"] for i in all_items)[2]
    data = client.get(
        f"/api/equipment/{eid}/git/commits",
        params={"date_from": mid_date, "date_to": mid_date},
    ).json()
    assert data["total"] >= 1
    for item in data["items"]:
        assert item["commit_date"] >= mid_date
        assert item["commit_date"] <= mid_date


def test_no_duplicate_commits_on_join_search(synced_device_a, client):
    eid = synced_device_a["id"]
    data = client.get(f"/api/equipment/{eid}/git/commits").json()
    ids = [item["id"] for item in data["items"]]
    assert len(ids) == len(set(ids))


def test_total_accuracy_with_search(synced_device_a, client):
    eid = synced_device_a["id"]
    data = client.get(
        f"/api/equipment/{eid}/git/commits", params={"q": "FareCalc"}
    ).json()
    assert data["total"] == len(data["items"]) or data["total_pages"] > 1
    assert data["total"] >= 1


def test_commit_detail(synced_device_a, client):
    eid = synced_device_a["id"]
    items = client.get(f"/api/equipment/{eid}/git/commits").json()["items"]
    commit_id = items[0]["id"]
    response = client.get(f"/api/git/commits/{commit_id}")
    assert response.status_code == 200
    detail = response.json()
    assert detail["id"] == commit_id
    assert detail["equipment_id"] == eid
    assert "changes" in detail
    assert len(detail["changes"]) >= 1


def test_commit_detail_not_found(client):
    response = client.get("/api/git/commits/99999")
    assert response.status_code == 404


def test_equipment_not_found(client):
    response = client.get("/api/equipment/99999/git/commits")
    assert response.status_code == 404


def test_same_commit_hash_different_equipment_detail(
    two_equipment_same_commit_hashes, client
):
    eq_a, eq_b = two_equipment_same_commit_hashes

    list_a = client.get(f"/api/equipment/{eq_a['id']}/git/commits").json()["items"]
    list_b = client.get(f"/api/equipment/{eq_b['id']}/git/commits").json()["items"]

    hash_a = {item["commit_hash"]: item["id"] for item in list_a}
    hash_b = {item["commit_hash"]: item["id"] for item in list_b}

    common = set(hash_a.keys()) & set(hash_b.keys())
    assert len(common) >= 1

    shared_hash = next(iter(common))
    id_a = hash_a[shared_hash]
    id_b = hash_b[shared_hash]
    assert id_a != id_b

    detail_a = client.get(f"/api/git/commits/{id_a}").json()
    detail_b = client.get(f"/api/git/commits/{id_b}").json()

    assert detail_a["commit_hash"] == detail_b["commit_hash"]
    assert detail_a["equipment_id"] == eq_a["id"]
    assert detail_b["equipment_id"] == eq_b["id"]
    assert detail_a["id"] != detail_b["id"]


def test_search_service_direct(synced_device_a):
    eid = synced_device_a["id"]
    result = search_commits(CommitSearchParams(equipment_id=eid, q="CHILD_FARE"))
    assert result.total >= 1

    detail = get_commit_detail(result.items[0].id)
    assert detail is not None
