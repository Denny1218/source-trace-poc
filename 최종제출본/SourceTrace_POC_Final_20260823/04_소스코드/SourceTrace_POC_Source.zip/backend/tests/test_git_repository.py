"""Tests for Git Repository 1:N model, migration, and validation."""

from pathlib import Path
from unittest.mock import patch

import pytest

from app.db.database import get_connection, init_database
from app.services.git_url_utils import mask_repository_url
from app.services.path_validation_service import validate_document_path
from tests.conftest import (
    count_commits_for_equipment,
    equipment_payload,
    register_equipment,
    register_equipment_with_repo,
    register_local_repository,
)


def test_migrate_legacy_git_path_to_repository(tmp_path, monkeypatch, device_a_paths):
    db_path = tmp_path / "legacy.db"
    monkeypatch.setattr("app.db.database.DATABASE_PATH", str(db_path))

    from app.db.migrations import MIGRATIONS

    conn = get_connection()
    try:
        for sql in MIGRATIONS:
            conn.execute(sql)
        conn.commit()
        conn.execute(
            """
            INSERT INTO equipment (name, git_path, document_path, created_at, updated_at)
            VALUES ('LEGACY', ?, ?, '2024-01-01T00:00:00+00:00', '2024-01-01T00:00:00+00:00')
            """,
            (device_a_paths["git_path"], device_a_paths["document_path"]),
        )
        equipment_id = conn.execute(
            "SELECT id FROM equipment WHERE name = 'LEGACY'"
        ).fetchone()["id"]
        conn.execute(
            """
            INSERT INTO git_commit
                (equipment_id, commit_hash, commit_date, author, message, parent_hash)
            VALUES (?, 'abc123', '2024-01-01T00:00:00+00:00', 'A', 'legacy', NULL)
            """,
            (equipment_id,),
        )
        conn.commit()
    finally:
        conn.close()

    init_database()

    conn = get_connection()
    try:
        repo = conn.execute(
            "SELECT * FROM git_repository WHERE equipment_id = ?",
            (equipment_id,),
        ).fetchone()
        assert repo is not None
        assert repo["source_type"] == "local"
        assert repo["local_path"] == device_a_paths["git_path"]

        commit = conn.execute(
            "SELECT repository_id FROM git_commit WHERE commit_hash = 'abc123'"
        ).fetchone()
        assert commit["repository_id"] == repo["id"]
    finally:
        conn.close()


def test_repository_crud_multiple_per_equipment(client, device_a_paths, device_b_paths):
    equipment = register_equipment(client, device_a_paths)
    repo1 = register_local_repository(
        client, equipment["id"], "card", device_a_paths["git_path"]
    )
    repo2 = register_local_repository(
        client, equipment["id"], "comm", device_b_paths["git_path"]
    )
    assert repo1["name"] == "card"
    assert repo2["name"] == "comm"

    listed = client.get(f"/api/equipment/{equipment['id']}/repositories").json()
    assert len(listed) == 2

    dup = client.post(
        f"/api/equipment/{equipment['id']}/repositories",
        json={
            "name": "card",
            "source_type": "local",
            "local_path": device_a_paths["git_path"],
        },
    )
    assert dup.status_code == 409

    other = register_equipment(client, device_b_paths)
    ok = client.post(
        f"/api/equipment/{other['id']}/repositories",
        json={
            "name": "card",
            "source_type": "local",
            "local_path": device_b_paths["git_path"],
        },
    )
    assert ok.status_code == 201

    deleted = client.delete(f"/api/repositories/{repo2['id']}")
    assert deleted.status_code == 204
    listed2 = client.get(f"/api/equipment/{equipment['id']}/repositories").json()
    assert len(listed2) == 1


def test_repository_filter_in_git_history(synced_device_a, client):
    eid = synced_device_a["id"]
    repos = client.get(f"/api/equipment/{eid}/repositories").json()
    repo_id = repos[0]["id"]
    all_data = client.get(f"/api/equipment/{eid}/git/commits").json()
    filtered = client.get(
        f"/api/equipment/{eid}/git/commits", params={"repository_id": repo_id}
    ).json()
    assert filtered["total"] == all_data["total"]
    assert all(item["repository_name"] for item in all_data["items"])


def test_mask_repository_url_password():
    masked = mask_repository_url("http://user:secret@192.168.1.1:9000/repo.git")
    assert "secret" not in masked
    assert "user" not in masked
    assert masked == "http://192.168.1.1:9000/repo.git"


def test_mask_repository_url_username_only():
    masked = mask_repository_url(
        "http://user_a@git.example.local:9000/project-a/repository-a"
    )
    assert "user_a" not in masked
    assert masked == "http://git.example.local:9000/project-a/repository-a"


def test_document_path_recursive_pptx_count(project_root, ppt_documents_ready):
    from tests.conftest import local_path_to_test_unc

    docs = project_root / "tests" / "test-data" / "device-a" / "documents"
    valid, message, count = validate_document_path(local_path_to_test_unc(docs))
    assert valid is True
    assert count >= 10
    assert "하위 폴더" in message


def test_validate_remote_url_invalid(client):
    response = client.post(
        "/api/repositories/validate/remote",
        json={"repository_url": "http://invalid.example.invalid/repo.git"},
    )
    assert response.status_code == 200
    data = response.json()
    assert data["valid"] is False


def test_remote_repository_create_stores_canonical_url_only(
    client, device_a_paths, monkeypatch, tmp_path
):
    monkeypatch.setattr("app.core.config.REPOSITORIES_ROOT", tmp_path / "managed")
    monkeypatch.setattr("app.services.git_repository_service.REPOSITORIES_ROOT", tmp_path / "managed")
    equipment = register_equipment(client, device_a_paths)

    response = client.post(
        f"/api/equipment/{equipment['id']}/repositories",
        json={
            "name": "remote_repo",
            "source_type": "remote",
            "repository_url": "http://user_a@git.example.local:9000/project/repo",
        },
    )
    assert response.status_code == 201, response.text
    body = response.json()
    assert body["repository_url"] == "http://git.example.local:9000/project/repo"
    assert body["canonical_repository_url"] == "http://git.example.local:9000/project/repo"
    assert body["yona_username"] is None
    assert "user_a" not in (body["repository_url"] or "")


def test_update_repository_same_canonical_no_git(
    client, device_a_paths, monkeypatch, tmp_path
):
    monkeypatch.setattr("app.core.config.REPOSITORIES_ROOT", tmp_path / "managed")
    monkeypatch.setattr("app.services.git_repository_service.REPOSITORIES_ROOT", tmp_path / "managed")
    equipment = register_equipment(client, device_a_paths)
    created = client.post(
        f"/api/equipment/{equipment['id']}/repositories",
        json={
            "name": "remote_repo",
            "source_type": "remote",
            "repository_url": "http://user_a@git.example.local:9000/project/repo",
        },
    ).json()

    def fail_git(*_args, **_kwargs):
        raise AssertionError("update with same canonical must not run git commands")

    monkeypatch.setattr(
        "app.services.git_repository_service.validate_remote_repository_url",
        fail_git,
    )
    monkeypatch.setattr("app.services.git_repository_service._set_remote_origin", fail_git)
    monkeypatch.setattr("app.services.git_repository_service._clone_remote", fail_git)
    monkeypatch.setattr("app.services.git_repository_service._run_git_command", fail_git)

    response = client.put(
        f"/api/repositories/{created['id']}",
        json={
            "name": "remote_repo_renamed",
            "repository_url": "http://user_b@git.example.local:9000/project/repo",
        },
    )
    assert response.status_code == 200, response.text
    body = response.json()
    assert body["name"] == "remote_repo_renamed"
    assert body["status"] == "pending"
    assert body["repository_url"] == "http://git.example.local:9000/project/repo"


def test_prepare_skips_ready_repository(
    client, device_a_paths, monkeypatch, tmp_path
):
    monkeypatch.setattr("app.core.config.REPOSITORIES_ROOT", tmp_path / "managed")
    monkeypatch.setattr("app.services.git_repository_service.REPOSITORIES_ROOT", tmp_path / "managed")
    equipment = register_equipment(client, device_a_paths)
    created = client.post(
        f"/api/equipment/{equipment['id']}/repositories",
        json={
            "name": "remote_repo",
            "source_type": "remote",
            "repository_url": "http://git.example.local:9000/project/repo",
        },
    ).json()

    clone_dir = tmp_path / "managed" / str(equipment["id"]) / str(created["id"])
    clone_dir.mkdir(parents=True)
    (clone_dir / ".git").mkdir()

    from app.db.database import get_connection

    conn = get_connection()
    try:
        conn.execute(
            "UPDATE git_repository SET local_path = ?, status = 'ready' WHERE id = ?",
            (str(clone_dir), created["id"]),
        )
        conn.commit()
    finally:
        conn.close()

    def fail_clone(*_args, **_kwargs):
        raise AssertionError("prepare must skip clone for ready repository")

    monkeypatch.setattr("app.services.git_repository_service._clone_remote", fail_clone)

    response = client.post(f"/api/repositories/{created['id']}/prepare")
    assert response.status_code == 200, response.text
    assert response.json()["status"] == "ready"


def test_remote_repository_create_does_not_run_ls_remote(
    client, device_a_paths, monkeypatch, tmp_path
):
    monkeypatch.setattr("app.core.config.REPOSITORIES_ROOT", tmp_path / "managed")
    monkeypatch.setattr("app.services.git_repository_service.REPOSITORIES_ROOT", tmp_path / "managed")
    equipment = register_equipment(client, device_a_paths)

    def fail_validate(_repository_url: str):
        raise AssertionError("create_repository should not call validate_remote_repository_url")

    monkeypatch.setattr(
        "app.services.git_repository_service.validate_remote_repository_url",
        fail_validate,
    )

    response = client.post(
        f"/api/equipment/{equipment['id']}/repositories",
        json={
            "name": "remote_repo",
            "source_type": "remote",
            "repository_url": "http://user_a@git.example.local:9000/project/repo",
        },
    )
    assert response.status_code == 201, response.text
    body = response.json()
    assert body["status"] == "pending"
    assert body["canonical_repository_url"] == "http://git.example.local:9000/project/repo"


def test_remote_repository_prepare_runs_clone_without_ls_remote(
    client, device_a_paths, monkeypatch, tmp_path
):
    monkeypatch.setattr("app.core.config.REPOSITORIES_ROOT", tmp_path / "managed")
    monkeypatch.setattr("app.services.git_repository_service.REPOSITORIES_ROOT", tmp_path / "managed")
    equipment = register_equipment(client, device_a_paths)
    created = client.post(
        f"/api/equipment/{equipment['id']}/repositories",
        json={
            "name": "remote_repo",
            "source_type": "remote",
            "repository_url": "http://user_a@git.example.local:9000/project/repo",
        },
    )
    assert created.status_code == 201, created.text
    repo = created.json()

    def fail_validate(_repository_url: str):
        raise AssertionError("prepare should not call validate_remote_repository_url")

    def fake_clone(access_url: str, target: Path):
        target.mkdir(parents=True, exist_ok=True)
        (target / ".git").mkdir()

    monkeypatch.setattr(
        "app.services.git_repository_service.validate_remote_repository_url",
        fail_validate,
    )
    monkeypatch.setattr("app.services.git_repository_service._clone_remote", fake_clone)

    response = client.post(f"/api/repositories/{repo['id']}/prepare")
    assert response.status_code == 200, response.text
    body = response.json()
    assert body["status"] == "ready"


def test_remote_repository_prepare_failure_sets_error(
    client, device_a_paths, monkeypatch, tmp_path
):
    monkeypatch.setattr("app.core.config.REPOSITORIES_ROOT", tmp_path / "managed")
    monkeypatch.setattr("app.services.git_repository_service.REPOSITORIES_ROOT", tmp_path / "managed")
    equipment = register_equipment(client, device_a_paths)
    created = client.post(
        f"/api/equipment/{equipment['id']}/repositories",
        json={
            "name": "remote_repo",
            "source_type": "remote",
            "repository_url": "http://user_a@git.example.local:9000/project/repo",
        },
    )
    repo = created.json()

    def fail_clone(_access_url: str, _target: Path):
        from app.services.git_repository_service import GitRepositoryError

        raise GitRepositoryError("clone failed")

    monkeypatch.setattr("app.services.git_repository_service._clone_remote", fail_clone)

    response = client.post(f"/api/repositories/{repo['id']}/prepare")
    assert response.status_code == 400

    repo_after = client.get(f"/api/repositories/{repo['id']}").json()
    assert repo_after["status"] == "error"


def test_equipment_delete_cascades_repositories(client, registered_device_a):
    equipment_id = registered_device_a["id"]
    client.post(f"/api/equipment/{equipment_id}/sync/git")
    conn = get_connection()
    try:
        assert count_commits_for_equipment(conn, equipment_id) > 0
        repo_cnt = conn.execute(
            "SELECT COUNT(*) AS cnt FROM git_repository WHERE equipment_id = ?",
            (equipment_id,),
        ).fetchone()["cnt"]
        assert repo_cnt >= 1
    finally:
        conn.close()

    client.delete(f"/api/equipment/{equipment_id}")

    conn = get_connection()
    try:
        assert (
            conn.execute(
                "SELECT COUNT(*) AS cnt FROM git_repository WHERE equipment_id = ?",
                (equipment_id,),
            ).fetchone()["cnt"]
            == 0
        )
        assert count_commits_for_equipment(conn, equipment_id) == 0
    finally:
        conn.close()


def test_trace_candidate_includes_repository(synced_device_a, client):
    eid = synced_device_a["id"]
    response = client.post(
        "/api/trace/search",
        json={"equipment_id": eid, "query": "CHILD_FARE"},
    )
    assert response.status_code == 200
    data = response.json()
    assert len(data["git_candidates"]) >= 1
    assert "repository_id" in data["git_candidates"][0]
    assert "repository_name" in data["git_candidates"][0]
