import subprocess
from pathlib import Path

import pytest

from tests.conftest import count_commits_for_equipment, register_equipment_with_repo
from app.db.database import get_connection
from app.services.git_service import (
    BINARY_DIFF_PLACEHOLDER,
    get_existing_commit_hashes,
    list_all_commit_hashes,
    sync_equipment_git,
)


def test_foreign_keys_enabled(test_db):
    conn = get_connection()
    try:
        row = conn.execute("PRAGMA foreign_keys").fetchone()
        assert row[0] == 1
    finally:
        conn.close()


def test_list_all_commit_hashes(isolated_device_a_repo):
    hashes = list_all_commit_hashes(str(isolated_device_a_repo))
    assert len(hashes) == 5


def test_initial_sync_collects_five_commits(registered_device_a, client):
    equipment_id = registered_device_a["id"]
    response = client.post(f"/api/equipment/{equipment_id}/sync/git")
    assert response.status_code == 200
    data = response.json()
    assert data["new_commits"] == 5
    assert data["skipped_commits"] == 0
    assert data["scanned_commits"] == 5
    assert data["new_changes"] >= 5
    assert data["status"] == "completed"


def test_resync_no_duplicates(registered_device_a, client):
    equipment_id = registered_device_a["id"]
    client.post(f"/api/equipment/{equipment_id}/sync/git")
    response = client.post(f"/api/equipment/{equipment_id}/sync/git")
    data = response.json()
    assert data["new_commits"] == 0
    assert data["skipped_commits"] == 5

    conn = get_connection()
    try:
        commit_count = count_commits_for_equipment(conn, equipment_id)
        change_count = conn.execute(
            """
            SELECT COUNT(*) AS cnt FROM git_change gc
            JOIN git_commit gcm ON gc.commit_id = gcm.id
            JOIN git_repository gr ON gr.id = gcm.repository_id
            WHERE gr.equipment_id = ?
            """,
            (equipment_id,),
        ).fetchone()["cnt"]
    finally:
        conn.close()

    assert commit_count == 5
    assert change_count == data["new_changes"] or change_count >= 5


def test_sync_after_new_commit(registered_device_a, client, isolated_device_a_repo):
    equipment_id = registered_device_a["id"]
    client.post(f"/api/equipment/{equipment_id}/sync/git")

    readme = isolated_device_a_repo / "README.md"
    readme.write_text(readme.read_text(encoding="utf-8") + "\n# update\n", encoding="utf-8")
    repo = str(isolated_device_a_repo)
    subprocess.run(["git", "-C", repo, "add", "README.md"], check=True, capture_output=True)
    subprocess.run(
        [
            "git",
            "-C",
            repo,
            "-c",
            "user.email=test@example.com",
            "-c",
            "user.name=Test User",
            "commit",
            "-m",
            "추가 README 갱신",
        ],
        check=True,
        capture_output=True,
        encoding="utf-8",
    )

    response = client.post(f"/api/equipment/{equipment_id}/sync/git")
    data = response.json()
    assert data["new_commits"] == 1
    assert data["skipped_commits"] == 5


def test_korean_commit_message_preserved(registered_device_a, client):
    equipment_id = registered_device_a["id"]
    client.post(f"/api/equipment/{equipment_id}/sync/git")

    conn = get_connection()
    try:
        rows = conn.execute(
            """
            SELECT gc.message
            FROM git_commit gc
            JOIN git_repository gr ON gr.id = gc.repository_id
            WHERE gr.equipment_id = ?
            ORDER BY gc.commit_date
            """,
            (equipment_id,),
        ).fetchall()
    finally:
        conn.close()

    messages = [row["message"] for row in rows]
    assert any("어린이 카드 요금 처리 추가" in m for m in messages)
    assert not any("\ufffd" in m for m in messages)


def test_sync_with_space_in_path(client, project_root, setup_repos, tmp_path):
    import sys

    sys.path.insert(0, str(project_root / "tests" / "test-data"))
    from setup_repositories import _apply_commits, _device_a_commits

    dest_parent = tmp_path / "path with spaces"
    dest = dest_parent / "repository"
    _apply_commits(dest, _device_a_commits)

    docs = tmp_path / "docs"
    docs.mkdir()
    (docs / "a.pptx").write_text("x", encoding="utf-8")

    from tests.conftest import local_path_to_test_unc

    equipment = register_equipment_with_repo(
        client,
        {
            "name": "SPACE_PATH_DEVICE",
            "git_path": str(dest),
            "document_path": local_path_to_test_unc(docs),
        },
    )
    response = client.post(f"/api/equipment/{equipment['id']}/sync/git")
    assert response.status_code == 200
    assert response.json()["new_commits"] == 5


def test_sync_invalid_git_repo(client, registered_device_a, tmp_path):
    equipment_id = registered_device_a["id"]
    not_repo = tmp_path / "plain"
    not_repo.mkdir()

    conn = get_connection()
    try:
        repo_row = conn.execute(
            "SELECT id FROM git_repository WHERE equipment_id = ? LIMIT 1",
            (equipment_id,),
        ).fetchone()
        conn.execute(
            "UPDATE git_repository SET local_path = ? WHERE id = ?",
            (str(not_repo), repo_row["id"]),
        )
        conn.commit()
    finally:
        conn.close()

    response = client.post(f"/api/equipment/{equipment_id}/sync/git")
    assert response.status_code == 400
    assert "Git Repository" in response.json()["detail"]


def test_sync_nonexistent_equipment(client):
    response = client.post("/api/equipment/99999/sync/git")
    assert response.status_code == 404


def test_two_equipment_independent_sync(
    client, isolated_device_a_paths, isolated_device_b_paths
):
    eq_a = register_equipment_with_repo(client, isolated_device_a_paths, "repo_a")
    eq_b = register_equipment_with_repo(client, isolated_device_b_paths, "repo_b")

    sync_a = client.post(f"/api/equipment/{eq_a['id']}/sync/git").json()
    sync_b = client.post(f"/api/equipment/{eq_b['id']}/sync/git").json()

    assert sync_a["new_commits"] == 5
    assert sync_b["new_commits"] == 2

    conn = get_connection()
    try:
        hashes_a = {
            r["commit_hash"]
            for r in conn.execute(
                """
                SELECT gc.commit_hash
                FROM git_commit gc
                JOIN git_repository gr ON gr.id = gc.repository_id
                WHERE gr.equipment_id = ?
                """,
                (eq_a["id"],),
            ).fetchall()
        }
        hashes_b = {
            r["commit_hash"]
            for r in conn.execute(
                """
                SELECT gc.commit_hash
                FROM git_commit gc
                JOIN git_repository gr ON gr.id = gc.repository_id
                WHERE gr.equipment_id = ?
                """,
                (eq_b["id"],),
            ).fetchall()
        }
    finally:
        conn.close()

    assert hashes_a.isdisjoint(hashes_b) or len(hashes_a) == 5


def test_equipment_delete_cascades_git_data(client, registered_device_a):
    equipment_id = registered_device_a["id"]
    client.post(f"/api/equipment/{equipment_id}/sync/git")

    conn = get_connection()
    try:
        assert count_commits_for_equipment(conn, equipment_id) > 0
    finally:
        conn.close()

    response = client.delete(f"/api/equipment/{equipment_id}")
    assert response.status_code == 204

    conn = get_connection()
    try:
        fk_on = conn.execute("PRAGMA foreign_keys").fetchone()[0]
        assert fk_on == 1
        commit_cnt = count_commits_for_equipment(conn, equipment_id)
        change_cnt = conn.execute(
            """
            SELECT COUNT(*) AS cnt FROM git_change gc
            WHERE NOT EXISTS (
                SELECT 1 FROM git_commit gcm WHERE gcm.id = gc.commit_id
            )
            """
        ).fetchone()["cnt"]
    finally:
        conn.close()

    assert commit_cnt == 0
    assert change_cnt == 0


def test_binary_file_commit(client, tmp_path):
    repo = tmp_path / "binary-repo"
    repo.mkdir()
    docs = tmp_path / "docs"
    docs.mkdir()
    (docs / "sample.pptx").write_text("x", encoding="utf-8")

    subprocess.run(["git", "init"], cwd=repo, check=True, capture_output=True)
    (repo / "data.bin").write_bytes(bytes(range(256)))
    subprocess.run(["git", "add", "."], cwd=repo, check=True, capture_output=True)
    subprocess.run(
        [
            "git",
            "-c",
            "user.email=t@e.com",
            "-c",
            "user.name=T",
            "commit",
            "-m",
            "binary add",
        ],
        cwd=repo,
        check=True,
        capture_output=True,
        encoding="utf-8",
    )

    from tests.conftest import local_path_to_test_unc

    equipment = register_equipment_with_repo(
        client,
        {
            "name": "BINARY_TEST",
            "git_path": str(repo),
            "document_path": local_path_to_test_unc(docs),
        },
    )
    response = client.post(f"/api/equipment/{equipment['id']}/sync/git")
    assert response.status_code == 200

    conn = get_connection()
    try:
        row = conn.execute(
            """
            SELECT gc.additions, gc.deletions, gc.diff
            FROM git_change gc
            JOIN git_commit gcm ON gc.commit_id = gcm.id
            JOIN git_repository gr ON gr.id = gcm.repository_id
            WHERE gr.equipment_id = ? AND gc.file_path = 'data.bin'
            """,
            (equipment["id"],),
        ).fetchone()
    finally:
        conn.close()

    assert row is not None
    assert row["additions"] is None
    assert row["deletions"] is None
    assert row["diff"] == BINARY_DIFF_PLACEHOLDER


def test_renamed_file_change_type(client, tmp_path):
    repo = tmp_path / "rename-repo"
    repo.mkdir()
    docs = tmp_path / "docs2"
    docs.mkdir()
    (docs / "sample.pptx").write_text("x", encoding="utf-8")

    subprocess.run(["git", "init"], cwd=repo, check=True, capture_output=True)
    (repo / "old_name.c").write_text("int x=1;\n", encoding="utf-8")
    subprocess.run(["git", "add", "."], cwd=repo, check=True, capture_output=True)
    subprocess.run(
        [
            "git",
            "-c",
            "user.email=t@e.com",
            "-c",
            "user.name=T",
            "commit",
            "-m",
            "add file",
        ],
        cwd=repo,
        check=True,
        capture_output=True,
        encoding="utf-8",
    )
    subprocess.run(
        ["git", "mv", "old_name.c", "new_name.c"],
        cwd=repo,
        check=True,
        capture_output=True,
    )
    subprocess.run(
        [
            "git",
            "-c",
            "user.email=t@e.com",
            "-c",
            "user.name=T",
            "commit",
            "-m",
            "rename file",
        ],
        cwd=repo,
        check=True,
        capture_output=True,
        encoding="utf-8",
    )

    from tests.conftest import local_path_to_test_unc

    equipment = register_equipment_with_repo(
        client,
        {
            "name": "RENAME_TEST",
            "git_path": str(repo),
            "document_path": local_path_to_test_unc(docs),
        },
    )
    client.post(f"/api/equipment/{equipment['id']}/sync/git")

    conn = get_connection()
    try:
        row = conn.execute(
            """
            SELECT gc.change_type, gc.file_path
            FROM git_change gc
            JOIN git_commit gcm ON gc.commit_id = gcm.id
            JOIN git_repository gr ON gr.id = gcm.repository_id
            WHERE gr.equipment_id = ? AND gc.change_type = 'renamed'
            """,
            (equipment["id"],),
        ).fetchone()
    finally:
        conn.close()

    assert row is not None
    assert row["file_path"] == "new_name.c"


def test_get_existing_commit_hashes(registered_device_a, client):
    equipment_id = registered_device_a["id"]
    client.post(f"/api/equipment/{equipment_id}/sync/git")
    conn = get_connection()
    try:
        repo_id = conn.execute(
            "SELECT id FROM git_repository WHERE equipment_id = ? LIMIT 1",
            (equipment_id,),
        ).fetchone()["id"]
    finally:
        conn.close()
    hashes = get_existing_commit_hashes(repo_id)
    assert len(hashes) == 5


def test_sync_service_direct(registered_device_a):
    result = sync_equipment_git(registered_device_a["id"])
    assert result.scanned_commits == 5
    assert result.new_commits == 5

    result2 = sync_equipment_git(registered_device_a["id"])
    assert result2.new_commits == 0
    assert result2.skipped_commits == 5
