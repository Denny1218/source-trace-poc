from unittest.mock import patch

from fastapi.testclient import TestClient

from app.main import app


def test_health_endpoint_returns_expected_fields():
    client = TestClient(app)
    response = client.get("/api/health")
    assert response.status_code == 200
    data = response.json()
    assert "status" in data
    assert "database" in data
    assert "git" in data
    assert "ollama" in data


def test_health_endpoint_status_ok_when_database_ok():
    client = TestClient(app)
    with patch("app.services.health_service.check_database", return_value="ok"):
        with patch("app.services.health_service.check_git", return_value="available"):
            with patch(
                "app.services.health_service.check_ollama", return_value="unavailable"
            ):
                response = client.get("/api/health")
    data = response.json()
    assert data["status"] == "ok"
    assert data["database"] == "ok"
    assert data["ollama"] == "unavailable"


def test_health_endpoint_degraded_when_database_error():
    client = TestClient(app)
    with patch("app.services.health_service.check_database", return_value="error"):
        with patch("app.services.health_service.check_git", return_value="available"):
            with patch(
                "app.services.health_service.check_ollama", return_value="unavailable"
            ):
                response = client.get("/api/health")
    data = response.json()
    assert data["status"] == "degraded"
    assert data["database"] == "error"


def test_check_git_unavailable_when_not_installed():
    from app.services.health_service import check_git

    with patch("app.services.health_service.shutil.which", return_value=None):
        assert check_git() == "unavailable"


def test_check_ollama_unavailable_on_connection_error():
    from app.services.health_service import check_ollama

    with patch("app.services.health_service.httpx.Client") as mock_client:
        mock_client.return_value.__enter__.return_value.get.side_effect = Exception(
            "connection refused"
        )
        assert check_ollama() == "unavailable"
