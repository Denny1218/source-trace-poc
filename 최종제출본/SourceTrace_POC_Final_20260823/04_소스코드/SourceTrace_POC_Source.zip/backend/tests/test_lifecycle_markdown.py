"""Markdown renderer — PROJECT_SPEC v2.6 simplified user results."""

from __future__ import annotations

from pathlib import Path

from app.services.function_git_lifecycle_service import (
    FunctionGitHistoryEntry,
    _build_narrative,
    _entry_heading,
    _user_limitation_note,
)
from app.services.lifecycle_markdown import (
    format_date_display,
    md_escape_cell,
    render_lifecycle_markdown,
    split_to_be_bullets,
)
from app.services.lifecycle_ppt import (
    LINK_COMMIT_DIRECT,
    LINK_FEATURE_RELEASE,
    LINK_MAINTENANCE,
    LINK_RELATED,
    PptLink,
    connection_strength,
    connection_strength_label,
    document_phase,
)


FN = "sample_trace_function"


def _entry(**kwargs) -> FunctionGitHistoryEntry:
    defaults = dict(
        commit_id=1,
        commit_hash="aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
        commit_date="2020-02-26T10:00:00+09:00",
        message="add fn",
        file_path="src/a.c",
        change_type="function_creation",
        change_type_label="함수 최초 추가",
        change_description="- 함수 원형과 구현이 새로 추가되었습니다.",
        impact=None,
        confidence="high",
        confidence_label="높음",
        section="core",
        confirmation_note=None,
        diff_state=None,
        is_core=True,
        ppt_title=None,
        ppt_file=None,
        ppt_slide=None,
        ppt_link_level="none",
        ppt_link_reason=None,
        ppt_link=None,
        debug_item={"evidence_tier": "DIRECT_BODY_CHANGE", "classification_reason": "body_change:body_change"},
    )
    defaults.update(kwargs)
    if "is_core" not in kwargs and defaults.get("section") in {"other", "unconfirmed"}:
        defaults["is_core"] = False
    return FunctionGitHistoryEntry(**defaults)


def _counts(**kwargs) -> dict:
    base = {
        "creation_count": 1,
        "core_followup_count": 0,
        "other_count": 0,
        "maintenance_count": 0,
        "ppt_direct_count": 0,
        "ppt_official_doc_count": 0,
        "_stage_official_docs": [],
        "_request_equipment_id": 1,
        "_request_equipment_name": None,
        "_query_file_path": "src/a.c",
        "direct_confirmed_count": 1,
    }
    base.update(kwargs)
    return base


def _render(entries, overall="보통", counts=None):
    return render_lifecycle_markdown(
        FN,
        entries,
        overall,
        counts or _counts(),
        entry_heading=_entry_heading,
        user_limitation_note=_user_limitation_note,
        build_narrative=_build_narrative,
    )


def test_no_270_day_constant_in_lifecycle_modules():
    root = Path(__file__).resolve().parents[1] / "app" / "services"
    for name in ("lifecycle_markdown.py", "lifecycle_ppt.py", "function_git_lifecycle_service.py"):
        text = (root / name).read_text(encoding="utf-8")
        assert "270" not in text, f"{name} still mentions 270"


def test_document_phase_ignores_date_gap():
    assert document_phase("modify", "2020-01-01", "2017-01-01") == "development"
    assert document_phase("delete", "2020-01-01", "2017-01-01") == "maintenance"
    assert document_phase("apply", "2025-01-01", "2017-01-01") == "development"


def test_connection_strength_labels_still_exist_internally():
    assert connection_strength(LINK_COMMIT_DIRECT) == "commit_direct"
    assert connection_strength_label(LINK_FEATURE_RELEASE) == "단계 연결 근거"
    assert connection_strength_label(LINK_MAINTENANCE) == "관련 참고"
    assert connection_strength_label(LINK_RELATED) == "관련 참고"


def test_glance_table_v26_minimal():
    md = _render([_entry()])
    assert "## 한눈에 보기" in md
    assert "| 최초 확인 |" in md
    assert "| 이후 Git 이력 |" in md
    assert "| 이후 변경 |" not in md
    assert "| 관련 문서 |" in md
    assert "| 조회 파일 |" in md
    assert "주요 개발" not in md
    assert "보조 변경" not in md
    assert "유지보수" not in md
    assert "Commit 직접 연결 문서" not in md
    assert "단계 연결 문서" not in md
    assert "관련 참고 문서" not in md
    assert "분석 신뢰도" not in md
    assert "관련 공식 문서" not in md


def test_history_table_three_columns():
    md = _render([_entry()])
    assert "## 변경 이력" in md
    assert "| 날짜 | Commit | 변경 내용 |" in md
    assert "Git 근거" not in md
    assert "문서 연결" not in md
    assert "| 구분 |" not in md
    assert "## 핵심 변경 흐름" not in md


def test_details_single_section_no_role_subheadings():
    doc = PptLink(
        document_name="apply.pptx",
        change_title="기능 적용",
        link_type=LINK_FEATURE_RELEASE,
        slide_number=2,
        document_date="2020-02-24",
        versions=["V1"],
        csr_no="C1",
        to_be="타입 추가. 생년월일 추가.",
        phase="development",
        change_action="apply",
        related_source_paths=["a.c"],
        related_symbols=["foo"],
    )
    md = _render(
        [_entry(ppt_link=doc)],
        counts=_counts(_stage_official_docs=[doc], ppt_official_doc_count=1),
    )
    assert "## 변경 상세" in md
    assert "### 초기 개발 및 주요 기능 변경" not in md
    assert "### 개발 및 보조 변경" not in md
    assert "### 후속 Git 유지보수" not in md
    assert "### 연관 Git 이력" not in md
    assert "## 관련 문서" in md
    assert "## 관련 공식 문서" not in md
    assert "**주요 변경 내용**" in md
    assert "| 연결 유형 |" not in md
    assert "대표 연결 근거" not in md
    assert "관련 소스·함수 보기" in md
    assert "### 연결 Commit" not in md


def test_commit_detail_separates_message_from_code_facts():
    e = _entry(
        change_type="transfer_reboarding_change",
        change_type_label="환승",
        message="10분 재승차 기능 추가 및 5분 재개표",
        change_description=(
            "- 10분 재승차 기능 추가 및 5분 재개표\n"
            "- Diff에서 환승·재승차 판정 조건을 변경했습니다."
        ),
        debug_item={
            "evidence_tier": "DIRECT_BODY_CHANGE",
            "classification_reason": "body_change:transfer_reboarding_change",
        },
    )
    md = _render([e], counts=_counts(creation_count=0, core_followup_count=1))
    assert "- Commit 메시지:" in md
    assert "- 코드에서 확인:" in md
    assert "- 확인된 변경:" not in md
    # Extract the 코드에서 확인 block and ensure Commit message is not echoed there.
    after = md.split("- 코드에서 확인:")[1].split("</details>")[0]
    assert "10분 재승차 기능 추가 및 5분 재개표" not in after
    assert "환승·재승차 판정 조건 변경" in after
    assert "Diff에서 환승" not in after


def test_message_only_has_no_code_confirmed_section():
    e = _entry(
        change_type="transfer_reboarding_change",
        change_type_label="환승·재승차 판정 변경",
        change_description=(
            "- Commit 메시지상 환승·재승차 판정 변경(으)로 확인됩니다.\n"
            "- 대상 함수의 세부 Diff는 확보하지 못했습니다."
        ),
        section="unconfirmed",
        is_core=False,
        debug_item={
            "evidence_tier": "MESSAGE_ONLY",
            "classification_reason": "message_topic",
        },
    )
    md = _render([e], counts=_counts(creation_count=0, core_followup_count=0))
    assert "- 코드에서 확인:" not in md
    assert "대상 함수의 세부 Diff는 확인하지 못했습니다." in md
    assert "대상 함수 Diff 미확인" in md


def test_related_doc_hides_linked_commits():
    doc = PptLink(
        document_name="apply.pptx",
        change_title="기능 적용",
        link_type=LINK_FEATURE_RELEASE,
        slide_number=2,
        document_date="2020-02-24",
        versions=["V1"],
        csr_no="C1",
        to_be="타입 추가. 생년월일 추가.",
        phase="development",
        change_action="apply",
        related_source_paths=["a.c"],
        related_symbols=["foo"],
    )
    md = _render(
        [_entry(ppt_link=doc)],
        counts=_counts(_stage_official_docs=[doc], ppt_official_doc_count=1),
    )
    assert "관련 소스·함수 보기" in md
    assert "관련 소스·함수·연결 Commit 보기" not in md
    assert "### 연결 Commit" not in md
    assert "확정된 단일 Commit은 없습니다." not in md
    assert "### 관련 소스" in md
    assert "### 관련 함수" in md
    assert "a.c" in md
    assert "foo()" in md


def test_no_speculative_call_site_phrasing():
    from app.services.function_git_lifecycle_service import _build_creation_description

    text = _build_creation_description({"plus_call": 2}, parent_verified_absent=False)
    assert "관련 호출부" not in text
    assert "수 있습니다" not in text
    assert "최초로 확인되었습니다" in text
    verified = _build_creation_description({}, parent_verified_absent=True)
    assert "새로 추가되었습니다" in verified
    assert "수 있습니다" not in verified


def test_commit_detail_shows_doc_without_strength_labels():
    direct = PptLink(
        document_name="d.pptx",
        change_title="직접",
        link_type=LINK_COMMIT_DIRECT,
        slide_number=1,
        link_reason_user="대상 함수 Diff와 문서 내용이 직접 일치합니다.",
        phase="development",
        change_action="apply",
    )
    e1 = _entry(ppt_link=direct, change_type="card_type_setting", change_type_label="변경")
    md = _render([e1], counts=_counts(_stage_official_docs=[direct], ppt_official_doc_count=1))
    assert "- 관련 문서:" in md
    assert "연결 유형" not in md
    assert "연결 근거:" not in md


def test_details_blocks_for_commits():
    md = _render([_entry()])
    assert "<details>" in md
    assert "`aaaaaaaa`" in md


def test_stage_doc_not_repeated_on_commit_detail():
    stage = PptLink(
        document_name="stage.pptx",
        change_title="단계",
        link_type=LINK_FEATURE_RELEASE,
        slide_number=3,
        phase="development",
        change_action="apply",
    )
    e = _entry(
        ppt_link=stage,
        change_type="transfer_reboarding_change",
        change_type_label="환승",
        change_description="- 환승·재승차 판정 조건을 변경했습니다.",
        message="15분 재승차 시간 변경",
        debug_item={
            "evidence_tier": "DIRECT_BODY_CHANGE",
            "classification_reason": "body_change:transfer_reboarding_change",
        },
    )
    md = _render(
        [e],
        counts=_counts(
            creation_count=0,
            core_followup_count=1,
            _stage_official_docs=[stage],
            ppt_official_doc_count=1,
        ),
    )
    # Stage/reference docs belong only in bottom ## 관련 문서
    assert "## 관련 문서" in md
    assert "stage.pptx" in md
    # Commit detail must not repeat stage doc
    detail = md.split("## 관련 문서")[0]
    assert "stage.pptx" not in detail
    assert "15분 재승차" in md  # Commit message preferred in summary


def test_citations_collapsed():
    md = _render([_entry()])
    assert "## 전체 참조 근거" in md
    assert "Git Commit 및 변경내역서 전체 보기" in md


def test_zero_docs_shows_not_found():
    md = _render([_entry()])
    assert "관련 문서를 찾지 못했습니다." in md or "| 관련 문서 | 0건 |" in md


def test_md_escape_and_date():
    assert "\\|" in md_escape_cell("a|b")
    assert format_date_display("2020-02-26T13:50:51+09:00") == "2020-02-26"


def test_split_to_be_preserves_when_unsplittable():
    assert split_to_be_bullets("단순설명") == ["단순설명"]


def test_meta_footer_no_confidence(tmp_path: Path):
    doc = PptLink(
        document_name="프로그램변경내역서_sample.pptx",
        change_title="샘플 적용",
        link_type=LINK_FEATURE_RELEASE,
        slide_number=2,
        to_be="변경",
    )
    md = _render(
        [_entry(ppt_link=doc)],
        counts=_counts(_stage_official_docs=[doc], ppt_official_doc_count=1),
    )
    assert "분석 신뢰도" not in md
    assert "조회:" in md
    out = Path(__file__).resolve().parent / "fixtures" / "lifecycle_markdown_sample.md"
    out.write_text(md, encoding="utf-8")
