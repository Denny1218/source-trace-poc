"""Feature-release PPT linking + classification regression tests."""

from __future__ import annotations

from app.schemas.trace import GitCandidate
from app.services.change_item_candidate_service import ChangeItemCandidate
from app.services.evidence_service import EvidenceLink, EvidenceResult
from app.services.function_git_lifecycle_service import (
    analyze_function_commit,
    resolve_function_git_lifecycle,
)
from app.services.lifecycle_ppt import (
    LINK_COMMIT_DIRECT,
    LINK_DEV_REFERENCE,
    LINK_FEATURE_RELEASE,
    LINK_MAINTENANCE,
    build_ppt_link_for_entry,
    classify_change_action,
    collect_feature_documents,
    extract_related_source_paths,
    extract_related_symbols,
    item_mentions_symbol,
    pick_primary_feature_title,
    search_token_sets_equivalent,
)
from app.services.source_path_utils import PathMatchLevel, source_path_match_level


FN = "card_mif_post_check_valid_birthday_usertype"
FILE = "mif_post/src/card_mif_postpay.c"


def _git(*, commit_hash: str, commit_date: str, message: str, commit_id: int) -> GitCandidate:
    return GitCandidate.model_construct(
        repository_id=1,
        repository_name="repo",
        commit_id=commit_id,
        commit_hash=commit_hash,
        commit_date=commit_date,
        message=message,
        file_path=FILE,
        score=10,
        match_reasons=["diff_symbol"],
        query_match_reasons=[],
        query_relevance_score=0,
        query_relevance_level="높음",
    )


def _item(
    *,
    title: str,
    file_name: str,
    functions: list[str],
    paths: list[str] | None = None,
    slide_no: int = 3,
    csr: str | None = "C20200205_022",
    bg: str | None = "[기관요청] 청소년 후불카드 적용",
    to_be: str | None = "구후불에 청소년·어린이 유형 및 생년월일 추가",
    cache_id: int = 1,
) -> ChangeItemCandidate:
    source_functions = []
    for i, fn_list in enumerate([functions]):
        source_functions.append(
            {
                "file_path": (paths or [f"Card/{FILE}"])[0] if paths or True else None,
                "functions": fn_list,
            }
        )
    if paths:
        source_functions = [
            {"file_path": p, "functions": functions} for p in paths
        ]
    else:
        source_functions = [{"file_path": f"Card/{FILE}", "functions": functions}]
    return ChangeItemCandidate(
        change_item_cache_id=cache_id,
        document_cache_id=1,
        slide_no=slide_no,
        file_path=file_name,
        file_name=file_name,
        item_no="1",
        change_title=title,
        csr_no=csr,
        business_background=bg,
        current_status=None,
        as_is="기존 후불 카드 유형 판정",
        to_be=to_be,
        source_functions=source_functions,
        test_cases=[],
        applicable_scopes=[],
        raw_text=title,
        matched_keywords=[],
        candidate_score=1,
        equipment_id=1,
    )


def _evidence(
    links: list,
    gits: list,
    items: list | None = None,
    *,
    equipment_name: str | None = None,
) -> EvidenceResult:
    return EvidenceResult(
        equipment_id=1,
        equipment_name=equipment_name,
        query=f"{FN} 변경 이력",
        query_keywords=[],
        weak_query_terms=[],
        request_functions=[FN],
        request_files=[FILE],
        path_scopes=[],
        git_candidates=gits,
        change_item_candidates=items or [],
        evidence_links=links,
        change_item_link_candidate_count=0,
        fallback_documents_parsed=0,
        change_item_total=0,
    )


def _patch(monkeypatch, records: dict) -> None:
    def fake_resolve(commit_id, file_path, scope_path=None):
        key = (commit_id, file_path)
        diff = records.get(key) or records.get(commit_id)
        if diff is None:
            return None, "unavailable"
        return {
            "id": commit_id,
            "commit_id": commit_id,
            "file_path": file_path,
            "diff": diff,
            "additions": 1,
            "deletions": 1,
            "change_type": "modified",
        }, "exact_git_change"

    monkeypatch.setattr(
        "app.services.function_git_lifecycle_service.resolve_git_change_record",
        fake_resolve,
    )
    monkeypatch.setattr(
        "app.services.function_git_lifecycle_service.fetch_symbol_git_rows",
        lambda *a, **k: [],
    )
    monkeypatch.setattr(
        "app.services.function_git_lifecycle_service.ancestor_file_has_function_definition",
        lambda *a, **k: False,
    )
    monkeypatch.setattr(
        "app.services.change_item_cache_service.list_change_items_for_equipment",
        lambda *a, **k: [],
    )


def test_spaced_ppt_function_name_mentions_symbol():
    item = _item(
        title="청소년 후불카드 적용",
        file_name="프로그램변경내역서_20200224_V129_V208.pptx",
        functions=["card_mif_post_check_valid_birthday_ usertype()"],
    )
    assert item_mentions_symbol(item, FN) is True


def test_card_prefix_path_matches_suffix():
    level = source_path_match_level(
        "mif_post/src/card_mif_postpay.c",
        "Card/mif_post/src/card_mif_postpay.c",
    )
    assert level == PathMatchLevel.SUFFIX


def test_feature_release_without_commit_hash(monkeypatch):
    """Official doc mentions symbol+path but is not hash-paired to the creation commit."""
    creation_diff = (
        f"@@\n"
        f"+static int {FN}(int a)\n"
        f"+{{\n"
        f"+  return 0;\n"
        f"+}}\n"
        f"+int x = 1;\n"
    )
    g = _git(
        commit_hash="aaa1111111111111111111111111111111111111",
        commit_date="2020-02-26",
        message=f"add {FN}",
        commit_id=1,
    )
    item = _item(
        title="청소년 후불카드 적용",
        file_name="프로그램변경내역서_20200224_V129_V208_휴대용정산기.pptx",
        functions=["card_mif_post_check_valid_birthday_ usertype()"],
    )
    # Evidence link pairs PPT with a DIFFERENT commit hash
    other = _git(
        commit_hash="bbb2222222222222222222222222222222222222",
        commit_date="2020-03-01",
        message="unrelated",
        commit_id=99,
    )
    link = EvidenceLink(
        git_candidate=other,
        change_item=item,
        link_score=50,
        match_reasons=[],
    )
    er = _evidence([link], [g], items=[item])
    _patch(monkeypatch, {1: creation_diff})
    # creation needs parent False — already patched
    result = resolve_function_git_lifecycle(er, FN, file_path=FILE)
    assert result.entries
    entry = result.entries[0]
    # v2.5: creation Commit does not stage-link without Diff+topic lineage;
    # the document still appears in function-level 관련 공식 문서.
    assert entry.ppt_link is None or entry.ppt_link.link_type == LINK_FEATURE_RELEASE
    assert "확인 필요 후보" not in result.document_text
    assert "## 관련 문서" in result.document_text


def test_multiple_commits_share_one_feature_doc(monkeypatch):
    body_diff = (
        f"@@\n"
        f" static int {FN}(int a)\n"
        f" {{\n"
        f"-  type = ADULT;\n"
        f"+  type = YOUTH;\n"
        f" }}\n"
    )
    g1 = _git(
        commit_hash="c111111111111111111111111111111111111111",
        commit_date="2020-02-26",
        message="create fn",
        commit_id=1,
    )
    g2 = _git(
        commit_hash="c222222222222222222222222222222222222222",
        commit_date="2020-02-27",
        message="청소년 카드 유형 설정",
        commit_id=2,
    )
    creation_diff = (
        f"@@\n+static int {FN}(int a)\n+{{\n+  return 0;\n+}}\n+int z=1;\n"
    )
    item = _item(
        title="청소년 후불카드 적용",
        file_name="프로그램변경내역서_20200224_V129.pptx",
        functions=[FN],
    )
    er = _evidence([], [g1, g2], items=[item])

    def fake_parent(commit_id, file_path, symbol):
        return False if commit_id == 1 else True

    monkeypatch.setattr(
        "app.services.function_git_lifecycle_service.ancestor_file_has_function_definition",
        fake_parent,
    )
    monkeypatch.setattr(
        "app.services.function_git_lifecycle_service.fetch_symbol_git_rows",
        lambda *a, **k: [],
    )

    def fake_resolve(commit_id, file_path, scope_path=None):
        diff = creation_diff if commit_id == 1 else body_diff
        return {
            "id": commit_id,
            "commit_id": commit_id,
            "file_path": file_path,
            "diff": diff,
            "additions": 1,
            "deletions": 1,
            "change_type": "modified",
        }, "exact_git_change"

    monkeypatch.setattr(
        "app.services.function_git_lifecycle_service.resolve_git_change_record",
        fake_resolve,
    )

    result = resolve_function_git_lifecycle(er, FN, file_path=FILE)
    linked = [e for e in result.entries if e.ppt_link and e.ppt_link.link_type == LINK_FEATURE_RELEASE]
    # v2.5: creation may not stage-link; body-change commit should.
    assert len(linked) >= 1
    assert result.debug["lifecycle_summary"]["ppt_official_doc_count"] >= 1


def test_log_commit_gets_dev_reference_not_direct_reason():
    item = _item(
        title="청소년 후불카드 적용",
        file_name="프로그램변경내역서_20200224.pptx",
        functions=[FN],
    )
    docs = collect_feature_documents(
        _evidence([], [], items=[item]), FN, file_path=FILE
    )
    link = build_ppt_link_for_entry(
        commit_hash="loghash000000000000000000000000000000001",
        commit_date="2020-03-05",
        message="테스트 로그 삭제",
        change_type="comment_or_log",
        file_path=FILE,
        symbol=FN,
        feature_docs=docs,
    )
    # v2.5: log/dev-reference is not attached to Commit 상세
    assert link is None


def test_date_logic_doc_links_as_commit_or_feature():
    item = _item(
        title="후불 청소년 카드 날짜비교 로직 삭제",
        file_name="프로그램변경내역서_20211218_V225_휴대용정산기.pptx",
        functions=[FN],
        csr="C20211201_001",
        bg="날짜 비교 로직 삭제",
        to_be="하드코딩 날짜 비교 제거",
        cache_id=2,
    )
    docs = collect_feature_documents(
        _evidence([], [], items=[item]), FN, file_path=FILE
    )
    link = build_ppt_link_for_entry(
        commit_hash="datehash0000000000000000000000000000001",
        commit_date="2021-12-10",
        message="날짜 하드코딩 부분 삭제",
        change_type="date_logic_change",
        file_path=FILE,
        symbol=FN,
        feature_docs=docs,
    )
    # Without confirmed body Diff + hash, maintenance docs stay function-level.
    assert link is None or link.link_type in {LINK_COMMIT_DIRECT, LINK_FEATURE_RELEASE}


def test_delete_doc_not_feature_release_on_creation():
    item = _item(
        title="후불 청소년 카드 날짜비교 로직 삭제",
        file_name="프로그램변경내역서_20211218_V225_휴대용정산기.pptx",
        functions=[FN],
        csr="C20211201_001",
        bg="날짜 비교 로직 삭제",
        to_be="하드코딩 날짜 비교 제거",
        cache_id=2,
    )
    docs = collect_feature_documents(
        _evidence([], [], items=[item]), FN, file_path=FILE
    )
    link = build_ppt_link_for_entry(
        commit_hash="create000000000000000000000000000000001",
        commit_date="2020-02-26",
        message="add function",
        change_type="function_creation",
        file_path=FILE,
        symbol=FN,
        feature_docs=docs,
        creation_date="2020-02-26",
        function_range_confirmed=True,
        diff_available=True,
    )
    assert link is None or link.link_type not in {LINK_COMMIT_DIRECT, LINK_FEATURE_RELEASE}


def test_apply_and_delete_actions_differ():
    assert classify_change_action("청소년 후불카드 적용") == "apply"
    assert classify_change_action("후불 청소년 카드 날짜비교 로직 삭제") == "delete"


def test_search_token_order_independent():
    assert search_token_sets_equivalent("청소년 후불", "후불 청소년")


def test_primary_title_prefers_apply_not_delete():
    from app.services.lifecycle_ppt import PptLink

    links = [
        PptLink(
            document_name="2021.pptx",
            change_title="후불 청소년 카드 날짜비교 로직 삭제",
            link_type=LINK_MAINTENANCE,
            change_action="delete",
            phase="maintenance",
            document_date="2021-12-18",
        ),
        PptLink(
            document_name="2020.pptx",
            change_title="청소년 후불카드 적용",
            link_type=LINK_FEATURE_RELEASE,
            change_action="apply",
            phase="development",
            document_date="2020-02-24",
        ),
    ]
    assert pick_primary_feature_title(links) == "청소년 후불카드 적용"


def test_related_paths_and_symbols_separated():
    item = _item(
        title="청소년 후불카드 적용",
        file_name="프로그램변경내역서_20200224.pptx",
        functions=["card_mif_post_check_valid_birthday_ usertype()", "Card/mif_post/src/x.c"],
        paths=["Card/mif_post/src/card_mif_postpay.c"],
    )
    # Put path into functions list intentionally (noisy PPT cell).
    item.source_functions = [
        {
            "file_path": "Card/mif_post/src/card_mif_postpay.c",
            "functions": [
                "card_mif_post_check_valid_birthday_ usertype()",
                "Card/sc_kscc/src/card_sc_tm.c",
            ],
            "raw_text": "Card/mif_post/src/card_mif_postpay.c - card_mif_post_check_valid_birthday_ usertype()",
        }
    ]
    paths = extract_related_source_paths(item)
    symbols = extract_related_symbols(item)
    assert any("card_mif_postpay.c" in p for p in paths)
    assert all(not p.endswith("()") for p in paths)
    assert FN in symbols or any(FN in s for s in symbols)
    assert all("/" not in s and "\\" not in s for s in symbols)


def test_two_official_docs_counted(monkeypatch):
    creation_diff = (
        f"@@\n+static int {FN}(int a)\n+{{\n+  return 0;\n+}}\n+int z=1;\n"
    )
    date_diff = (
        f"@@\n static int {FN}(int a)\n {{\n"
        f"-  if (date < APPLY_DATE) return 0;\n"
        f"+  return 1;\n"
        f" }}\n"
    )
    g1 = _git(
        commit_hash="e111111111111111111111111111111111111111",
        commit_date="2020-02-26",
        message="add fn",
        commit_id=1,
    )
    g2 = _git(
        commit_hash="e222222222222222222222222222222222222222",
        commit_date="2021-12-10",
        message="날짜 하드코딩 부분 삭제",
        commit_id=2,
    )
    apply_item = _item(
        title="청소년 후불카드 적용",
        file_name="프로그램변경내역서_20200224_V129_V208_휴대용정산기.pptx",
        functions=[FN],
        cache_id=1,
    )
    delete_item = _item(
        title="후불 청소년 카드 날짜비교 로직 삭제",
        file_name="프로그램변경내역서_20211218_V225_휴대용정산기.pptx",
        functions=[FN],
        csr="C2021",
        bg="날짜비교 삭제",
        to_be="날짜 비교 제거",
        cache_id=2,
    )
    er = _evidence([], [g1, g2], items=[apply_item, delete_item])

    def fake_parent(commit_id, file_path, symbol):
        return False if commit_id == 1 else True

    monkeypatch.setattr(
        "app.services.function_git_lifecycle_service.ancestor_file_has_function_definition",
        fake_parent,
    )
    monkeypatch.setattr(
        "app.services.function_git_lifecycle_service.fetch_symbol_git_rows",
        lambda *a, **k: [],
    )
    monkeypatch.setattr(
        "app.services.change_item_cache_service.list_change_items_for_equipment",
        lambda *a, **k: [],
    )

    def fake_resolve(commit_id, file_path, scope_path=None):
        diff = creation_diff if commit_id == 1 else date_diff
        return {
            "id": commit_id,
            "commit_id": commit_id,
            "file_path": file_path,
            "diff": diff,
            "additions": 1,
            "deletions": 1,
            "change_type": "modified",
        }, "exact_git_change"

    monkeypatch.setattr(
        "app.services.function_git_lifecycle_service.resolve_git_change_record",
        fake_resolve,
    )
    result = resolve_function_git_lifecycle(er, FN, file_path=FILE)
    md = result.document_text
    assert "청소년 후불카드 적용" in md
    assert "날짜비교 로직 삭제" in md or "날짜비교" in md
    # Primary feature title line removed by policy
    assert "주요 기능:" not in md
    create_entry = next(e for e in result.entries if e.commit_id == 1)
    if create_entry.ppt_link is not None:
        assert create_entry.ppt_link.change_action != "delete"
    assert result.debug["lifecycle_summary"]["ppt_official_doc_count"] >= 2
    assert "## 변경 상세" in md
    assert "### 후속 Git 유지보수" not in md
    assert "## 관련 문서" in md


def test_message_promotes_log_cleanup_out_of_unconfirmed():
    change_type, desc, conf, reason, is_core = analyze_function_commit(
        diff=None,
        symbol=FN,
        message="청소년 후불 테스트 로그 삭제",
        parent_has_function=True,
        diff_available=False,
    )
    assert change_type == "comment_or_log"
    assert is_core is False
    assert "로그" in desc


def test_message_promotes_card_type():
    change_type, desc, conf, reason, is_core = analyze_function_commit(
        diff=None,
        symbol=FN,
        message="청소년 구후불 적용일 이전에도 청소년·어린이 카드 타입 적용",
        parent_has_function=True,
        diff_available=False,
    )
    assert change_type == "card_type_setting"
    assert is_core is False  # v2.5: message-only → 연관 Git 이력


def test_body_description_skips_declaration_sample():
    from app.services.function_git_lifecycle_service import _build_body_description

    stats = {
        "added_samples": [f"static int {FN}(int a);", "type = YOUTH;"],
        "deleted_samples": ["type = ADULT;"],
    }
    desc = _build_body_description("card_type_setting", stats, None, FN)
    assert "static int" not in desc
    assert "YOUTH" in desc or "카드" in desc


def test_markdown_consistency_entry_and_citations(monkeypatch):
    creation_diff = (
        f"@@\n+static int {FN}(int a)\n+{{\n+  return 0;\n+}}\n+int z=1;\n"
    )
    g = _git(
        commit_hash="ddd4444444444444444444444444444444444444",
        commit_date="2020-02-26",
        message="add fn",
        commit_id=1,
    )
    item = _item(
        title="청소년 후불카드 적용",
        file_name="프로그램변경내역서_20200224.pptx",
        functions=[FN],
    )
    er = _evidence([], [g], items=[item])
    _patch(monkeypatch, {1: creation_diff})
    result = resolve_function_git_lifecycle(er, FN, file_path=FILE)
    md = result.document_text
    assert "변경내역서 근거 없음" not in md
    assert any("변경내역서" in c for c in result.citation_lines)
    # No primary section titled 확인 필요
    assert "### 1. 확인 필요" not in md
    assert "확인 필요 후보" not in md


def test_path_segments_not_parsed_as_symbols():
    item = _item(
        title="청소년 후불카드 적용",
        file_name="프로그램변경내역서_20200224.pptx",
        functions=["Lib", "src", "Card", "mif_post", "include", FN],
        paths=[
            "Lib/libcommon/include/card_common.h",
            "Card/mif_post/src/card_mif_postpay.c",
            "Card/sc_kscc/src/sard_sc_tm.c",
        ],
    )
    # Simulate polluted functions list + path raw_text split hazard.
    item.source_functions = [
        {
            "file_path": "Card/mif_post/src/card_mif_postpay.c",
            "functions": ["Lib", "libcommon", "include", "Card", "mif_post", "src", "sc_kscc", FN],
            "raw_text": (
                "Lib/libcommon/include/card_common.h\n"
                "Card/mif_post/src/card_mif_postpay.c\n"
                "Card/sc_kscc/src/sard_sc_tm.c\n"
                f"{FN}()"
            ),
        }
    ]
    symbols = extract_related_symbols(item)
    paths = extract_related_source_paths(item)
    banned = {
        "Lib",
        "libcommon",
        "include",
        "Card",
        "mif_post",
        "src",
        "sc_kscc",
        "card_mif_postpay",
        "card_common",
        "sard_sc_tm",
        "hCard",
        "subwaylib",
        "card_",
        "mif_postpay",
    }
    assert not (set(symbols) & banned)
    assert FN in symbols
    assert any("sard_sc_tm.c" in p for p in paths)
    assert any("card_common.h" in p for p in paths)


def test_path_stems_and_cross_line_joins_not_symbols():
    """Path lines must not become symbols; only underscore-wrap joins allowed."""
    item = _item(
        title="적용",
        file_name="프로그램변경내역서_20200224_휴대용정산기.pptx",
        functions=[],
    )
    item.source_functions = [
        {
            "file_path": "Card/mif_post/src/card_mif_postpay.c",
            "functions": [
                "card_mif_post_check_valid_birthday_\nusertype()",
            ],
            "raw_text": (
                "Lib/subwaylib/hCard/src/x.c\n"
                "Card/mif_post/src/card_mif_postpay.c\n"
                "card_mif_post_check_valid_birthday_\n"
                " usertype()\n"
                "card_common.h\n"
            ),
        }
    ]
    symbols = extract_related_symbols(item)
    banned = {
        "card_mif_postpay",
        "hCard",
        "subwaylib",
        "card_",
        "mif_postpay",
        "card_common",
        "sard_sc_tm",
    }
    assert FN in symbols
    assert not (set(s.lower() for s in symbols) & {b.lower() for b in banned})


def test_spaced_ppt_symbol_matches_and_counts_two_official(monkeypatch):
    """PPT 'birthday_ usertype()' must match Git symbol and keep 2020+2021 docs."""
    creation_diff = (
        f"@@\n+static int {FN}(int a)\n+{{\n+  return 0;\n+}}\n+int z=1;\n"
    )
    date_diff = (
        f"@@\n static int {FN}(int a)\n {{\n"
        f"-  if (date < APPLY_DATE) return 0;\n"
        f"+  return 1;\n"
        f" }}\n"
    )
    g1 = _git(
        commit_hash="s111111111111111111111111111111111111111",
        commit_date="2020-02-26",
        message="add fn",
        commit_id=1,
    )
    g2 = _git(
        commit_hash="s222222222222222222222222222222222222222",
        commit_date="2021-12-10",
        message="날짜 하드코딩 부분 삭제",
        commit_id=2,
    )
    apply_item = _item(
        title="청소년 후불카드 적용",
        file_name="프로그램변경내역서_20200224_V129_V208_휴대용정산기.pptx",
        functions=["card_mif_post_check_valid_birthday_ usertype()"],
        cache_id=1,
        slide_no=2,
    )
    apply_item.source_functions = [
        {
            "file_path": f"Card/{FILE}",
            "functions": ["card_mif_post_check_valid_birthday_ usertype()"],
            "raw_text": (
                f"Card/{FILE}\n"
                "card_mif_post_check_valid_birthday_\n"
                " usertype()"
            ),
        }
    ]
    delete_item = _item(
        title="후불 청소년 카드 날짜비교 로직 삭제",
        file_name="프로그램변경내역서_20211218_V225_휴대용정산기.pptx",
        functions=[FN],
        csr="C2021",
        bg="날짜비교 삭제",
        to_be="날짜 비교 제거",
        cache_id=2,
        slide_no=5,
    )
    noise = _item(
        title="기후동행카드 서비스 개발 건",
        file_name="기후동행.pptx",
        functions=[],
        paths=[f"Card/{FILE}"],
        cache_id=77,
        bg="기후동행",
        to_be="기후동행",
    )
    noise.source_functions = [
        {"file_path": f"Card/{FILE}", "functions": [], "raw_text": f"Card/{FILE}"}
    ]
    assert item_mentions_symbol(apply_item, FN) is True
    er = _evidence([], [g1, g2], items=[apply_item, delete_item, noise])

    def fake_parent(commit_id, file_path, symbol):
        return False if commit_id == 1 else True

    monkeypatch.setattr(
        "app.services.function_git_lifecycle_service.ancestor_file_has_function_definition",
        fake_parent,
    )
    monkeypatch.setattr(
        "app.services.function_git_lifecycle_service.fetch_symbol_git_rows",
        lambda *a, **k: [],
    )
    monkeypatch.setattr(
        "app.services.change_item_cache_service.list_change_items_for_equipment",
        lambda *a, **k: [],
    )

    def fake_resolve(commit_id, file_path, scope_path=None):
        diff = creation_diff if commit_id == 1 else date_diff
        return {
            "id": commit_id,
            "commit_id": commit_id,
            "file_path": file_path,
            "diff": diff,
            "additions": 1,
            "deletions": 1,
            "change_type": "modified",
        }, "exact_git_change"

    monkeypatch.setattr(
        "app.services.function_git_lifecycle_service.resolve_git_change_record",
        fake_resolve,
    )
    result = resolve_function_git_lifecycle(er, FN, file_path=FILE)
    md = result.document_text
    assert result.debug["lifecycle_summary"]["ppt_official_doc_count"] == 2
    assert "청소년 후불카드 적용" in md
    assert "## 관련 문서" in md
    assert "기후동행" not in md
    assert "연결된 변경내역서 없음" not in md
    assert any("변경내역서" in c for c in result.citation_lines)
    assert len([c for c in result.citation_lines if "변경내역서" in c]) == 2


def test_path_only_shared_source_not_official():
    """Unrelated docs that only share card_mif_postpay.c must not become official."""
    path_only = _item(
        title="기후동행카드 서비스 개발 건",
        file_name="프로그램변경내역서_20241115_기후동행.pptx",
        functions=[],  # no target symbol
        paths=[f"Card/{FILE}"],
        cache_id=99,
        bg="기후동행카드",
        to_be="기후동행 요금 처리",
    )
    path_only.source_functions = [
        {
            "file_path": f"Card/{FILE}",
            "functions": [],
            "raw_text": f"Card/{FILE}",
        }
    ]
    apply = _item(
        title="청소년 후불카드 적용",
        file_name="프로그램변경내역서_20200224_V129_V208_휴대용정산기.pptx",
        functions=[FN],
        cache_id=1,
        slide_no=2,
    )
    docs = collect_feature_documents(
        _evidence([], [], items=[path_only, apply]), FN, file_path=FILE
    )
    titles = {d.change_title for d in docs}
    assert "청소년 후불카드 적용" in titles
    assert "기후동행카드 서비스 개발 건" not in titles

    link = build_ppt_link_for_entry(
        commit_hash="create000000000000000000000000000000001",
        commit_date="2020-02-26",
        message="청소년 후불카드 적용",
        change_type="function_creation",
        file_path=FILE,
        symbol=FN,
        feature_docs=docs,
        creation_date="2020-02-26",
        function_range_confirmed=True,
        diff_available=True,
    )
    # Topic-aligned creation may stage-link; path-only climate doc must not win.
    if link is not None:
        assert link.change_title == "청소년 후불카드 적용"
        assert "기후동행" not in (link.change_title or "")

    # Even if a path-only doc is forced into feature_docs, linking must refuse it.
    forced = collect_feature_documents(
        _evidence([], [], items=[apply]), FN, file_path=FILE
    )
    # Manually inject path-only FeatureDocument
    from app.services.lifecycle_ppt import FeatureDocument

    forced.append(FeatureDocument(item=path_only))
    bad = build_ppt_link_for_entry(
        commit_hash="create000000000000000000000000000000001",
        commit_date="2020-02-26",
        message="기후동행 관련 수정",
        change_type="body_change",
        file_path=FILE,
        symbol=FN,
        feature_docs=[FeatureDocument(item=path_only)],
        creation_date="2020-02-26",
        function_range_confirmed=True,
        diff_available=True,
    )
    assert bad is None


def test_path_only_not_in_stage_official_or_counts(monkeypatch):
    creation_diff = (
        f"@@\n+static int {FN}(int a)\n+{{\n+  return 0;\n+}}\n+int z=1;\n"
    )
    date_diff = (
        f"@@\n static int {FN}(int a)\n {{\n"
        f"-  if (date < APPLY_DATE) return 0;\n"
        f"+  return 1;\n"
        f" }}\n"
    )
    g1 = _git(
        commit_hash="p111111111111111111111111111111111111111",
        commit_date="2020-02-26",
        message="add fn",
        commit_id=1,
    )
    g2 = _git(
        commit_hash="p222222222222222222222222222222222222222",
        commit_date="2021-12-10",
        message="날짜 하드코딩 부분 삭제",
        commit_id=2,
    )
    apply_item = _item(
        title="청소년 후불카드 적용",
        file_name="프로그램변경내역서_20200224_V129_V208_휴대용정산기.pptx",
        functions=[FN],
        cache_id=1,
    )
    delete_item = _item(
        title="후불 청소년 카드 날짜비교 로직 삭제",
        file_name="프로그램변경내역서_20211218_V225_휴대용정산기.pptx",
        functions=[FN],
        csr="C2021",
        bg="날짜비교 삭제",
        to_be="날짜 비교 제거",
        cache_id=2,
    )
    noise = _item(
        title="기후동행카드 서비스 개발 건",
        file_name="기후동행_20241115.pptx",
        functions=[],
        paths=[f"Card/{FILE}"],
        cache_id=50,
        bg="기후동행",
        to_be="기후동행",
    )
    noise.source_functions = [
        {"file_path": f"Card/{FILE}", "functions": [], "raw_text": f"Card/{FILE}"}
    ]
    fare = _item(
        title="경기버스 요금인상",
        file_name="경기버스_요금.pptx",
        functions=[],
        paths=[f"Card/{FILE}"],
        cache_id=51,
        bg="요금인상",
        to_be="요금 변경",
    )
    fare.source_functions = [
        {"file_path": f"Card/{FILE}", "functions": [], "raw_text": f"Card/{FILE}"}
    ]
    er = _evidence(
        [], [g1, g2], items=[apply_item, delete_item, noise, fare]
    )

    def fake_parent(commit_id, file_path, symbol):
        return False if commit_id == 1 else True

    monkeypatch.setattr(
        "app.services.function_git_lifecycle_service.ancestor_file_has_function_definition",
        fake_parent,
    )
    monkeypatch.setattr(
        "app.services.function_git_lifecycle_service.fetch_symbol_git_rows",
        lambda *a, **k: [],
    )
    monkeypatch.setattr(
        "app.services.change_item_cache_service.list_change_items_for_equipment",
        lambda *a, **k: [],
    )

    def fake_resolve(commit_id, file_path, scope_path=None):
        diff = creation_diff if commit_id == 1 else date_diff
        return {
            "id": commit_id,
            "commit_id": commit_id,
            "file_path": file_path,
            "diff": diff,
            "additions": 1,
            "deletions": 1,
            "change_type": "modified",
        }, "exact_git_change"

    monkeypatch.setattr(
        "app.services.function_git_lifecycle_service.resolve_git_change_record",
        fake_resolve,
    )
    result = resolve_function_git_lifecycle(er, FN, file_path=FILE)
    md = result.document_text
    summary = result.debug["lifecycle_summary"]
    assert summary["ppt_official_doc_count"] == 2
    assert "기후동행" not in md
    assert "경기버스" not in md
    assert "청소년 후불카드 적용" in md
    assert "날짜비교" in md or "날짜 비교" in md
    assert "주요 기능:" not in md
    assert all("기후동행" not in c for c in result.citation_lines)


def test_stage_docs_count_when_only_log_links(monkeypatch):
    """Official apply doc must remain even if only log commits got DEV_REFERENCE."""
    creation_diff = (
        f"@@\n+static int {FN}(int a)\n+{{\n+  return 0;\n+}}\n+int z=1;\n"
    )
    log_diff = "@@\n- printf(\"debug\");\n+ \n"
    g1 = _git(
        commit_hash="a111111111111111111111111111111111111111",
        commit_date="2020-02-26",
        message="add fn",
        commit_id=1,
    )
    g2 = _git(
        commit_hash="a222222222222222222222222222222222222222",
        commit_date="2020-03-05",
        message="테스트 로그 삭제",
        commit_id=2,
    )
    g3 = _git(
        commit_hash="a333333333333333333333333333333333333333",
        commit_date="2021-12-10",
        message="날짜 하드코딩 부분 삭제",
        commit_id=3,
    )
    apply_item = _item(
        title="청소년 후불카드 적용",
        file_name="프로그램변경내역서_20200224_V129_V208_휴대용정산기.pptx",
        functions=[FN],
        cache_id=1,
        slide_no=2,
    )
    delete_item = _item(
        title="후불 청소년 카드 날짜비교 로직 삭제",
        file_name="프로그램변경내역서_20211218_V225_휴대용정산기.pptx",
        functions=[FN],
        csr="C2021",
        bg="날짜비교 삭제",
        to_be="날짜 비교 제거",
        cache_id=2,
        slide_no=5,
    )
    er = _evidence([], [g1, g2, g3], items=[apply_item, delete_item])

    def fake_parent(commit_id, file_path, symbol):
        return False if commit_id == 1 else True

    monkeypatch.setattr(
        "app.services.function_git_lifecycle_service.ancestor_file_has_function_definition",
        fake_parent,
    )
    monkeypatch.setattr(
        "app.services.function_git_lifecycle_service.fetch_symbol_git_rows",
        lambda *a, **k: [],
    )
    monkeypatch.setattr(
        "app.services.change_item_cache_service.list_change_items_for_equipment",
        lambda *a, **k: [],
    )

    def fake_resolve(commit_id, file_path, scope_path=None):
        diffs = {1: creation_diff, 2: log_diff, 3: (
            f"@@\n static int {FN}(int a)\n {{\n"
            f"-  if (date < APPLY_DATE) return 0;\n"
            f"+  return 1;\n"
            f" }}\n"
        )}
        return {
            "id": commit_id,
            "commit_id": commit_id,
            "file_path": file_path,
            "diff": diffs[commit_id],
            "additions": 1,
            "deletions": 1,
            "change_type": "modified",
        }, "exact_git_change"

    monkeypatch.setattr(
        "app.services.function_git_lifecycle_service.resolve_git_change_record",
        fake_resolve,
    )
    result = resolve_function_git_lifecycle(er, FN, file_path=FILE)
    md = result.document_text
    summary = result.debug["lifecycle_summary"]
    assert summary["ppt_official_doc_count"] >= 2
    assert "## 관련 문서" in md
    assert "청소년 후불카드 적용" in md
    assert any("20200224" in c or "청소년 후불" in c for c in result.citation_lines)
    create_entry = next(e for e in result.entries if e.commit_id == 1)
    if create_entry.ppt_link is not None:
        assert create_entry.ppt_link.link_type == LINK_FEATURE_RELEASE
    # Log-only Diff without target-function evidence is excluded (false-positive filter).
    assert not any(e.commit_id == 2 for e in result.entries)
    assert any(
        (x.get("commit_hash") or "").startswith("a222")
        and x.get("reason") == "symbol_not_in_diff"
        for x in (result.debug.get("excluded_commits") or [])
    )
    assert any(e.commit_id == 3 for e in result.entries)

def test_other_equipment_docs_excluded_from_official(monkeypatch):
    """Same shared document_path / discovery equipment_id must not promote other-equipment PPT."""
    creation_diff = (
        f"@@\n+static int {FN}(int a)\n+{{\n+  return 0;\n+}}\n+int z=1;\n"
    )
    date_diff = (
        f"@@\n static int {FN}(int a)\n {{\n"
        f"-  if (date < APPLY_DATE) return 0;\n"
        f"+  return 1;\n"
        f" }}\n"
    )
    g1 = _git(
        commit_hash="eq11111111111111111111111111111111111111",
        commit_date="2020-02-26",
        message="add fn",
        commit_id=1,
    )
    g2 = _git(
        commit_hash="eq22222222222222222222222222222222222222",
        commit_date="2021-12-10",
        message="날짜 하드코딩 부분 삭제",
        commit_id=2,
    )
    portable_apply = _item(
        title="청소년 후불카드 적용",
        file_name="프로그램변경내역서_20200224_V129_V208_휴대용정산기.pptx",
        functions=[FN],
        cache_id=1,
    )
    # Same discovery equipment_id as request (shared document_path cache).
    portable_apply.equipment_id = 1
    portable_maint = _item(
        title="후불 청소년 카드 날짜비교 로직 삭제",
        file_name="프로그램변경내역서_20211218_V225_휴대용정산기.pptx",
        functions=[FN],
        csr="C2021",
        bg="날짜비교 삭제",
        to_be="날짜 비교 제거",
        cache_id=2,
    )
    portable_maint.equipment_id = 1
    other_equip = _item(
        title="청소년 후불카드 적용",
        file_name="프로그램변경내역서 20200228_V1.37_개집표기.pptx",
        functions=[FN],
        csr="C2020",
        cache_id=99,
        slide_no=3,
        bg="청소년 후불카드",
        to_be="청소년 후불카드 적용",
    )
    # Critical: same document_cache.equipment_id as portable (shared folder discovery).
    other_equip.equipment_id = 1
    other_equip.document_cache_id = 99
    er = _evidence(
        [],
        [g1, g2],
        items=[portable_apply, portable_maint, other_equip],
        equipment_name="휴대용정산기",
    )

    monkeypatch.setattr(
        "app.services.lifecycle_ppt._load_known_equipment",
        lambda: [(1, "휴대용정산기"), (2, "개집표기")],
    )

    def fake_parent(commit_id, file_path, symbol):
        return False if commit_id == 1 else True

    monkeypatch.setattr(
        "app.services.function_git_lifecycle_service.ancestor_file_has_function_definition",
        fake_parent,
    )
    monkeypatch.setattr(
        "app.services.function_git_lifecycle_service.fetch_symbol_git_rows",
        lambda *a, **k: [],
    )
    monkeypatch.setattr(
        "app.services.change_item_cache_service.list_change_items_for_equipment",
        lambda *a, **k: [],
    )

    def fake_resolve(commit_id, file_path, scope_path=None):
        diff = creation_diff if commit_id == 1 else date_diff
        return {
            "id": commit_id,
            "commit_id": commit_id,
            "file_path": file_path,
            "diff": diff,
            "additions": 1,
            "deletions": 1,
            "change_type": "modified",
        }, "exact_git_change"

    monkeypatch.setattr(
        "app.services.function_git_lifecycle_service.resolve_git_change_record",
        fake_resolve,
    )
    result = resolve_function_git_lifecycle(er, FN, file_path=FILE)
    md = result.document_text
    assert result.debug["lifecycle_summary"]["ppt_official_doc_count"] == 2
    assert "개집표기" not in md
    assert all("개집표기" not in c for c in result.citation_lines)
    assert "| 관련 문서 | 2건 |" in md
    assert "공식 적용" not in md
    assert "## 관련 문서" in md
    ppt_citations = [c for c in result.citation_lines if "변경내역서" in c]
    assert len(ppt_citations) == 2


def test_diff_unavailable_not_shown_as_commit_direct(monkeypatch):
    """Diff 미확보 + message-only Commit은 함수 lifecycle에서 제외한다."""
    g = _git(
        commit_hash="f355272aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
        commit_date="2020-03-01",
        message="청소년 카드 유형 설정",
        commit_id=55,
    )
    item = _item(
        title="청소년 후불카드 적용",
        file_name="프로그램변경내역서_20200224_V129_V208_휴대용정산기.pptx",
        functions=[FN],
    )
    er = _evidence([], [g], items=[item])
    monkeypatch.setattr(
        "app.services.function_git_lifecycle_service.ancestor_file_has_function_definition",
        lambda *a, **k: True,
    )
    monkeypatch.setattr(
        "app.services.function_git_lifecycle_service.fetch_symbol_git_rows",
        lambda *a, **k: [],
    )
    monkeypatch.setattr(
        "app.services.change_item_cache_service.list_change_items_for_equipment",
        lambda *a, **k: [],
    )
    monkeypatch.setattr(
        "app.services.function_git_lifecycle_service.resolve_git_change_record",
        lambda *a, **k: (None, "unavailable"),
    )
    result = resolve_function_git_lifecycle(er, FN, file_path=FILE)
    md = result.document_text
    assert not any(e.commit_hash.startswith("f355272") for e in result.entries)
    excluded = result.debug.get("excluded_commits") or []
    assert any(
        (x.get("commit_hash") or "").startswith("f355272")
        and x.get("reason") in {
            "diff_unavailable",
            "message_topic",
            "message_card_type",
            "message_only",
        }
        for x in excluded
    )
    # Official docs may still appear via stage collection; never as this Commit's direct link.
    assert "연결 유형: Commit 직접 근거" not in md or "f355272" not in md


def test_old_document_not_stage_linked_to_undiffed_distant_commit():
    """PROJECT_SPEC v2.4 §11 — a commit with no confirmed direct Diff of the
    target function (related_candidate) must not be stage-linked to a document
    from a far (multi-year) time band without message/document topic overlap.
    """
    item = _item(
        title="재승차 10분 이내 환승 처리 개선",
        file_name="프로그램변경내역서_20230110_V210_휴대용정산기.pptx",
        functions=[FN],
        csr="C2023",
        bg="재승차 시간 조정",
        to_be="10분 이내 재승차 판정 개선",
    )
    docs = collect_feature_documents(
        _evidence([], [], items=[item]), FN, file_path=FILE
    )
    link = build_ppt_link_for_entry(
        commit_hash="farhash00000000000000000000000000000001",
        commit_date="2025-01-08",
        message="선의무표시 강제할인 적용 (공항철도 독립구간)",
        change_type="related_candidate",
        file_path=FILE,
        symbol=FN,
        feature_docs=docs,
        diff_available=True,
        function_range_confirmed=False,
    )
    assert link is None or link.link_type != LINK_FEATURE_RELEASE


def test_symbol_not_listed_downgrades_related_function_wording():
    """PROJECT_SPEC v2.4 §11 — when the document's own related-function list
    does not contain the target symbol (it only appears loosely in free text),
    the "대상 함수가 관련 함수로 확인됩니다" wording must not be generated and
    the link must not be promoted to a stage (feature_release) link."""
    item = _item(
        title="청소년 후불카드 적용",
        file_name="프로그램변경내역서_20200224_V129_휴대용정산기.pptx",
        functions=["other_unrelated_function"],
        bg=f"관련 배경 설명 중 {FN} 이 언급됨",
        to_be="구후불에 청소년 유형 추가",
    )
    docs = collect_feature_documents(
        _evidence([], [], items=[item]), FN, file_path=FILE
    )
    assert docs, "loose text mention should still surface as a recall candidate"
    link = build_ppt_link_for_entry(
        commit_hash="notlisted000000000000000000000000000001",
        commit_date="2020-03-01",
        message="청소년 카드 유형 설정",
        change_type="card_type_setting",
        file_path=FILE,
        symbol=FN,
        feature_docs=docs,
        diff_available=False,
    )
    if link is not None:
        assert link.link_type != LINK_FEATURE_RELEASE
        assert "대상 함수가 관련 함수로 확인됩니다" not in link.link_reason_user


def test_direct_diff_link_unaffected_by_symbol_listed_gate():
    """Existing accurate direct/exact commit-diff links must not regress when
    the function is properly listed in the document's related-function list."""
    item = _item(
        title="청소년 후불카드 적용",
        file_name="프로그램변경내역서_20200224_V129_휴대용정산기.pptx",
        functions=[FN],
    )
    docs = collect_feature_documents(
        _evidence([], [], items=[item]), FN, file_path=FILE
    )
    diff = "\n".join(
        [
            f"+void {FN}(void)",
            "+{",
            "+    return;",
            "+    x++;",
            "+}",
        ]
    )
    from app.services.function_git_lifecycle_service import _parse_diff_stats

    stats = _parse_diff_stats(diff, FN)
    link = build_ppt_link_for_entry(
        commit_hash="create000000000000000000000000000000001",
        commit_date="2020-02-26",
        message="청소년 후불카드 적용",
        change_type="function_creation",
        file_path=FILE,
        symbol=FN,
        feature_docs=docs,
        creation_date="2020-02-26",
        # Creation Diff with +def lines is treated as confirmed function scope.
        function_range_confirmed=True,
        diff_available=True,
    )
    assert link is not None
    assert link.link_type in {LINK_COMMIT_DIRECT, LINK_FEATURE_RELEASE}
    assert (
        "관련 함수 목록에 명시" in link.link_reason_user
        or "Diff와 문서" in link.link_reason_user
        or link.link_type == LINK_COMMIT_DIRECT
    )


def test_far_time_band_does_not_block_stage_link_with_topic_overlap():
    """PROJECT_SPEC v2.4 §11.5 — far time_band must not be a mandatory dropout;
    stage linking still requires explicit topic/symbol evidence."""
    item = _item(
        title="재승차 10분 이내 환승 처리 개선",
        file_name="프로그램변경내역서_20230110_V210_휴대용정산기.pptx",
        functions=[FN],
        csr="C2023",
        bg="재승차 시간 조정",
        to_be="10분 이내 재승차 판정 개선",
    )
    docs = collect_feature_documents(
        _evidence([], [], items=[item]), FN, file_path=FILE
    )
    link = build_ppt_link_for_entry(
        commit_hash="farhash00000000000000000000000000000002",
        commit_date="2025-01-08",
        message="재승차 10분 판정 보완",
        change_type="related_candidate",
        file_path=FILE,
        symbol=FN,
        feature_docs=docs,
        diff_available=True,
        function_range_confirmed=False,
    )
    assert link is not None
    assert link.link_type == LINK_FEATURE_RELEASE
    assert "시점 차이" in link.link_reason_user or "차이가 큽" in link.link_reason_user
