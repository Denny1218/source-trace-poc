"""TRACE_LINK_MIN_SCORE config name and env override checks."""

from __future__ import annotations

import importlib


def test_config_name_is_trace_link_min_score():
    from app.core import link_score_config

    assert hasattr(link_score_config, "TRACE_LINK_MIN_SCORE")
    assert not hasattr(link_score_config, "TRACE_LINM_MIN_SCORE")
    assert link_score_config.TRACE_LINK_MIN_SCORE == 10


def test_env_override_applies(monkeypatch):
    monkeypatch.setenv("TRACE_LINK_MIN_SCORE", "25")
    from app.core import link_score_config

    importlib.reload(link_score_config)
    try:
        assert link_score_config.TRACE_LINK_MIN_SCORE == 25
    finally:
        monkeypatch.delenv("TRACE_LINK_MIN_SCORE", raising=False)
        importlib.reload(link_score_config)
        assert link_score_config.TRACE_LINK_MIN_SCORE == 10
