"""STEP 7: Link Score rule engine tests (pure functions, synthetic data only).

No real PPT/Git data is used — all commit messages, diffs, CSR numbers, file
paths, and function names below are generic placeholders (see
PROJECT_SPEC v2 STEP 7 section 21)."""

from __future__ import annotations

from app.core.link_score_config import (
    LINK_SCORE_CONFIG,
    TRACE_LINK_MIN_SCORE,
)
from app.services.link_score_service import (
    ChangeItemEvidenceInput,
    GitEvidenceInput,
    compute_link_score,
    evaluate_gate,
)


def _git(
    file_path: str = "src/fare_calc.c",
    message: str = "",
    diff: str | None = None,
    commit_date: str | None = "2025-06-15",
) -> GitEvidenceInput:
    return GitEvidenceInput(
        file_path=file_path, message=message, diff=diff, commit_date=commit_date
    )


def _item(
    change_title: str | None = None,
    csr_no: str | None = None,
    business_background: str | None = None,
    current_status: str | None = None,
    as_is: str | None = None,
    to_be: str | None = None,
    raw_text: str | None = None,
    source_functions: list[dict] | None = None,
    file_name: str | None = None,
) -> ChangeItemEvidenceInput:
    return ChangeItemEvidenceInput(
        change_title=change_title,
        csr_no=csr_no,
        business_background=business_background,
        current_status=current_status,
        as_is=as_is,
        to_be=to_be,
        raw_text=raw_text,
        source_functions=source_functions or [],
        file_name=file_name,
    )


def _types(result) -> set[str]:
    return {r.type for r in result.match_reasons}


# --- 1-6: File Match ---


def test_file_full_path_exact():
    git = _git(file_path="subwaylib/fare/src/fare_calc.c")
    item = _item(
        source_functions=[{"file_path": "subwaylib/fare/src/fare_calc.c", "functions": []}]
    )
    result = compute_link_score(git, item)
    assert "same_file_path" in _types(result)
    assert result.score >= LINK_SCORE_CONFIG["same_file_path"]


def test_file_separator_difference_still_exact():
    git = _git(file_path="subwaylib\\fare\\src\\fare_calc.c")
    item = _item(
        source_functions=[{"file_path": "subwaylib/fare/src/fare_calc.c", "functions": []}]
    )
    result = compute_link_score(git, item)
    assert "same_file_path" in _types(result)


def test_file_path_suffix_match():
    git = _git(file_path="fare/src/fare_calc.c")
    item = _item(
        source_functions=[
            {"file_path": "subwaylib/fare/src/fare_calc.c", "functions": []}
        ]
    )
    result = compute_link_score(git, item)
    assert "same_file_path" in _types(result)


def test_file_basename_exact_match():
    git = _git(file_path="src/fare_calc.c")
    item = _item(
        source_functions=[{"file_path": "subwaylib/other/fare_calc.c", "functions": []}]
    )
    result = compute_link_score(git, item)
    assert "same_file_basename" in _types(result)


def test_file_same_basename_unrelated_extension_no_evidence():
    git = _git(file_path="fare/fare_calc.c")
    item = _item(
        source_functions=[{"file_path": "other/fare_calc.txt", "functions": []}]
    )
    result = compute_link_score(git, item)
    assert "same_file_path" not in _types(result)
    assert "same_file_basename" not in _types(result)


def test_file_partial_substring_not_match():
    git = _git(file_path="fare/fare_calc.c")
    item = _item(
        source_functions=[{"file_path": "fare/fare_calc_extended.c", "functions": []}]
    )
    result = compute_link_score(git, item)
    assert "same_file_path" not in _types(result)
    assert "same_file_basename" not in _types(result)


# --- 7-12: Symbol Match ---


def test_symbol_exact_match():
    git = _git(diff="+int calculate_fare(int cardType) {")
    item = _item(source_functions=[{"file_path": None, "functions": ["calculate_fare"]}])
    result = compute_link_score(git, item)
    assert "same_function_exact" in _types(result)


def test_symbol_trailing_parens_normalized_match():
    git = _git(diff="+int calculate_fare(int cardType) {")
    item = _item(source_functions=[{"file_path": None, "functions": ["calculate_fare()"]}])
    result = compute_link_score(git, item)
    assert "same_function_exact" in _types(result)


def test_symbol_whitespace_normalized_match():
    git = _git(diff="+int calculate_fare(int cardType) {")
    item = _item(source_functions=[{"file_path": None, "functions": ["  calculate_fare  "]}])
    result = compute_link_score(git, item)
    assert "same_function_exact" in _types(result)


def test_symbol_different_symbol_no_match():
    git = _git(diff="+int calculate_child_fare(int cardType) {")
    item = _item(source_functions=[{"file_path": None, "functions": ["calculate_fare"]}])
    result = compute_link_score(git, item)
    assert "same_function_exact" not in _types(result)


def test_symbol_substring_only_not_strong_match():
    git = _git(diff="+int calculate_fare_extended(int cardType) {")
    item = _item(source_functions=[{"file_path": None, "functions": ["calculate_fare"]}])
    result = compute_link_score(git, item)
    assert "same_function_exact" not in _types(result)


def test_symbol_invalid_free_text_not_used_for_exact_match():
    git = _git(diff="설명: 이 함수가 왜 변경됐는지 확인")
    item = _item(
        source_functions=[{"file_path": None, "functions": ["이 함수가 왜 변경됐는지"]}]
    )
    result = compute_link_score(git, item)
    assert "same_function_exact" not in _types(result)


# --- 13-16: CSR ---


def test_csr_exact_match_in_message():
    git = _git(message="C20250101_001 반영")
    item = _item(csr_no="C20250101_001")
    result = compute_link_score(git, item)
    assert "csr_exact" in _types(result)


def test_csr_case_normalization():
    git = _git(message="c20250101_001 반영")
    item = _item(csr_no="C20250101_001")
    result = compute_link_score(git, item)
    assert "csr_exact" in _types(result)


def test_csr_brackets_around_match():
    git = _git(message="[SR260529_42025] 반영")
    item = _item(csr_no="SR260529_42025")
    result = compute_link_score(git, item)
    assert "csr_exact" in _types(result)


def test_csr_colon_before_match():
    git = _git(message="CSR:SR260529_42025")
    item = _item(csr_no="SR260529_42025")
    result = compute_link_score(git, item)
    assert "csr_exact" in _types(result)


def test_csr_longer_suffix_not_exact():
    """Substring false positive: SR260529_420251 must not trigger csr_exact."""
    git = _git(message="SR260529_420251 수정")
    item = _item(csr_no="SR260529_42025")
    result = compute_link_score(git, item)
    assert "csr_exact" not in _types(result)


def test_csr_leading_identifier_not_exact():
    git = _git(message="XSR260529_42025")
    item = _item(csr_no="SR260529_42025")
    result = compute_link_score(git, item)
    assert "csr_exact" not in _types(result)


def test_csr_different_csr_no_match():
    git = _git(message="C20250101_999 반영")
    item = _item(csr_no="C20250101_001")
    result = compute_link_score(git, item)
    assert "csr_exact" not in _types(result)


def test_csr_missing_no_evidence():
    git = _git(message="C20250101_001 반영")
    item = _item(csr_no=None)
    result = compute_link_score(git, item)
    assert "csr_exact" not in _types(result)


# --- 17-23: Date ---


def test_date_same_day():
    git = _git(commit_date="2025-06-15")
    item = _item(file_name="20250615_변경내역.pptx")
    result = compute_link_score(git, item)
    assert "date_0_7_days" in _types(result)


def test_date_within_7_days():
    git = _git(commit_date="2025-06-20")
    item = _item(file_name="20250615_변경내역.pptx")
    result = compute_link_score(git, item)
    assert "date_0_7_days" in _types(result)


def test_date_within_30_days():
    git = _git(commit_date="2025-07-10")
    item = _item(file_name="20250615_변경내역.pptx")
    result = compute_link_score(git, item)
    assert "date_8_30_days" in _types(result)


def test_date_within_90_days():
    git = _git(commit_date="2025-09-01")
    item = _item(file_name="20250615_변경내역.pptx")
    result = compute_link_score(git, item)
    assert "date_31_90_days" in _types(result)


def test_date_over_90_days_no_evidence():
    git = _git(commit_date="2026-01-01")
    item = _item(file_name="20250615_변경내역.pptx")
    result = compute_link_score(git, item)
    assert not ({"date_0_7_days", "date_8_30_days", "date_31_90_days"} & _types(result))


def test_date_no_filename_date_no_evidence():
    git = _git(commit_date="2025-06-15")
    item = _item(file_name="변경내역.pptx")
    result = compute_link_score(git, item)
    assert not ({"date_0_7_days", "date_8_30_days", "date_31_90_days"} & _types(result))


def test_date_evidence_never_derived_from_modified_at():
    """ChangeItemEvidenceInput has no modified_at field at all — date evidence
    can only ever come from the document filename, never filesystem mtime."""
    assert "modified_at" not in ChangeItemEvidenceInput.__dataclass_fields__


# --- 24-29: Keyword ---


def test_keyword_commit_message_vs_change_title():
    git = _git(message="어린이 요금 정책 반영")
    item = _item(change_title="어린이 요금 할인 정책 변경")
    result = compute_link_score(git, item)
    assert "commit_message_change_title" in _types(result)


def test_keyword_korean_change_title_match():
    git = _git(message="재승차 허용 정책 수정")
    item = _item(change_title="15분 재승차 허용 기관 추가")
    result = compute_link_score(git, item)
    assert "commit_message_change_title" in _types(result)


def test_keyword_english_case_insensitive():
    git = _git(message="calcfare 함수 리팩터링")
    item = _item(change_title="CalcFare 로직 개선")
    result = compute_link_score(git, item)
    assert "commit_message_change_title" in _types(result)


def test_keyword_c_identifier_match_via_diff():
    git = _git(diff="+ DEFAULT_FARE 값 조정 관련 diff context")
    item = _item(to_be="DEFAULT_FARE 값을 1200으로 상향")
    result = compute_link_score(git, item)
    assert "diff_other_field" in _types(result)


def test_keyword_diff_vs_to_be():
    git = _git(diff="+국내 최초 청소년 요금 적용 로직 추가")
    item = _item(to_be="청소년 요금 적용 로직으로 변경")
    result = compute_link_score(git, item)
    assert "diff_other_field" in _types(result)


def test_keyword_raw_text_only_weak_match():
    git = _git(message="기타 참고사항 확인")
    item = _item(raw_text="기타 참고사항: 별도 확인 필요")
    result = compute_link_score(git, item)
    assert "raw_text_keyword" in _types(result)
    assert result.score == LINK_SCORE_CONFIG["raw_text_keyword"]


# --- 30-35: Gate ---


def test_gate_date_only_excluded():
    git = _git(commit_date="2025-06-15", message="", diff=None)
    item = _item(file_name="20250615_변경내역.pptx")
    result = compute_link_score(git, item)
    assert _types(result) == {"date_0_7_days"}
    assert result.passes_gate is False


def test_gate_no_modified_at_evidence_type_exists():
    """modified_at is never used as a Link Score input — no such evidence type
    exists in the config at all, so it can never pass the gate."""
    assert "modified_at" not in LINK_SCORE_CONFIG


def test_gate_strong_file_evidence_included():
    git = _git(file_path="src/fare_calc.c")
    item = _item(source_functions=[{"file_path": "src/fare_calc.c", "functions": []}])
    result = compute_link_score(git, item)
    assert result.passes_gate is True


def test_gate_function_evidence_included():
    git = _git(diff="+int calculate_fare(int cardType) {")
    item = _item(source_functions=[{"file_path": None, "functions": ["calculate_fare"]}])
    result = compute_link_score(git, item)
    assert result.passes_gate is True


def test_gate_csr_evidence_included():
    git = _git(message="C20250101_001 반영")
    item = _item(csr_no="C20250101_001")
    result = compute_link_score(git, item)
    assert result.passes_gate is True


def test_gate_multiple_weak_evidence_combined_included():
    git = _git(
        commit_date="2025-06-15",
        message="기타 참고사항 확인",
    )
    item = _item(
        file_name="20250615_변경내역.pptx",
        raw_text="기타 참고사항: 별도 확인 필요",
    )
    result = compute_link_score(git, item)
    assert _types(result) == {"date_0_7_days", "raw_text_keyword"}
    assert result.passes_gate is True


def test_gate_single_weak_evidence_excluded():
    git = _git(message="기타 참고사항 확인")
    item = _item(raw_text="기타 참고사항: 별도 확인 필요")
    result = compute_link_score(git, item)
    assert _types(result) == {"raw_text_keyword"}
    assert result.passes_gate is False


# --- 36-39: Ranking ---


def test_ranking_function_and_file_scores_higher_than_file_only():
    git_file_only = _git(file_path="src/fare_calc.c", diff="")
    item_file_only = _item(
        source_functions=[{"file_path": "src/fare_calc.c", "functions": []}]
    )
    file_only = compute_link_score(git_file_only, item_file_only)

    git_both = _git(file_path="src/fare_calc.c", diff="+int calculate_fare(int x) {")
    item_both = _item(
        source_functions=[
            {"file_path": "src/fare_calc.c", "functions": ["calculate_fare"]}
        ]
    )
    both = compute_link_score(git_both, item_both)

    assert both.score > file_only.score


def test_ranking_csr_and_keyword_scores_higher_than_keyword_only():
    git_keyword_only = _git(message="어린이 요금 정책 반영")
    item_keyword_only = _item(change_title="어린이 요금 할인 정책 변경")
    keyword_only = compute_link_score(git_keyword_only, item_keyword_only)

    git_both = _git(message="C20250101_001 어린이 요금 정책 반영")
    item_both = _item(csr_no="C20250101_001", change_title="어린이 요금 할인 정책 변경")
    both = compute_link_score(git_both, item_both)

    assert both.score > keyword_only.score


def test_ranking_equal_score_deterministic():
    """Same inputs always produce the same score/reasons — no randomness."""
    git = _git(file_path="src/fare_calc.c")
    item = _item(source_functions=[{"file_path": "src/fare_calc.c", "functions": []}])
    first = compute_link_score(git, item)
    second = compute_link_score(git, item)
    assert first.score == second.score
    assert [r.type for r in first.match_reasons] == [r.type for r in second.match_reasons]


def test_min_score_threshold_matches_min_two_weak_combo():
    """TRACE_LINK_MIN_SCORE never blocks the smallest gate-passing 2-weak
    combination (raw_text_keyword + date_31_90_days = 10)."""
    min_two_weak = LINK_SCORE_CONFIG["raw_text_keyword"] + LINK_SCORE_CONFIG["date_31_90_days"]
    assert TRACE_LINK_MIN_SCORE <= min_two_weak


def test_evaluate_gate_matches_compute_link_score_result():
    git = _git(message="C20250101_001 반영")
    item = _item(csr_no="C20250101_001")
    result = compute_link_score(git, item)
    assert evaluate_gate(result.match_reasons) == result.passes_gate
