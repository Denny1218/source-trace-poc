"""STEP 8 ops diagnosis: Ollama tiny-test + prompt size knobs (synthetic)."""

from __future__ import annotations

import logging

from app.schemas.trace import GitCandidate
from app.services import ollama_service
from app.services.change_item_candidate_service import ChangeItemCandidate
from app.services.evidence_service import EvidenceLink, EvidenceResult
from app.services.link_score_service import MatchReason
from app.services.ollama_service import (
    OllamaCallError,
    analyze_evidence,
    build_ollama_context,
    build_ollama_request_meta,
    run_ollama_tiny_test,
)
from app.services.query_relevance_service import QueryMatchReason


def _git() -> GitCandidate:
    return GitCandidate(
        repository_id=1,
        repository_name="repo",
        commit_id=1,
        commit_hash="abc1234",
        commit_date="2024-03-15T00:00:00",
        message="Fix file_close_init timeout",
        file_path="common/lib/src/file_save_mgt.c",
        score=10,
        match_reasons=["commit_message_keyword"],
        query_relevance_level="높음",
        query_relevance_score=40,
    )


def _item() -> ChangeItemCandidate:
    return ChangeItemCandidate(
        change_item_cache_id=1,
        document_cache_id=1,
        slide_no=3,
        file_path="docs/a.pptx",
        file_name="TEST_변경내역.pptx",
        item_no="1",
        change_title="시간초과 하차 거래 데이터 변경",
        csr_no=None,
        business_background="x" * 800,
        current_status=None,
        as_is=None,
        to_be=None,
        source_functions=[{"file_path": "file_save_mgt.c", "functions": ["file_close_init"]}],
        test_cases=[],
        applicable_scopes=[],
        raw_text="RAW_SHOULD_NEVER_APPEAR " + ("y" * 2000),
        matched_keywords=[],
        candidate_score=50,
    )


def _link(git: GitCandidate, item: ChangeItemCandidate) -> EvidenceLink:
    return EvidenceLink(
        git_candidate=git,
        change_item=item,
        link_score=75,
        match_reasons=[
            MatchReason(
                type="same_file_path",
                score=35,
                git_value="common/lib/src/file_save_mgt.c",
            ),
            MatchReason(
                type="same_function_exact",
                score=40,
                git_value="file_close_init",
            ),
        ],
        diff_excerpt="\n".join(f"+ line {i} SECRET_DIFF_MARKER" for i in range(80)),
        query_relevance_score=40,
        query_relevance_level="높음",
        query_match_reasons=[
            QueryMatchReason(
                keyword="file_close_init",
                field="commit_message",
                value=git.message,
                score=35,
                strength="core",
            )
        ],
        final_rank_score=115,
    )


def _evidence(links: list[EvidenceLink], git: GitCandidate) -> EvidenceResult:
    return EvidenceResult(
        equipment_id=1,
        query="file_close_init 함수 변경 이력을 보여줘",
        query_keywords=[],
        weak_query_terms=[],
        request_functions=["file_close_init"],
        request_files=[],
        path_scopes=[],
        git_candidates=[git],
        change_item_candidates=[links[0].change_item] if links else [],
        evidence_links=links,
        change_item_link_candidate_count=1,
        fallback_documents_parsed=0,
        change_item_total=1,
    )


def test_ollama_tiny_test_success(monkeypatch):
    monkeypatch.setattr(
        ollama_service,
        "_call_ollama_raw",
        lambda *a, **k: "안녕하세요. 테스트 응답입니다.",
    )
    result = run_ollama_tiny_test()
    assert result.ok is True
    assert result.error_type is None
    assert result.elapsed_ms >= 0
    assert "안녕" in (result.response_preview or "")


def test_ollama_tiny_test_timeout(monkeypatch):
    def _raise(*a, **k):
        raise OllamaCallError("timeout", kind="timeout")

    monkeypatch.setattr(ollama_service, "_call_ollama_raw", _raise)
    result = run_ollama_tiny_test()
    assert result.ok is False
    assert result.error_type == "timeout"
    assert result.elapsed_ms >= 0


def test_ollama_tiny_test_api(monkeypatch, client):
    monkeypatch.setattr(
        ollama_service,
        "_call_ollama_raw",
        lambda *a, **k: "한 문장 응답입니다.",
    )
    response = client.get("/api/trace/ollama-test")
    assert response.status_code == 200
    data = response.json()
    assert data["ok"] is True
    assert "elapsed_ms" in data
    assert data["response_preview"]


def test_analyze_logs_meta_without_full_prompt(monkeypatch, caplog):
    git = _git()
    item = _item()
    link = _link(git, item)
    monkeypatch.setattr(
        ollama_service,
        "_call_ollama_raw",
        lambda prompt, **k: "관련 변경은 file_close_init 정리입니다.",
    )

    with caplog.at_level(logging.INFO, logger="equipment_change_trace"):
        analyze_evidence(_evidence([link], git))

    joined = "\n".join(r.getMessage() for r in caplog.records)
    assert "Ollama request_start" in joined
    assert "Ollama request_end" in joined
    assert "prompt_chars=" in joined
    assert "elapsed_ms=" in joined
    assert "result_type=" in joined
    assert "max_diff_chars=" in joined
    assert "max_field_chars=" in joined
    # Full prompt / secrets must not appear in logs.
    assert "SECRET_DIFF_MARKER" not in joined
    assert "RAW_SHOULD_NEVER_APPEAR" not in joined
    assert "file_close_init 함수 변경 이력을 보여줘" not in joined


def test_evidence_limit_one_applies(monkeypatch):
    monkeypatch.setattr(ollama_service, "OLLAMA_MAX_EVIDENCE", 1)
    monkeypatch.setattr(ollama_service, "TRACE_ANSWER_EVIDENCE_LIMIT", 1)

    git = _git()
    item = _item()
    links = [_link(git, item), _link(git, item)]
    # Second link needs distinct identity for list length before slice.
    links[1] = EvidenceLink(
        git_candidate=git,
        change_item=item,
        link_score=10,
        match_reasons=links[0].match_reasons,
        query_relevance_score=10,
        query_relevance_level="보통",
        final_rank_score=20,
    )

    selected_links, git_only = ollama_service._select_evidence_for_context(
        _evidence(links, git)
    )
    assert len(selected_links) == 1
    assert git_only == []


def test_max_diff_chars_applied(monkeypatch):
    monkeypatch.setattr(ollama_service, "TRACE_ANSWER_MAX_DIFF_CHARS", 300)
    monkeypatch.setattr(ollama_service, "TRACE_ANSWER_MAX_FIELD_CHARS", 300)

    git = _git()
    item = _item()
    link = _link(git, item)
    prompt = build_ollama_context("q", [link], [])
    assert "RAW_SHOULD_NEVER_APPEAR" not in prompt
    # Diff excerpt truncated well below the synthetic 80-line body.
    assert prompt.count("SECRET_DIFF_MARKER") < 80
    meta = build_ollama_request_meta(
        links=[link], git_only=[], prompt_chars=len(prompt)
    )
    assert meta["max_diff_chars"] == 300
    assert meta["max_field_chars"] == 300
    assert meta["prompt_chars"] == len(prompt)
    assert meta["prompt_estimated_tokens"] == len(prompt) // 4


def test_timeout_setting_override_used_in_meta(monkeypatch):
    monkeypatch.setattr(ollama_service, "OLLAMA_TIMEOUT_SECONDS", 120.0)
    meta = build_ollama_request_meta(links=[], git_only=[_git()], prompt_chars=10)
    assert meta["timeout_seconds"] == 120.0


def test_prompt_hard_cap(monkeypatch):
    monkeypatch.setattr(ollama_service, "TRACE_ANSWER_MAX_PROMPT_CHARS", 200)
    capped, truncated = ollama_service._cap_prompt("x" * 500)
    assert truncated is True
    assert len(capped) == 200
