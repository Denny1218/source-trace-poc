"""STEP 8: Ollama Evidence Grounded Answer unit tests (synthetic only).

Ollama is never called over the network in tests — only
``ollama_service._call_ollama_raw`` is monkeypatched, per PROJECT_SPEC_v2
section 13 ("Ollama는 일반 Unit Test에서 직접 호출하지 않는다").
"""

from __future__ import annotations

from app.schemas.trace import GitCandidate
from app.services import ollama_service
from app.services.change_item_candidate_service import ChangeItemCandidate
from app.services.evidence_service import EvidenceLink, EvidenceResult
from app.services.link_score_service import MatchReason
from app.services.ollama_service import (
    NO_EVIDENCE_SUMMARY,
    OllamaCallError,
    analyze_evidence,
)


def _git(hash_: str = "abc1234", message: str = "Fix file_close_init timeout") -> GitCandidate:
    return GitCandidate(
        repository_id=1,
        repository_name="repo",
        commit_id=1,
        commit_hash=hash_,
        commit_date="2024-03-15T00:00:00",
        message=message,
        file_path="common/lib/src/file_save_mgt.c",
        score=10,
        match_reasons=["commit_message_keyword"],
        query_relevance_level="높음",
        query_relevance_score=40,
    )


def _item(title: str = "file_close_init 정리", slide_no: int = 7) -> ChangeItemCandidate:
    return ChangeItemCandidate(
        change_item_cache_id=1,
        document_cache_id=1,
        slide_no=slide_no,
        file_path="docs/a.pptx",
        file_name="TEST_변경내역.pptx",
        item_no="1",
        change_title=title,
        csr_no=None,
        business_background="정리 작업",
        current_status=None,
        as_is=None,
        to_be=None,
        source_functions=[{"file_path": "file_save_mgt.c", "functions": ["file_close_init"]}],
        test_cases=[],
        applicable_scopes=[],
        raw_text=title,
        matched_keywords=[],
        candidate_score=50,
    )


def _evidence_result(
    *,
    links: list[EvidenceLink] | None = None,
    git_candidates: list[GitCandidate] | None = None,
    change_item_candidates: list[ChangeItemCandidate] | None = None,
    query: str = "file_close_init 함수 변경 이력을 보자",
) -> EvidenceResult:
    return EvidenceResult(
        equipment_id=1,
        query=query,
        query_keywords=[],
        weak_query_terms=["함수", "변경", "이력", "보자"],
        request_functions=["file_close_init"],
        request_files=[],
        path_scopes=[],
        git_candidates=git_candidates or [],
        change_item_candidates=change_item_candidates or [],
        evidence_links=links or [],
        change_item_link_candidate_count=len(change_item_candidates or []),
        fallback_documents_parsed=0,
        change_item_total=len(change_item_candidates or []),
    )


def _link(
    git: GitCandidate,
    item: ChangeItemCandidate,
    diff_excerpt: str | None = None,
    *,
    match_reasons: list[MatchReason] | None = None,
    query_match_reasons: list | None = None,
) -> EvidenceLink:
    from app.services.query_relevance_service import QueryMatchReason

    reasons = match_reasons or [
        MatchReason(
            type="same_file_path",
            score=35,
            git_value="common/lib/src/file_save_mgt.c",
            change_item_value="file_save_mgt.c",
        ),
        MatchReason(
            type="same_function_exact",
            score=40,
            git_value="file_close_init",
            change_item_value="file_close_init",
        ),
        MatchReason(
            type="commit_message_change_title",
            score=25,
            git_value="file_close_init",
        ),
    ]
    qreasons = query_match_reasons
    if qreasons is None:
        qreasons = [
            QueryMatchReason(
                keyword="file_close_init",
                field="commit_message",
                value=git.message,
                score=35,
                strength="core",
            ),
            QueryMatchReason(
                keyword="file_close_init",
                field="source_function",
                value="file_close_init()",
                score=40,
                strength="core",
            ),
        ]
    return EvidenceLink(
        git_candidate=git,
        change_item=item,
        link_score=sum(r.score for r in reasons),
        match_reasons=reasons,
        diff_excerpt=diff_excerpt,
        query_relevance_score=40,
        query_relevance_level="높음",
        query_match_reasons=qreasons,
        final_rank_score=80,
    )


def test_no_evidence_skips_ollama_call(monkeypatch):
    called = False

    def _fail_if_called(prompt: str) -> str:
        nonlocal called
        called = True
        raise AssertionError("Ollama must not be called with no evidence")

    monkeypatch.setattr(ollama_service, "_call_ollama_raw", _fail_if_called)

    result = analyze_evidence(_evidence_result())
    assert called is False
    assert result.ai_available is True
    assert result.summary == NO_EVIDENCE_SUMMARY
    assert result.evidence_refs == []
    assert result.answer_status == "no_evidence"
    assert result.confidence == "low"


def test_normal_grounded_answer(monkeypatch):
    git = _git()
    item = _item()
    link = _link(git, item)

    def _fake_raw(prompt: str) -> str:
        assert "file_close_init" in prompt
        assert "abc1234" in prompt
        return (
            '{"summary": "file_close_init 정리 작업", '
            '"reason": "정리 작업으로 확인됨", '
            '"confidence": "high", "inference": false, '
            '"evidence": [{"type": "git", "commit": "abc1234"}, '
            '{"type": "document", "file": "TEST_변경내역.pptx", "slide": 7}]}'
        )

    monkeypatch.setattr(ollama_service, "_call_ollama_raw", _fake_raw)

    result = analyze_evidence(_evidence_result(links=[link], git_candidates=[git]))
    assert result.ai_available is True
    assert result.summary == "file_close_init 정리 작업"
    assert result.confidence == "high"  # Evidence rule, not Ollama field
    assert result.inference is False
    assert result.parse_error is False
    assert {r.type for r in result.evidence_refs} == {"git", "document"}
    assert any(r.commit == "abc1234" for r in result.evidence_refs)
    assert any(r.file == "TEST_변경내역.pptx" and r.slide == 7 for r in result.evidence_refs)


def test_git_only_evidence_builds_context_without_document(monkeypatch):
    git = _git()

    captured = {}

    def _fake_raw(prompt: str) -> str:
        captured["prompt"] = prompt
        return '{"summary": "확인 불가", "reason": "확인 불가", "confidence": "low", "inference": false, "evidence": []}'

    monkeypatch.setattr(ollama_service, "_call_ollama_raw", _fake_raw)

    result = analyze_evidence(_evidence_result(git_candidates=[git]))
    assert "관련 변경내역서 근거를 찾지 못했습니다" in captured["prompt"]
    assert result.ai_available is True
    assert all(r.type == "git" for r in result.evidence_refs)
    assert any(r.commit == "abc1234" for r in result.evidence_refs)
    assert result.confidence == "medium"  # git-only + query 높음


def test_low_relevance_git_only_is_treated_as_no_evidence(monkeypatch):
    """Git Candidates exist but none are query-relevant -> must not fabricate context."""
    git = _git()
    git = git.model_copy(update={"query_relevance_level": "낮음", "query_relevance_score": 0})

    called = False

    def _fail_if_called(prompt: str) -> str:
        nonlocal called
        called = True
        return "{}"

    monkeypatch.setattr(ollama_service, "_call_ollama_raw", _fail_if_called)

    result = analyze_evidence(_evidence_result(git_candidates=[git]))
    assert called is False
    assert result.summary == NO_EVIDENCE_SUMMARY


def test_reason_generation_suppressed_without_evidence():
    """No Git, no Change Item at all -> deterministic 확인불가, Ollama untouched."""
    result = analyze_evidence(_evidence_result())
    assert result.reason is None
    assert result.confidence == "low"
    assert result.answer_status == "no_evidence"
    assert "확인 불가" in result.answer or NO_EVIDENCE_SUMMARY in result.answer


def test_non_json_text_mixed_response_still_parses(monkeypatch):
    git = _git()
    item = _item()
    link = _link(git, item)

    def _fake_raw(prompt: str) -> str:
        return (
            "물론입니다! 분석 결과는 다음과 같습니다:\n\n"
            '{"summary": "정리 작업", "reason": "정리 작업 확인", '
            '"confidence": "medium", "inference": true, "evidence": []}\n\n'
            "추가로 궁금한 점이 있으면 말씀해주세요."
        )

    monkeypatch.setattr(ollama_service, "_call_ollama_raw", _fake_raw)

    result = analyze_evidence(_evidence_result(links=[link], git_candidates=[git]))
    assert result.parse_error is False
    assert result.summary == "정리 작업"
    # Ollama said medium; Evidence rule keeps high (Query 높음 + Primary).
    assert result.confidence == "high"
    assert result.inference is True


def test_markdown_plain_text_response_used_as_answer(monkeypatch):
    git = _git(hash_="b46acebabcdef")
    item = _item(title="시간초과 하차 거래 데이터 변경")
    link = _link(git, item)

    prose = (
        "가장 관련 높은 변경은 시간초과 하차 거래 데이터 변경입니다.\n\n"
        "연결 근거:\n"
        "- 소스 파일 file_save_mgt.c가 일치합니다.\n"
        "- 함수 file_close_init이 포함되어 있습니다."
    )
    monkeypatch.setattr(ollama_service, "_call_ollama_raw", lambda prompt: prose)

    result = analyze_evidence(_evidence_result(links=[link], git_candidates=[git]))
    assert result.parse_error is False
    assert result.answer_status == "ok"
    assert result.confidence == "high"
    assert "시간초과 하차 거래 데이터 변경" in result.answer
    assert "file_close_init" in result.answer
    assert any(r.type == "git" for r in result.evidence_refs)
    assert any(r.type == "document" for r in result.evidence_refs)


def test_bad_json_blob_uses_evidence_fallback(monkeypatch):
    git = _git()
    item = _item(title="시간초과 하차 거래 데이터 변경")
    link = _link(git, item)

    monkeypatch.setattr(
        ollama_service,
        "_call_ollama_raw",
        lambda prompt: '{ "summary": "broken", "reason": ',
    )

    result = analyze_evidence(_evidence_result(links=[link], git_candidates=[git]))
    assert result.parse_error is True
    assert result.answer_status in {"ollama_parse_error", "ollama_empty_response"}
    assert result.confidence == "high"
    assert "시간초과 하차 거래 데이터 변경" in (result.summary or "")
    assert any(r.type == "git" for r in result.evidence_refs)


def test_bad_json_with_surrounding_prose_uses_plain_text(monkeypatch):
    git = _git()
    item = _item()
    link = _link(git, item)

    monkeypatch.setattr(
        ollama_service,
        "_call_ollama_raw",
        lambda prompt: (
            "관련 변경은 file_close_init 정리로 보입니다. "
            "형식은 깨졌지만 본문은 충분합니다. {not-json"
        ),
    )

    result = analyze_evidence(_evidence_result(links=[link], git_candidates=[git]))
    assert result.answer_status == "ok"
    assert "file_close_init" in result.answer
    assert result.confidence == "high"


def test_empty_ollama_response_uses_fallback(monkeypatch):
    git = _git()
    item = _item(title="시간초과 하차 거래 데이터 변경")
    link = _link(git, item)
    monkeypatch.setattr(ollama_service, "_call_ollama_raw", lambda prompt: "   ")

    result = analyze_evidence(_evidence_result(links=[link], git_candidates=[git]))
    assert result.parse_error is True
    assert result.answer_status == "ollama_empty_response"
    assert "시간초과 하차 거래 데이터 변경" in (result.summary or "")
    assert result.confidence == "high"


def test_evidence_high_keeps_confidence_on_parse_error(monkeypatch):
    git = _git()
    item = _item()
    link = _link(git, item)
    monkeypatch.setattr(ollama_service, "_call_ollama_raw", lambda prompt: "{}")
    result = analyze_evidence(_evidence_result(links=[link], git_candidates=[git]))
    assert result.parse_error is True
    assert result.confidence == "high"


def test_no_evidence_parse_path_not_needed():
    """Evidence 없음은 Ollama를 호출하지 않으므로 parse_error 없이 확인 불가."""
    result = analyze_evidence(_evidence_result())
    assert result.parse_error is False
    assert result.answer_status == "no_evidence"
    assert result.confidence == "low"


def test_ollama_timeout_degrades_gracefully(monkeypatch):
    git = _git()
    item = _item(title="시간초과 하차 거래 데이터 변경")
    link = _link(git, item)

    def _raise_timeout(prompt: str) -> str:
        raise OllamaCallError(
            "Ollama 응답이 시간 내에 도착하지 않았습니다.", kind="timeout"
        )

    monkeypatch.setattr(ollama_service, "_call_ollama_raw", _raise_timeout)

    result = analyze_evidence(_evidence_result(links=[link], git_candidates=[git]))
    assert result.ai_available is False
    assert result.answer_status == "ollama_timeout"
    assert "Ollama 응답 실패" in (result.error or "")
    assert result.summary is not None
    assert "시간초과 하차 거래 데이터 변경" in result.summary
    assert result.confidence == "high"
    assert any(r.type == "git" for r in result.evidence_refs)
    assert any(r.type == "document" for r in result.evidence_refs)


def test_ollama_connection_refused_degrades_gracefully(monkeypatch):
    git = _git()
    item = _item()
    link = _link(git, item)

    def _raise_conn_error(prompt: str) -> str:
        raise OllamaCallError("Ollama 서버에 연결할 수 없습니다.", kind="unavailable")

    monkeypatch.setattr(ollama_service, "_call_ollama_raw", _raise_conn_error)

    result = analyze_evidence(_evidence_result(links=[link], git_candidates=[git]))
    assert result.ai_available is False
    assert result.answer_status == "ollama_unavailable"
    assert any(r.type == "git" for r in result.evidence_refs)
    assert result.summary  # fallback filled


def test_malformed_json_response_does_not_raise(monkeypatch):
    """Broken JSON-looking object with no salvageable prose -> fallback, API path safe."""
    git = _git()
    item = _item(title="시간초과 하차 거래 데이터 변경")
    link = _link(git, item)

    monkeypatch.setattr(
        ollama_service,
        "_call_ollama_raw",
        lambda prompt: '{ "summary": true, "reason": [1,2 }',
    )

    result = analyze_evidence(_evidence_result(links=[link], git_candidates=[git]))
    assert result.ai_available is True
    assert result.parse_error is True
    assert result.summary is not None
    assert "시간초과 하차 거래 데이터 변경" in (result.summary or "")
    assert result.confidence == "high"
    assert any(r.type == "git" for r in result.evidence_refs)
    assert any(r.type == "document" for r in result.evidence_refs)


def test_korean_answer_format(monkeypatch):
    git = _git()
    item = _item()
    link = _link(git, item)

    def _fake_raw(prompt: str) -> str:
        return (
            '{"summary": "정산 로직 정리", "reason": "file_close_init 정리 작업 반영", '
            '"confidence": "high", "inference": false, "evidence": []}'
        )

    monkeypatch.setattr(ollama_service, "_call_ollama_raw", _fake_raw)

    result = analyze_evidence(_evidence_result(links=[link], git_candidates=[git]))
    assert "정산 로직 정리" in result.answer
    assert "Git 근거" in result.answer
    assert "변경내역서 근거" in result.answer
    assert "abc1234" in result.answer
    assert "TEST_변경내역.pptx" in result.answer


def test_evidence_missing_in_ai_response_still_returns_grounded_evidence(monkeypatch):
    git = _git()
    item = _item()
    link = _link(git, item)

    def _fake_raw(prompt: str) -> str:
        return (
            '{"summary": "정리 작업", "reason": "확인됨", '
            '"confidence": "medium", "inference": false}'
        )

    monkeypatch.setattr(ollama_service, "_call_ollama_raw", _fake_raw)

    result = analyze_evidence(_evidence_result(links=[link], git_candidates=[git]))
    assert result.ai_evidence_missing is True
    assert any(r.type == "git" and r.commit == "abc1234" for r in result.evidence_refs)
    assert any(r.type == "document" for r in result.evidence_refs)


def test_context_never_includes_full_diff_dump(monkeypatch):
    """Ollama Context must only use the bounded diff excerpt, never a raw full diff."""
    git = _git()
    item = _item()
    long_full_diff = "\n".join(f"line {i}" for i in range(500))
    link = _link(git, item, diff_excerpt="- fare = DEFAULT_FARE;\n+ fare = CHILD_FARE;")

    captured = {}

    def _fake_raw(prompt: str) -> str:
        captured["prompt"] = prompt
        return '{"summary": "ok", "reason": "ok", "confidence": "high", "inference": false, "evidence": []}'

    monkeypatch.setattr(ollama_service, "_call_ollama_raw", _fake_raw)
    analyze_evidence(_evidence_result(links=[link], git_candidates=[git]))
    assert long_full_diff not in captured["prompt"]
    assert "CHILD_FARE" in captured["prompt"]


def test_ollama_confidence_field_ignored_uses_evidence_rule(monkeypatch):
    """Ollama JSON confidence is ignored; Evidence rule decides."""
    git = _git()
    item = _item()
    link = _link(git, item)

    def _fake_raw(prompt: str) -> str:
        import json

        return json.dumps(
            {
                "summary": "ok",
                "reason": "ok",
                "confidence": "low",  # model says low — must not win
                "inference": False,
                "evidence": [],
            }
        )

    monkeypatch.setattr(ollama_service, "_call_ollama_raw", _fake_raw)
    result = analyze_evidence(_evidence_result(links=[link], git_candidates=[git]))
    assert result.confidence == "high"


def test_json_code_fence_response_parses(monkeypatch):
    git = _git()
    item = _item()
    link = _link(git, item)

    def _fake_raw(prompt: str) -> str:
        return (
            "```json\n"
            '{"summary": "펜스 제거 성공", "reason": "ok", '
            '"confidence": "high", "inference": false, "evidence": []}\n'
            "```"
        )

    monkeypatch.setattr(ollama_service, "_call_ollama_raw", _fake_raw)
    result = analyze_evidence(_evidence_result(links=[link], git_candidates=[git]))
    assert result.parse_error is False
    assert result.summary == "펜스 제거 성공"


# --- use_ollama (AI 보조 설명 생성 체크박스) ---------------------------------


def test_use_ollama_true_attempts_ollama_call(monkeypatch):
    git = _git()
    item = _item(title="시간초과 하차 거래 데이터 변경")
    link = _link(git, item)

    called = False

    def _fake_raw(prompt: str) -> str:
        nonlocal called
        called = True
        return "AI 보조 설명 본문입니다. file_close_init 관련 변경으로 확인됩니다."

    monkeypatch.setattr(ollama_service, "_call_ollama_raw", _fake_raw)

    result = analyze_evidence(
        _evidence_result(links=[link], git_candidates=[git]), use_ollama=True
    )
    assert called is True
    assert result.ai_used is True
    assert result.ai_answer is not None
    assert "AI 보조 설명 본문" in result.ai_answer


def test_use_ollama_false_skips_ollama_call(monkeypatch):
    git = _git()
    item = _item(title="시간초과 하차 거래 데이터 변경")
    link = _link(git, item)

    def _fail_if_called(prompt: str) -> str:
        raise AssertionError("Ollama must not be called when use_ollama=false")

    monkeypatch.setattr(ollama_service, "_call_ollama_raw", _fail_if_called)

    result = analyze_evidence(
        _evidence_result(links=[link], git_candidates=[git]), use_ollama=False
    )
    assert result.ai_used is False
    assert result.ai_answer is None
    assert result.answer_status == "ollama_skipped_by_user"
    assert result.ai_available is False


def test_use_ollama_false_still_returns_server_evidence_summary(monkeypatch):
    git = _git()
    item = _item(title="시간초과 하차 거래 데이터 변경")
    link = _link(git, item)

    monkeypatch.setattr(
        ollama_service,
        "_call_ollama_raw",
        lambda prompt: (_ for _ in ()).throw(AssertionError("must not call Ollama")),
    )

    result = analyze_evidence(
        _evidence_result(links=[link], git_candidates=[git]), use_ollama=False
    )
    assert "시간초과 하차 거래 데이터 변경" in result.evidence_summary
    assert result.evidence_answer
    assert result.confidence == "high"  # Evidence rule, unaffected by use_ollama
    assert any(r.type == "git" for r in result.evidence_refs)
    assert any(r.type == "document" for r in result.evidence_refs)


def test_use_ollama_false_no_evidence_still_no_evidence_status():
    """no_evidence takes priority regardless of use_ollama value."""
    result = analyze_evidence(_evidence_result(), use_ollama=False)
    assert result.answer_status == "no_evidence"
    assert result.ai_used is False


def test_use_ollama_true_ollama_failure_keeps_server_evidence_summary(monkeypatch):
    git = _git()
    item = _item(title="시간초과 하차 거래 데이터 변경")
    link = _link(git, item)

    def _raise_timeout(prompt: str) -> str:
        raise OllamaCallError(
            "Ollama 응답이 시간 내에 도착하지 않았습니다.", kind="timeout"
        )

    monkeypatch.setattr(ollama_service, "_call_ollama_raw", _raise_timeout)

    result = analyze_evidence(
        _evidence_result(links=[link], git_candidates=[git]), use_ollama=True
    )
    assert result.ai_used is True
    assert result.ai_answer is None
    assert "시간초과 하차 거래 데이터 변경" in result.evidence_summary
    assert result.confidence == "high"
