"""STEP 6 PPT analysis integration tests."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock

import pytest

from app.core.ppt_parse_config import PPT_PARSE_LIMIT
from app.schemas.equipment import EquipmentCreate
from app.schemas.trace import SearchContext
from app.services.equipment_service import create_equipment
from app.services.ppt_analysis_service import analyze_ppt, process_ppt_candidates
from app.services.ppt_candidate_service import PptCandidateResult
from app.services.ppt_parser_service import PptParseError
from app.services.slide_candidate_service import search_slide_candidates
from app.services.ppt_cache_service import CachedDocument


@pytest.fixture(scope="session")
def fixtures_dir(project_root):
    return project_root / "tests" / "test-data" / "ppt-fixtures"


@pytest.fixture(scope="session")
def ppt_fixtures_ready(project_root):
    import sys

    test_data = project_root / "tests" / "test-data"
    sys.path.insert(0, str(test_data))
    from setup_ppt_fixtures import setup_all_fixtures

    setup_all_fixtures(test_data / "ppt-fixtures")


@pytest.fixture
def analysis_docs_dir(isolated_device_a_paths, ppt_fixtures_ready, fixtures_dir):
    doc_dir = Path(isolated_device_a_paths["document_path_local"]) / "ppt-analysis"
    doc_dir.mkdir(parents=True, exist_ok=True)
    for name in (
        "child_fare.pptx",
        "transfer_fare.pptx",
        "table_change.pptx",
        "empty_slide.pptx",
        "corrupt.pptx",
        "change_item.pptx",
    ):
        src = fixtures_dir / name
        if src.exists():
            # Filename must contain equipment.name ("AG") for the hard filter.
            dest_name = name if name.startswith("AG_") else f"AG_{name}"
            (doc_dir / dest_name).write_bytes(src.read_bytes())
    korean_dir = fixtures_dir / "korean-names"
    if korean_dir.exists():
        for f in korean_dir.glob("*.pptx"):
            dest_name = f.name if f.name.startswith("AG_") else f"AG_{f.name}"
            (doc_dir / dest_name).write_bytes(f.read_bytes())
    return doc_dir


@pytest.fixture
def ag_equipment(test_db, isolated_device_a_paths, analysis_docs_dir):
    paths = {**isolated_device_a_paths, "name": "AG"}
    return create_equipment(EquipmentCreate(**paths))


def test_parse_limit_not_all_candidates(ag_equipment, monkeypatch):
    monkeypatch.setattr("app.services.ppt_analysis_service.PPT_PARSE_LIMIT", 2)

    result = analyze_ppt(
        equipment_id=ag_equipment.id,
        keywords=["CHILD_FARE", "CalcTransferFare", "어린이"],
        date_from="2024-01-01",
        date_to="2024-12-31",
    )
    assert result.ppt_candidate_count <= 30
    assert result.processed_documents <= 2


def test_slide_candidate_keyword_match(ag_equipment):
    result = analyze_ppt(
        equipment_id=ag_equipment.id,
        keywords=["CHILD_FARE", "어린이", "CalcTransferFare"],
        date_from="2024-01-01",
        date_to="2024-12-31",
    )
    assert len(result.slide_candidates) >= 1
    top = result.slide_candidates[0]
    assert top.candidate_score > 0
    assert top.matched_keywords
    assert top.slide_number >= 1


def test_slide_candidate_score_zero_excluded():
    doc = MagicMock()
    doc.id = 1
    doc.file_path = "/x/a.pptx"
    doc.file_name = "unrelated.pptx"

    slide = MagicMock()
    slide.id = 10
    slide.slide_number = 1
    slide.title = "무관"
    slide.content = "내용"

    cached = CachedDocument(
        document=doc,
        slides=[slide],
        cache_hit=True,
    )
    results = search_slide_candidates([cached], ["CHILD_FARE"])
    assert results == []


def test_corrupt_ppt_continues_others(ag_equipment):
    result = analyze_ppt(
        equipment_id=ag_equipment.id,
        keywords=["CHILD_FARE", "CalcTransferFare"],
        date_from="2024-01-01",
        date_to="2024-12-31",
    )
    assert result.parse_failures >= 1
    assert result.processed_documents >= 1


def test_ppt_analysis_api(ag_equipment, client):
    response = client.post(
        "/api/trace/ppt-analysis",
        json={
            "equipment_id": ag_equipment.id,
            "keywords": ["CHILD_FARE", "어린이"],
            "date_from": "2024-01-01",
            "date_to": "2024-12-31",
        },
    )
    assert response.status_code == 200
    data = response.json()
    assert "slide_candidates" in data
    assert data["processed_documents"] <= PPT_PARSE_LIMIT


def test_ppt_analysis_api_without_dates(ag_equipment, client):
    response = client.post(
        "/api/trace/ppt-analysis",
        json={
            "equipment_id": ag_equipment.id,
            "keywords": ["CHILD_FARE", "어린이"],
        },
    )
    assert response.status_code == 200
    data = response.json()
    assert data["ppt_candidate_count"] >= 1


def test_slide_cache_keyword_search_finds_cached_content(ag_equipment, client, analysis_docs_dir):
    from app.services.ppt_cache_service import get_or_parse_document

    ppt_path = analysis_docs_dir / "AG_child_fare.pptx"
    if not ppt_path.exists():
        pytest.skip("fixture ppt missing")
    unc_ppt = Path(ag_equipment.document_path) / "ppt-analysis" / "AG_child_fare.pptx"
    get_or_parse_document(ag_equipment.id, str(unc_ppt))

    response = client.post(
        "/api/trace/ppt-analysis",
        json={"equipment_id": ag_equipment.id, "keywords": ["CHILD_FARE"]},
    )
    assert response.status_code == 200
    data = response.json()
    assert data["slide_candidates"]
    assert any(
        "CHILD_FARE" in kw for s in data["slide_candidates"] for kw in s["matched_keywords"]
    )


def test_cache_hit_api(ag_equipment, client):
    payload = {
        "equipment_id": ag_equipment.id,
        "keywords": ["CHILD_FARE"],
        "date_from": "2024-01-01",
        "date_to": "2024-12-31",
    }
    first = client.post("/api/trace/ppt-analysis", json=payload).json()
    second = client.post("/api/trace/ppt-analysis", json=payload).json()
    assert second["cache_hits"] >= 1
    assert second["cache_misses"] == 0 or second["cache_hits"] >= first["processed_documents"]


def test_ppt_cache_list_api(ag_equipment, client):
    client.post(
        "/api/trace/ppt-analysis",
        json={
            "equipment_id": ag_equipment.id,
            "keywords": ["CHILD_FARE"],
            "date_from": "2024-01-01",
            "date_to": "2024-12-31",
        },
    )
    response = client.get(f"/api/equipment/{ag_equipment.id}/ppt-cache")
    assert response.status_code == 200
    assert len(response.json()["documents"]) >= 1


def test_ppt_cache_detail_api(ag_equipment, client):
    analysis = client.post(
        "/api/trace/ppt-analysis",
        json={
            "equipment_id": ag_equipment.id,
            "keywords": ["CHILD_FARE"],
            "date_from": "2024-01-01",
            "date_to": "2024-12-31",
        },
    ).json()
    if not analysis["documents"]:
        pytest.skip("no documents processed")
    doc_id = analysis["documents"][0]["document_cache_id"]
    detail = client.get(f"/api/ppt-cache/{doc_id}")
    assert detail.status_code == 200
    assert detail.json()["slides"]


def test_ppt_cache_delete_api(ag_equipment, client):
    analysis = client.post(
        "/api/trace/ppt-analysis",
        json={
            "equipment_id": ag_equipment.id,
            "keywords": ["CHILD_FARE"],
            "date_from": "2024-01-01",
            "date_to": "2024-12-31",
        },
    ).json()
    if not analysis["documents"]:
        pytest.skip("no documents")
    doc_id = analysis["documents"][0]["document_cache_id"]
    assert client.delete(f"/api/ppt-cache/{doc_id}").status_code == 204
    assert client.get(f"/api/ppt-cache/{doc_id}").status_code == 404


def test_korean_filename_analysis(ag_equipment, client):
    response = client.post(
        "/api/trace/ppt-analysis",
        json={
            "equipment_id": ag_equipment.id,
            "keywords": ["CHILD_FARE", "CalcFare"],
            "date_from": "2024-01-01",
            "date_to": "2024-12-31",
        },
    )
    assert response.status_code == 200


def test_equipment_404(client):
    response = client.post(
        "/api/trace/ppt-analysis",
        json={
            "equipment_id": 99999,
            "keywords": ["x"],
            "date_from": "2024-01-01",
            "date_to": "2024-12-31",
        },
    )
    assert response.status_code == 404


def test_process_ppt_candidates_parse_fn_not_called_on_hit(ag_equipment, analysis_docs_dir):
    ppt_path = analysis_docs_dir / "child_fare.pptx"
    candidates = [
        PptCandidateResult(
            file_path=str(ppt_path.resolve()),
            file_name=ppt_path.name,
            modified_at="2024-01-01T00:00:00+00:00",
            file_size=100,
            candidate_score=90,
            match_reasons=["filename_keyword"],
        )
    ]

    from app.services.ppt_cache_service import get_or_parse_document

    get_or_parse_document(ag_equipment.id, str(ppt_path.resolve()))

    calls = {"n": 0}

    def parse_fn(_path):
        calls["n"] += 1
        raise PptParseError("should not be called")

    docs, hits, misses, failures, _ = process_ppt_candidates(
        ag_equipment.id,
        candidates,
        ["CHILD_FARE"],
        parse_fn=parse_fn,
    )
    assert hits == 1
    assert calls["n"] == 0
    assert failures == 0
