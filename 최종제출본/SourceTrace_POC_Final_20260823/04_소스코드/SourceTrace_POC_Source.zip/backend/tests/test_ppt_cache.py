"""STEP 6 PPT cache DB and policy tests."""

from __future__ import annotations

import hashlib
import sqlite3
from pathlib import Path
from unittest.mock import MagicMock

import pytest

from app.core.ppt_parse_config import FILE_HASH_CHUNK_SIZE
from app.db.database import get_connection
from app.services.equipment_service import create_equipment
from app.services.ppt_cache_service import (
    compute_file_hash,
    delete_document_cache,
    get_document_cache,
    get_or_parse_document,
    get_slides_for_document,
)
from app.services.ppt_parser_service import ParsedPresentation, ParsedSlide, PptParseError, parse_pptx_file
from app.schemas.equipment import EquipmentCreate


@pytest.fixture(scope="session")
def fixtures_dir(project_root):
    return project_root / "tests" / "test-data" / "ppt-fixtures"


@pytest.fixture(scope="session")
def ppt_fixtures_ready(project_root):
    import sys

    test_data = project_root / "tests" / "test-data"
    sys.path.insert(0, str(test_data))
    from setup_ppt_fixtures import setup_all_fixtures

    setup_all_fixtures(test_data / "ppt-fixtures")


@pytest.fixture
def equipment_with_docs(test_db, isolated_device_a_paths, ppt_fixtures_ready, fixtures_dir):
    doc_dir = Path(isolated_device_a_paths["document_path_local"]) / "ppt-analysis"
    doc_dir.mkdir(parents=True, exist_ok=True)
    src = fixtures_dir / "child_fare.pptx"
    dest = doc_dir / "child_fare.pptx"
    dest.write_bytes(src.read_bytes())

    return create_equipment(
        EquipmentCreate(
            name=isolated_device_a_paths["name"],
            document_path=isolated_device_a_paths["document_path"],
        )
    )


def test_document_and_slide_cache_created(equipment_with_docs, fixtures_dir):
    ppt_path = Path(equipment_with_docs.document_path) / "ppt-analysis" / "child_fare.pptx"
    cached, hit, failed = get_or_parse_document(equipment_with_docs.id, str(ppt_path.resolve()))
    assert cached is not None
    assert hit is False
    assert failed is False
    assert cached.document.slide_count >= 1

    slides = get_slides_for_document(cached.document.id)
    assert len(slides) == cached.document.slide_count
    assert slides[0].slide_number == 1


def test_equipment_id_file_path_unique(equipment_with_docs, fixtures_dir):
    ppt_path = Path(equipment_with_docs.document_path) / "ppt-analysis" / "child_fare.pptx"
    get_or_parse_document(equipment_with_docs.id, str(ppt_path.resolve()))

    conn = get_connection()
    try:
        with pytest.raises(sqlite3.IntegrityError):
            conn.execute(
                """
                INSERT INTO document_cache
                (equipment_id, file_path, file_name, file_hash, modified_at, parsed_at, slide_count)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    equipment_with_docs.id,
                    str(ppt_path.resolve()),
                    "dup.pptx",
                    "abc",
                    "2024-01-01T00:00:00+00:00",
                    "2024-01-01T00:00:00+00:00",
                    1,
                ),
            )
            conn.commit()
    finally:
        conn.close()


def test_slide_number_unique(equipment_with_docs, fixtures_dir):
    ppt_path = Path(equipment_with_docs.document_path) / "ppt-analysis" / "child_fare.pptx"
    cached, _, _ = get_or_parse_document(equipment_with_docs.id, str(ppt_path.resolve()))

    conn = get_connection()
    try:
        with pytest.raises(sqlite3.IntegrityError):
            conn.execute(
                """
                INSERT INTO slide_cache (document_cache_id, slide_number, title, content)
                VALUES (?, ?, ?, ?)
                """,
                (cached.document.id, 1, "t", "c"),
            )
            conn.commit()
    finally:
        conn.close()


def test_equipment_delete_cascades_cache(test_db, equipment_with_docs, fixtures_dir):
    ppt_path = Path(equipment_with_docs.document_path) / "ppt-analysis" / "child_fare.pptx"
    cached, _, _ = get_or_parse_document(equipment_with_docs.id, str(ppt_path.resolve()))
    doc_id = cached.document.id

    conn = get_connection()
    try:
        conn.execute("DELETE FROM equipment WHERE id = ?", (equipment_with_docs.id,))
        conn.commit()
        assert conn.execute(
            "SELECT COUNT(*) FROM document_cache WHERE id = ?", (doc_id,)
        ).fetchone()[0] == 0
        assert conn.execute(
            "SELECT COUNT(*) FROM slide_cache WHERE document_cache_id = ?", (doc_id,)
        ).fetchone()[0] == 0
    finally:
        conn.close()


def test_document_cache_delete_cascades_slides(equipment_with_docs, fixtures_dir):
    ppt_path = Path(equipment_with_docs.document_path) / "ppt-analysis" / "child_fare.pptx"
    cached, _, _ = get_or_parse_document(equipment_with_docs.id, str(ppt_path.resolve()))
    doc_id = cached.document.id

    delete_document_cache(doc_id)
    assert get_slides_for_document(doc_id) == []


def test_sha256_chunk_hash(ppt_fixtures_ready, fixtures_dir, tmp_path):
    src = fixtures_dir / "child_fare.pptx"
    data = src.read_bytes()
    dest = tmp_path / "hash_test.pptx"
    dest.write_bytes(data)

    expected = hashlib.sha256(data).hexdigest()
    assert compute_file_hash(dest) == expected
    assert compute_file_hash(dest, chunk_size=FILE_HASH_CHUNK_SIZE) == expected


def test_modified_at_change_same_hash_cache_hit(equipment_with_docs, fixtures_dir, monkeypatch):
    ppt_path = Path(equipment_with_docs.document_path) / "ppt-analysis" / "child_fare.pptx"
    get_or_parse_document(equipment_with_docs.id, str(ppt_path.resolve()))

    import os

    os.utime(ppt_path, None)

    call_count = {"n": 0}

    def counting_parse(path):
        call_count["n"] += 1
        return parse_pptx_file(path)

    cached, hit, failed = get_or_parse_document(
        equipment_with_docs.id,
        str(ppt_path.resolve()),
        parse_fn=counting_parse,
    )
    assert hit is True
    assert failed is False
    assert call_count["n"] == 0


def test_hash_change_reparses_and_replaces_cache(equipment_with_docs, fixtures_dir):
    ppt_path = Path(equipment_with_docs.document_path) / "ppt-analysis" / "child_fare.pptx"
    first, _, _ = get_or_parse_document(equipment_with_docs.id, str(ppt_path.resolve()))
    old_id = first.document.id

    ppt_path.write_bytes(ppt_path.read_bytes() + b" ")

    second, hit, failed = get_or_parse_document(
        equipment_with_docs.id, str(ppt_path.resolve())
    )
    assert hit is False
    assert failed is False
    assert second.document.id == old_id
    assert second.document.file_hash != first.document.file_hash


def test_parse_failure_keeps_existing_cache(equipment_with_docs, fixtures_dir):
    ppt_path = Path(equipment_with_docs.document_path) / "ppt-analysis" / "child_fare.pptx"
    first, _, _ = get_or_parse_document(equipment_with_docs.id, str(ppt_path.resolve()))
    original_hash = first.document.file_hash

    ppt_path.write_bytes(ppt_path.read_bytes() + b"x")

    def fail_parse(_path):
        raise PptParseError("fail")

    cached, hit, failed = get_or_parse_document(
        equipment_with_docs.id,
        str(ppt_path.resolve()),
        parse_fn=fail_parse,
    )
    assert failed is True
    assert hit is True
    assert cached is not None
    assert cached.document.file_hash == original_hash


def test_new_ppt_parse_failure_no_cache(test_db, isolated_device_a_paths, fixtures_dir):
    doc_dir = Path(isolated_device_a_paths["document_path"]) / "ppt-analysis"
    doc_dir.mkdir(parents=True, exist_ok=True)
    corrupt = doc_dir / "corrupt.pptx"
    corrupt.write_bytes(b"bad")

    equipment = create_equipment(EquipmentCreate(**isolated_device_a_paths))

    def fail_parse(_path):
        raise PptParseError("fail")

    cached, hit, failed = get_or_parse_document(
        equipment.id,
        str(corrupt.resolve()),
        parse_fn=fail_parse,
    )
    assert cached is None
    assert failed is True
    assert get_document_cache(equipment.id, str(corrupt.resolve())) is None


def test_cache_delete_then_reparse(equipment_with_docs, fixtures_dir):
    ppt_path = Path(equipment_with_docs.document_path) / "ppt-analysis" / "child_fare.pptx"
    first, _, _ = get_or_parse_document(equipment_with_docs.id, str(ppt_path.resolve()))
    delete_document_cache(first.document.id)

    second, hit, failed = get_or_parse_document(
        equipment_with_docs.id, str(ppt_path.resolve())
    )
    assert second is not None
    assert hit is False
    assert failed is False
