from datetime import date
from pathlib import Path

import pytest

from app.core.ppt_candidate_config import PPT_CANDIDATE_LIMIT
from app.services.ppt_candidate_service import (
    PptCandidateSearchError,
    _iter_pptx_files,
    _scorable_keywords,
    search_ppt_candidates,
    search_ppt_candidates_from_context,
)
from app.services.ppt_date_parser import extract_dates_from_path, parse_date_from_text
from app.schemas.trace import SearchContext


@pytest.fixture
def docs_tree(tmp_path):
    """Minimal document tree for unit tests."""
    root = tmp_path / "documents"
    files = [
        "2024/20240315_AG_변경내역.pptx",
        "2024/20240501_AG_변경내역.pptx",
        "요금/AG_어린이카드_변경.pptx",
        "기타/화면문구변경.pptx",
        "날짜형식/AG_2024-03-15_변경.pptx",
        "날짜형식/AG_2024_03_16_변경.pptx",
        "날짜형식/AG_2024.03.17_변경.pptx",
        "임시/~$20240315_AG_변경내역.pptx",
        "legacy/구버전변경내역.ppt",
        "잘못된날짜/20241345_AG_변경내역.pptx",
        "대문자확장자/AG_어린이요금변경.PPTX",
        "무관/완전무관문서.pptx",
        "공유폴더/GateDevice_다른장비.pptx",
    ]
    for rel in files:
        p = root / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(b"PK")
    return root


def test_parse_date_compact():
    assert parse_date_from_text("20240315_AG_변경내역") == date(2024, 3, 15)


def test_parse_date_dash():
    assert parse_date_from_text("AG_2024-03-15_변경") == date(2024, 3, 15)


def test_parse_date_underscore():
    assert parse_date_from_text("AG_2024_03_16_변경") == date(2024, 3, 16)


def test_parse_date_dot():
    assert parse_date_from_text("AG_2024.03.17_변경") == date(2024, 3, 17)


def test_parse_invalid_date_skip():
    assert parse_date_from_text("20241345_AG") is None


def test_extract_folder_date(tmp_path):
    root = tmp_path / "docs"
    file_path = root / "2024-03-15" / "변경내역.pptx"
    file_path.parent.mkdir(parents=True)
    file_path.write_bytes(b"x")
    _, folder_date = extract_dates_from_path(str(file_path), str(root))
    assert folder_date == date(2024, 3, 15)


def test_iter_pptx_recursive_excludes(docs_tree):
    files = list(_iter_pptx_files(docs_tree))
    names = {f.name for f in files}
    assert "20240315_AG_변경내역.pptx" in names
    assert "어린이요금변경.PPTX" in names or any(n.lower().endswith(".pptx") for n in names)
    assert "구버전변경내역.ppt" not in names
    assert not any(n.startswith("~$") for n in names)
    assert len(files) == 11  # 13 files minus .ppt and ~$


def test_scorable_keywords_filters_short():
    kws = _scorable_keywords(["A", "IO", "어린이", "CalcFare"])
    assert "A" not in kws
    assert "IO" in kws
    assert "어린이" in kws
    assert "CalcFare" in kws


@pytest.fixture
def ag_equipment(client, docs_tree, isolated_device_a_repo, project_root):
    from tests.conftest import register_equipment_with_repo

    from tests.conftest import local_path_to_test_unc

    return register_equipment_with_repo(
        client,
        {
            "name": "AG",
            "git_path": str(isolated_device_a_repo),
            "document_path": local_path_to_test_unc(docs_tree),
        },
        "ag_repo",
    )


def test_ppt_candidate_api_date_match(ag_equipment, client):
    response = client.post(
        "/api/trace/ppt-candidates",
        json={
            "equipment_id": ag_equipment["id"],
            "keywords": ["어린이", "요금", "AG"],
            "date_from": "2024-02-01",
            "date_to": "2024-04-30",
        },
    )
    assert response.status_code == 200
    data = response.json()
    assert data["scanned_files"] == 11
    assert len(data["ppt_candidates"]) >= 1
    top = data["ppt_candidates"][0]
    assert top["candidate_score"] > 0
    assert top["match_reasons"]


def test_ppt_candidate_keyword_folder(ag_equipment, client):
    data = client.post(
        "/api/trace/ppt-candidates",
        json={
            "equipment_id": ag_equipment["id"],
            "keywords": ["어린이"],
            "date_from": "2024-01-01",
            "date_to": "2024-12-31",
        },
    ).json()
    matched = [c for c in data["ppt_candidates"] if "어린이" in c["file_name"]]
    assert len(matched) >= 1
    assert any("filename_keyword" in c["match_reasons"] or "folder_keyword" in c["match_reasons"] for c in matched)


def test_ppt_candidate_case_insensitive(ag_equipment, client):
    data = client.post(
        "/api/trace/ppt-candidates",
        json={
            "equipment_id": ag_equipment["id"],
            "keywords": ["calcfare"],
            "date_from": "2024-01-01",
            "date_to": "2024-12-31",
        },
    ).json()
    # No calcfare in filenames — may be empty; test uppercase extension file exists in scan
    assert data["scanned_files"] >= 1


def test_ppt_candidate_equipment_context(ag_equipment, client):
    data = client.post(
        "/api/trace/ppt-candidates",
        json={
            "equipment_id": ag_equipment["id"],
            "keywords": ["AG"],
            "date_from": "2024-03-01",
            "date_to": "2024-03-31",
        },
    ).json()
    assert len(data["ppt_candidates"]) >= 1
    assert any(
        "equipment_context" in c["match_reasons"] or "filename_date" in c["match_reasons"]
        for c in data["ppt_candidates"]
    )


def test_ppt_candidate_score_zero_excluded(ag_equipment, client):
    data = client.post(
        "/api/trace/ppt-candidates",
        json={
            "equipment_id": ag_equipment["id"],
            "keywords": ["CHILD_FARE"],
            "date_from": "2020-01-01",
            "date_to": "2020-12-31",
        },
    ).json()
    names = [c["file_name"] for c in data["ppt_candidates"]]
    assert "완전무관문서.pptx" not in names
    assert all(c["candidate_score"] > 0 for c in data["ppt_candidates"])


def test_ppt_candidate_empty_ok(ag_equipment, client):
    data = client.post(
        "/api/trace/ppt-candidates",
        json={
            "equipment_id": ag_equipment["id"],
            "keywords": ["NONEXISTENT_KEYWORD_XYZ"],
            "date_from": "2010-01-01",
            "date_to": "2010-12-31",
        },
    ).json()
    assert data["ppt_candidates"] == []


def test_ppt_candidate_without_dates(ag_equipment, client):
    response = client.post(
        "/api/trace/ppt-candidates",
        json={
            "equipment_id": ag_equipment["id"],
            "keywords": ["어린이", "요금"],
        },
    )
    assert response.status_code == 200
    data = response.json()
    assert data["scanned_files"] >= 1
    assert len(data["ppt_candidates"]) >= 1


def test_ppt_candidate_sorted_desc(ag_equipment, client):
    data = client.post(
        "/api/trace/ppt-candidates",
        json={
            "equipment_id": ag_equipment["id"],
            "keywords": ["AG", "어린이"],
            "date_from": "2024-01-01",
            "date_to": "2024-12-31",
        },
    ).json()
    scores = [c["candidate_score"] for c in data["ppt_candidates"]]
    assert scores == sorted(scores, reverse=True)


def test_ppt_candidate_limit(ag_equipment, client, monkeypatch):
    monkeypatch.setattr("app.services.ppt_candidate_service.PPT_CANDIDATE_LIMIT", 2)
    data = client.post(
        "/api/trace/ppt-candidates",
        json={
            "equipment_id": ag_equipment["id"],
            "keywords": ["AG"],
            "date_from": "2024-01-01",
            "date_to": "2024-12-31",
        },
    ).json()
    assert len(data["ppt_candidates"]) <= 2


def test_ppt_candidate_equipment_404(client):
    response = client.post(
        "/api/trace/ppt-candidates",
        json={
            "equipment_id": 99999,
            "keywords": ["test"],
            "date_from": "2024-01-01",
            "date_to": "2024-12-31",
        },
    )
    assert response.status_code == 404


def test_ppt_candidate_missing_document_path(client, isolated_device_a_paths, isolated_device_a_repo):
    from fastapi.testclient import TestClient
    from app.main import app
    from tests.conftest import equipment_payload

    c = TestClient(app)
    eq = c.post("/api/equipment", json=equipment_payload(isolated_device_a_paths)).json()
    from app.db.database import get_connection

    conn = get_connection()
    conn.execute(
        "UPDATE equipment SET document_path = ? WHERE id = ?",
        (r"C:\nonexistent\documents\path", eq["id"]),
    )
    conn.commit()
    conn.close()

    response = c.post(
        "/api/trace/ppt-candidates",
        json={
            "equipment_id": eq["id"],
            "keywords": ["test"],
            "date_from": "2024-01-01",
            "date_to": "2024-12-31",
        },
    )
    assert response.status_code == 400


def test_two_equipment_document_isolation(client, device_a_paths, device_b_paths, ppt_documents_ready):
    from tests.conftest import equipment_payload

    eq_a = client.post("/api/equipment", json=equipment_payload(device_a_paths)).json()
    eq_b = client.post("/api/equipment", json=equipment_payload(device_b_paths)).json()

    data_b = client.post(
        "/api/trace/ppt-candidates",
        json={
            "equipment_id": eq_b["id"],
            "keywords": ["DEVICE_B"],
            "date_from": "2024-01-01",
            "date_to": "2024-12-31",
        },
    ).json()
    assert any("TEST_DEVICE_B" in c["file_name"] for c in data_b["ppt_candidates"])
    names_a = client.post(
        "/api/trace/ppt-candidates",
        json={
            "equipment_id": eq_a["id"],
            "keywords": ["TEST_DEVICE_B"],
            "date_from": "2024-01-01",
            "date_to": "2024-12-31",
        },
    ).json()["ppt_candidates"]
    assert not any("TEST_DEVICE_B" in c["file_name"] for c in names_a)


def test_search_from_context(ag_equipment):
    ctx = SearchContext(
        keywords=["어린이", "요금"],
        date_from="2024-01-01",
        date_to="2024-12-31",
    )
    result = search_ppt_candidates_from_context(ag_equipment["id"], ctx)
    assert result.scanned_files >= 1


def test_individual_stat_failure_continues(ag_equipment, docs_tree, monkeypatch):
    from pathlib import Path

    original_stat = Path.stat
    target = docs_tree / "2024" / "20240315_AG_변경내역.pptx"

    def patched_stat(self, *args, **kwargs):
        if self.name == "20240315_AG_변경내역.pptx":
            raise PermissionError("denied")
        return original_stat(self, *args, **kwargs)

    monkeypatch.setattr(Path, "stat", patched_stat)
    result = search_ppt_candidates(
        ag_equipment["id"],
        keywords=["AG"],
        date_from="2024-03-01",
        date_to="2024-03-31",
    )
    assert result.scanned_files >= 9
    assert not any("20240315" in c.file_name for c in result.ppt_candidates)


def test_trace_then_ppt_candidates(client, registered_device_a, synced_device_a):
    trace = client.post(
        "/api/trace/search",
        json={
            "equipment_id": registered_device_a["id"],
            "query": "어린이 카드 요금 변경",
        },
    ).json()
    ctx = trace["search_context"]
    ppt = client.post(
        "/api/trace/ppt-candidates",
        json={
            "equipment_id": registered_device_a["id"],
            "keywords": ctx["keywords"],
            "date_from": ctx["date_from"],
            "date_to": ctx["date_to"],
        },
    ).json()
    assert ppt["scanned_files"] >= 1
