"""STEP 6 PPT parser unit tests."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock

import pytest
from pptx.enum.shapes import MSO_SHAPE_TYPE

from app.core.ppt_parse_config import FALLBACK_TITLE_MAX_LENGTH
from app.services.ppt_parser_service import (
    extract_shape_texts_for_test,
    parse_pptx_file,
    resolve_slide_title,
)


@pytest.fixture(scope="session")
def fixtures_dir(project_root):
    return project_root / "tests" / "test-data" / "ppt-fixtures"


@pytest.fixture(scope="session")
def ppt_fixtures_ready(project_root):
    import sys

    test_data = project_root / "tests" / "test-data"
    sys.path.insert(0, str(test_data))
    from setup_ppt_fixtures import setup_all_fixtures

    setup_all_fixtures(test_data / "ppt-fixtures")


def test_title_placeholder_and_textbox(ppt_fixtures_ready, fixtures_dir):
    parsed = parse_pptx_file(str(fixtures_dir / "child_fare.pptx"))
    assert parsed.slide_count >= 1
    slide = parsed.slides[0]
    assert slide.slide_number == 1
    assert "어린이 카드 요금 오류 수정" in (slide.title or "")
    assert "FareCalc.c" in slide.content
    assert "CHILD_FARE" in slide.content
    assert "특정 어린이 카드" in slide.content


def test_transfer_fare_text(ppt_fixtures_ready, fixtures_dir):
    parsed = parse_pptx_file(str(fixtures_dir / "transfer_fare.pptx"))
    assert "CalcTransferFare" in parsed.slides[0].content


def test_table_cell_format(ppt_fixtures_ready, fixtures_dir):
    parsed = parse_pptx_file(str(fixtures_dir / "table_change.pptx"))
    content = parsed.slides[0].content
    assert "장비명 | AG" in content
    assert "변경일 | 2024-03-15" in content
    assert "변경내용 | 어린이 카드 요금 오류 수정" in content


def test_empty_slide_preserved(ppt_fixtures_ready, fixtures_dir):
    parsed = parse_pptx_file(str(fixtures_dir / "empty_slide.pptx"))
    assert parsed.slide_count == 3
    assert parsed.slides[0].slide_number == 1
    assert parsed.slides[1].slide_number == 2
    assert parsed.slides[1].content == ""
    assert parsed.slides[2].slide_number == 3


def test_slide_numbers_start_at_one(ppt_fixtures_ready, fixtures_dir):
    parsed = parse_pptx_file(str(fixtures_dir / "empty_slide.pptx"))
    numbers = [s.slide_number for s in parsed.slides]
    assert numbers == [1, 2, 3]


def test_korean_and_space_filename(ppt_fixtures_ready, fixtures_dir):
    path = fixtures_dir / "korean-names" / "AG 변경 내역 2024.pptx"
    parsed = parse_pptx_file(str(path))
    assert "CHILD_FARE" in parsed.slides[0].content

    path2 = fixtures_dir / "korean-names" / "2024년_장비변경내역.pptx"
    parsed2 = parse_pptx_file(str(path2))
    assert "CalcFare" in parsed2.slides[0].content


def test_fallback_title_max_length():
    slide = MagicMock()
    slide.shapes.title = None
    long_line = "A" * 250
    title = resolve_slide_title(slide, long_line)
    assert title is not None
    assert len(title) <= FALLBACK_TITLE_MAX_LENGTH


def test_group_shape_internal_text():
    inner = MagicMock()
    inner.shape_type = MSO_SHAPE_TYPE.TEXT_BOX
    inner.has_table = False
    inner.has_text_frame = True
    para = MagicMock()
    para.text = "GroupInnerText CHILD_FARE"
    inner.text_frame.paragraphs = [para]

    group = MagicMock()
    group.shape_type = MSO_SHAPE_TYPE.GROUP
    group.shapes = [inner]

    texts = extract_shape_texts_for_test(group)
    assert any("GroupInnerText" in t for t in texts)
    assert any("CHILD_FARE" in t for t in texts)


def test_nested_group_shape():
    deep_inner = MagicMock()
    deep_inner.shape_type = MSO_SHAPE_TYPE.TEXT_BOX
    deep_inner.has_table = False
    deep_inner.has_text_frame = True
    para = MagicMock()
    para.text = "NestedDeep"
    deep_inner.text_frame.paragraphs = [para]

    inner_group = MagicMock()
    inner_group.shape_type = MSO_SHAPE_TYPE.GROUP
    inner_group.shapes = [deep_inner]

    outer_group = MagicMock()
    outer_group.shape_type = MSO_SHAPE_TYPE.GROUP
    outer_group.shapes = [inner_group]

    texts = extract_shape_texts_for_test(outer_group)
    assert any("NestedDeep" in t for t in texts)


def test_table_not_duplicated_with_text_frame():
    table_shape = MagicMock()
    table_shape.shape_type = MSO_SHAPE_TYPE.TABLE
    table_shape.has_table = True
    table_shape.has_text_frame = True

    row = MagicMock()
    cell = MagicMock()
    cell.text = "CellOnly"
    row.cells = [cell]
    table_shape.table.rows = [row]

    texts = extract_shape_texts_for_test(table_shape)
    assert texts == ["CellOnly"]
