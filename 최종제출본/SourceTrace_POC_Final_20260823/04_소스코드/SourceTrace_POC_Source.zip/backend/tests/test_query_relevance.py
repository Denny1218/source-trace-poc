"""Evidence query intent / relevance unit tests (synthetic only)."""

from app.schemas.trace import GitCandidate
from app.services.change_item_candidate_service import ChangeItemCandidate
from app.services.query_relevance_service import (
    core_match_keywords,
    evaluate_change_item_query_relevance,
    evaluate_git_query_relevance,
    evaluate_link_query_relevance,
    parse_file_path_input,
    split_evidence_query_intent,
)


def _git(message: str, file_path: str = "src/a.c") -> GitCandidate:
    return GitCandidate(
        repository_id=1,
        repository_name="repo",
        commit_id=1,
        commit_hash="abc",
        commit_date="2020-01-01T00:00:00",
        message=message,
        file_path=file_path,
        score=10,
        match_reasons=["commit_message_keyword"],
    )


def _ci(
    title: str,
    *,
    source_functions: list[dict] | None = None,
    to_be: str | None = None,
    raw_text: str | None = None,
) -> ChangeItemCandidate:
    return ChangeItemCandidate(
        change_item_cache_id=1,
        document_cache_id=1,
        slide_no=1,
        file_path="docs/a.pptx",
        file_name="program_PortableDevice_a.pptx",
        item_no="1",
        change_title=title,
        csr_no=None,
        business_background=None,
        current_status=None,
        as_is=None,
        to_be=to_be,
        source_functions=source_functions or [],
        test_cases=[],
        applicable_scopes=[],
        raw_text=raw_text if raw_text is not None else title,
        matched_keywords=[],
        candidate_score=50,
    )


def test_receipt_change_core_and_weak_english():
    intent = split_evidence_query_intent("receipt change")
    assert "receipt" in [k.lower() for k in intent.query_keywords]
    assert any(t.lower() == "change" for t in intent.weak_query_terms)


def test_korean_receipt_query_intent():
    intent = split_evidence_query_intent("영수증 변경사항")
    assert "영수증" in intent.query_keywords
    assert "변경사항" in intent.weak_query_terms
    assert "변경사항" not in intent.query_keywords


def test_korean_reboard_query_intent():
    intent = split_evidence_query_intent("15분 재승차 관련 변경 이유")
    cores = set(intent.query_keywords)
    weaks = set(intent.weak_query_terms)
    assert "15분" in cores
    assert "재승차" in cores
    assert "관련" in weaks
    assert "변경" in weaks
    assert "이유" in weaks


def test_function_query_intent():
    intent = split_evidence_query_intent("file_close_init 함수 변경 이유")
    assert "file_close_init" in intent.request_functions
    assert "file_close_init" not in intent.weak_query_terms
    assert "함수" in intent.weak_query_terms
    assert "변경" in intent.weak_query_terms
    assert "이유" in intent.weak_query_terms


def test_directory_path_not_requested_file():
    parsed = parse_file_path_input("common/lib/src/")
    assert parsed.is_file is False
    assert parsed.request_files == []
    assert parsed.path_scope == "common/lib/src"

    intent = split_evidence_query_intent(
        "file_close_init 함수 변경 내역을 보여줘",
        file_path="common/lib/src/",
    )
    assert intent.request_files == []
    assert intent.path_scopes == ["common/lib/src"]
    assert "src" not in [t.lower() for t in core_match_keywords(intent)]
    assert "file_close_init" in intent.request_functions


def test_directory_path_without_trailing_slash():
    parsed = parse_file_path_input("common/lib/src")
    assert parsed.is_file is False
    assert parsed.request_files == []
    assert parsed.path_scope == "common/lib/src"


def test_file_path_extracts_requested_file_and_scope():
    parsed = parse_file_path_input("common/lib/src/file_save_mgt.c")
    assert parsed.is_file is True
    assert "file_save_mgt.c" in parsed.request_files
    assert "file_save_mgt" in parsed.request_files
    assert parsed.path_scope == "common/lib/src"

    intent = split_evidence_query_intent(
        "file_close_init 함수 변경 내역을 보여줘",
        file_path="common/lib/src/file_save_mgt.c",
    )
    assert "file_save_mgt.c" in intent.request_files
    assert "file_save_mgt" in intent.request_files
    assert intent.path_scopes == ["common/lib/src"]
    assert "src" not in [t.lower() for t in intent.request_files]


def test_show_me_request_phrases_not_core():
    intent = split_evidence_query_intent(
        "file_close_init 함수 변경 내역을 보여줘",
        file_path="a/file_save_mgt.c",
    )
    assert "file_close_init" in intent.request_functions
    assert "file_save_mgt.c" in intent.request_files
    assert "file_save_mgt" in intent.request_files
    assert "file_close_init" not in intent.weak_query_terms
    for bad in ("내역", "내역을", "보여줘", "보여", "함수", "변경"):
        assert bad not in intent.query_keywords
        assert bad not in intent.request_functions
    assert any(t.startswith("내역") for t in intent.weak_query_terms)
    assert any(t.startswith("보여") for t in intent.weak_query_terms)


def test_boja_request_phrase_not_business_keyword():
    intent = split_evidence_query_intent("file_close_init 함수 변경 내역을 보자")
    assert "file_close_init" in intent.request_functions
    assert intent.query_keywords == []
    for bad in ("보자", "내역", "내역을", "함수", "변경"):
        assert bad not in intent.query_keywords
        assert bad not in intent.request_functions
    assert any(t.startswith("보자") for t in intent.weak_query_terms)


def test_history_phrase_not_business_keyword():
    intent = split_evidence_query_intent("file_close_init 함수의 변경 이력을 보자")
    assert "file_close_init" in intent.request_functions
    assert intent.query_keywords == []
    for bad in ("이력", "이력을", "보자", "변경", "함수", "함수의"):
        assert bad not in intent.query_keywords
        assert bad not in intent.request_functions
    assert any(t.startswith("이력") for t in intent.weak_query_terms)
    assert any(t.startswith("보자") for t in intent.weak_query_terms)


def test_receipt_boja_query_intent():
    intent = split_evidence_query_intent("영수증 변경사항 보자")
    assert "영수증" in intent.query_keywords
    assert "보자" not in intent.query_keywords
    assert "변경사항" in intent.weak_query_terms
    assert any(t.startswith("보자") for t in intent.weak_query_terms)


def test_receipt_change_history_show_me_intent():
    intent = split_evidence_query_intent("영수증 변경내역을 보여줘")
    assert "영수증" in intent.query_keywords
    assert "변경내역" not in intent.query_keywords
    assert "변경내역을" not in intent.query_keywords
    assert "보여줘" not in intent.query_keywords
    assert any(
        t.startswith("변경내역") for t in intent.weak_query_terms
    )
    assert any(t.startswith("보여") for t in intent.weak_query_terms)


def test_reboard_show_me_query_intent():
    intent = split_evidence_query_intent("15분 재승차 내역을 보여줘")
    cores = set(intent.query_keywords)
    weaks = set(intent.weak_query_terms)
    assert "15분" in cores
    assert "재승차" in cores
    assert "내역" not in cores
    assert "보여줘" not in cores
    assert any(t.startswith("내역") for t in intent.weak_query_terms)
    assert any(t.startswith("보여") for t in intent.weak_query_terms)


def test_reboard_change_item_tell_me_intent():
    intent = split_evidence_query_intent("15분 재승차 변경사항 알려줘")
    cores = set(intent.query_keywords)
    assert "15분" in cores
    assert "재승차" in cores
    assert "변경사항" not in cores
    assert "알려줘" not in cores
    assert "변경사항" in intent.weak_query_terms
    assert any(t.startswith("알려") for t in intent.weak_query_terms)


def test_directory_segment_only_match_not_high():
    intent = split_evidence_query_intent(
        "file_close_init 함수 변경 내역을 보여줘",
        file_path="common/lib/src/",
    )
    git = _git(
        "Add prepaid bin mapping under common/lib/src/",
        file_path="common/lib/src/bin_map.c",
    )
    item = _ci(
        "후불기후동행카드 bin 2종 추가",
        source_functions=[
            {"file_path": "common/lib/src/bin_map.c", "functions": ["add_bin"]}
        ],
        raw_text="common/lib/src bin update",
    )
    rel = evaluate_link_query_relevance(
        git, item, intent, request_file_path="common/lib/src/"
    )
    assert rel.level in {"없음", "낮음"}
    assert rel.passes_gate is False
    assert not any(
        r.keyword.lower() == "src" and r.strength == "core" for r in rel.match_reasons
    )


def test_function_direct_match_is_high():
    intent = split_evidence_query_intent(
        "file_close_init 함수 변경 내역을 보여줘",
        file_path="common/lib/src/",
    )
    git = _git("Fix file_close_init timeout", file_path="common/lib/src/file_save_mgt.c")
    item = _ci(
        "file_close_init 정리",
        source_functions=[
            {
                "file_path": "common/lib/src/file_save_mgt.c",
                "functions": ["file_close_init"],
            }
        ],
    )
    rel = evaluate_link_query_relevance(
        git, item, intent, request_file_path="common/lib/src/"
    )
    assert rel.passes_gate is True
    assert rel.level == "높음"
    assert any(
        r.keyword == "file_close_init" and r.strength == "core" for r in rel.match_reasons
    )


def test_keyword_score_cap_limits_repeated_field_hits():
    intent = split_evidence_query_intent("UniqueTopicWord change")
    item = _ci(
        "UniqueTopicWord title",
        to_be="UniqueTopicWord to_be",
        raw_text="UniqueTopicWord raw UniqueTopicWord again",
        source_functions=[
            {
                "file_path": "a/UniqueTopicWord.c",
                "functions": ["UniqueTopicWord"],
                "raw_text": "UniqueTopicWord()",
            }
        ],
    )
    rel = evaluate_change_item_query_relevance(item, intent)
    assert rel.passes_gate is True
    assert rel.score <= 50


def test_receipt_title_passes_gate():
    intent = split_evidence_query_intent("receipt change")
    item = _ci("Receipt print layout update")
    rel = evaluate_change_item_query_relevance(item, intent)
    assert rel.passes_gate is True
    assert rel.has_core_match is True
    assert any(r.keyword.lower() == "receipt" for r in rel.match_reasons)


def test_generic_change_only_fails_gate():
    intent = split_evidence_query_intent("receipt change")
    git = _git("Bus fare map change applied")
    item = _ci("Card map change notes")
    rel = evaluate_link_query_relevance(git, item, intent)
    assert rel.passes_gate is False
    assert rel.level in {"낮음", "없음"}


def test_strong_link_without_core_query_fails_gate():
    intent = split_evidence_query_intent("receipt change")
    git = _git("Update fare table", file_path="src/fare.c")
    item = _ci(
        "Fare table adjustment",
        source_functions=[{"file_path": "src/fare.c", "functions": ["CalcFare"]}],
    )
    rel = evaluate_link_query_relevance(git, item, intent)
    assert rel.passes_gate is False


def test_selected_code_counts_as_query_relevance():
    intent = split_evidence_query_intent(
        "함수 변경 이유",
        selected_code="file_close_init();",
    )
    assert "file_close_init" in intent.request_functions
    assert "file_close_init" in core_match_keywords(intent)
    item = _ci(
        "Init cleanup",
        source_functions=[
            {"file_path": "io.c", "functions": ["file_close_init"]},
        ],
    )
    rel = evaluate_change_item_query_relevance(
        item, intent, selected_code="file_close_init();"
    )
    assert rel.passes_gate is True
    assert any(
        r.field == "selected_code" or r.keyword == "file_close_init"
        for r in rel.match_reasons
    )


def test_request_file_path_counts_as_query_relevance():
    intent = split_evidence_query_intent("변경사항", file_path="src/receipt_print.c")
    assert any("receipt_print" in k.lower() for k in intent.request_files)
    assert not any("receipt_print" in k.lower() for k in intent.query_keywords)
    assert "src" not in [t.lower() for t in intent.request_files]
    git = _git("misc update", file_path="src/receipt_print.c")
    rel = evaluate_git_query_relevance(
        git, intent, request_file_path="src/receipt_print.c"
    )
    assert rel.passes_gate is True
    assert any(r.field == "request_file_path" for r in rel.match_reasons)


def test_query_match_reasons_structure():
    intent = split_evidence_query_intent("영수증 변경사항")
    item = _ci("김포 카드 충전 영수증 양식 변경")
    rel = evaluate_change_item_query_relevance(item, intent)
    assert rel.match_reasons
    reason = next(r for r in rel.match_reasons if r.keyword == "영수증")
    assert reason.field == "change_title"
    assert "영수증" in reason.value
    assert reason.score > 0
