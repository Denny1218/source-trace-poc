"""PROJECT_SPEC v2.6 — shared repository resolver."""

from __future__ import annotations

import pytest

from app.services.repository_resolver import (
    CODE_AMBIGUOUS,
    CODE_INVALID,
    RepositoryResolveError,
    normalize_repo_relative_path,
    resolve_equipment_repository,
)


FILE = "FareCalc.c"


def test_normalize_rejects_traversal():
    with pytest.raises(RepositoryResolveError) as ei:
        normalize_repo_relative_path("../x.c")
    assert ei.value.code == CODE_INVALID


def test_resolve_unique_path(registered_device_a):
    equipment_id = registered_device_a["id"]
    resolved = resolve_equipment_repository(
        equipment_id=equipment_id,
        repo_relative_path=FILE,
    )
    assert resolved.rel_path == FILE
    assert resolved.method == "path_unique"
    assert resolved.repository_id > 0


def test_resolve_with_valid_hint(registered_device_a):
    equipment_id = registered_device_a["id"]
    from app.services.git_repository_service import list_repositories

    repo = [r for r in list_repositories(equipment_id) if r.status == "ready"][0]
    resolved = resolve_equipment_repository(
        equipment_id=equipment_id,
        repo_relative_path=FILE,
        repo_id_hint=repo.id,
    )
    assert resolved.method == "repo_id_hint"
    assert resolved.repository_id == repo.id


def test_resolve_ignores_bad_hint_when_path_unique(registered_device_a):
    equipment_id = registered_device_a["id"]
    resolved = resolve_equipment_repository(
        equipment_id=equipment_id,
        repo_relative_path=FILE,
        repo_id_hint=999999,
    )
    assert resolved.method == "path_unique"
