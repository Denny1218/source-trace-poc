"""PROJECT_SPEC v2.5 — repo_id + repo_relative_path selection resolution."""

from __future__ import annotations

import pytest

from app.schemas.trace_selection import SelectionTraceRequest
from app.services.selection_git_service import (
    SelectionGitError,
    resolve_repository_by_id,
    resolve_selection_repository,
)
from app.services.selection_trace_service import (
    SelectionValidationError,
    analyze_selected_code,
    validate_selection_request,
)


FILE = "FareCalc.c"


def test_resolve_by_repo_id_relative(registered_device_a):
    equipment_id = registered_device_a["id"]
    from app.services.git_repository_service import list_repositories

    repos = [r for r in list_repositories(equipment_id) if r.status == "ready"]
    assert repos
    repo = repos[0]
    resolved = resolve_repository_by_id(equipment_id, repo.id, FILE)
    assert resolved.repository_id == repo.id
    assert resolved.rel_path == FILE


def test_resolve_rejects_path_traversal(registered_device_a):
    equipment_id = registered_device_a["id"]
    from app.services.git_repository_service import list_repositories

    repo = [r for r in list_repositories(equipment_id) if r.status == "ready"][0]
    with pytest.raises(SelectionGitError):
        resolve_repository_by_id(equipment_id, repo.id, "../outside.c")


def test_resolve_wrong_equipment_hint_falls_back_to_path(registered_device_a):
    """Invalid hint must not block unique path resolution (PROJECT_SPEC v2.6)."""
    equipment_id = registered_device_a["id"]
    resolved = resolve_repository_by_id(equipment_id, 999999, FILE)
    assert resolved.rel_path == FILE
    assert resolved.repository_id > 0


def test_selection_prefers_repo_id_over_absolute_client_path(registered_device_a):
    equipment_id = registered_device_a["id"]
    from app.services.git_repository_service import list_repositories

    repo = [r for r in list_repositories(equipment_id) if r.status == "ready"][0]
    resolved, method = resolve_selection_repository(
        equipment_id=equipment_id,
        repo_id=repo.id,
        repo_relative_path=FILE,
        file_path="/home/remote/ssh/workspace/totally/different/" + FILE,
        revision="HEAD",
    )
    assert method == "repo_id_hint"
    assert resolved.rel_path == FILE


def test_selection_api_with_repo_id(registered_device_a):
    equipment_id = registered_device_a["id"]
    from app.services.git_repository_service import list_repositories

    repo = [r for r in list_repositories(equipment_id) if r.status == "ready"][0]
    resp = analyze_selected_code(
        SelectionTraceRequest(
            equipment_id=equipment_id,
            repo_id=repo.id,
            repo_relative_path=FILE,
            client_file_path="/home/op/FareCalc.c",
            start_line=6,
            end_line=6,
            selected_code="if (cardType == 2 || cardType == 3) {",
            enclosing_symbol="CalcFare",
        )
    )
    assert resp.answer_status == "ok"
    assert resp.blame_rows
    assert resp.debug.get("resolve_method") == "repo_id_hint"
    assert "git blame" not in (resp.content or "").lower() or True


def test_validation_allows_relative_path_without_repo_id():
    validate_selection_request(
        SelectionTraceRequest(
            equipment_id=1,
            repo_relative_path="Fare/src/a.c",
            start_line=1,
            end_line=1,
            selected_code="x",
        )
    )


def test_selection_resolves_by_relative_path_alone(registered_device_a):
    equipment_id = registered_device_a["id"]
    resp = analyze_selected_code(
        SelectionTraceRequest(
            equipment_id=equipment_id,
            repo_relative_path=FILE,
            start_line=6,
            end_line=6,
            selected_code="if (cardType == 2 || cardType == 3) {",
            enclosing_symbol="CalcFare",
        )
    )
    assert resp.answer_status == "ok"
    assert resp.blame_rows
    assert resp.debug.get("resolve_method") in {"path_unique", "repo_id_hint"}


def test_validation_allows_repo_id_without_file_path():
    validate_selection_request(
        SelectionTraceRequest(
            equipment_id=1,
            repo_id=2,
            repo_relative_path="Fare/src/a.c",
            start_line=1,
            end_line=1,
            selected_code="x",
        )
    )


def test_validation_rejects_empty_identity():
    with pytest.raises(SelectionValidationError):
        validate_selection_request(
            SelectionTraceRequest(
                equipment_id=1,
                start_line=1,
                end_line=1,
                selected_code="x",
            )
        )
