"""PROJECT_SPEC v2.4 §13 — 선택 코드 변경 근거 조회(Backend) 테스트.

FareCalc.c 5-commit 고정 fixture(``registered_device_a`` / ``isolated_device_a_repo``)
를 그대로 사용한다 (특정 실사용 함수명·Commit·연도를 하드코딩하지 않음).

최종 FareCalc.c (5번째 Commit은 README만 변경):
    1: /* FareCalc.c */
    2: #define DEFAULT_FARE 1000
    3: #define CHILD_FARE 500
    4: (blank)
    5: int CalcFare(int cardType) {
    6:     if (cardType == 2 || cardType == 3) {      <- commit4 단독 수정
    7:         return CHILD_FARE;                      <- commit3 도입, 이후 불변
    8:     }                                            <- commit3 도입, 이후 불변
    9:     return DEFAULT_FARE;                         <- commit2 도입, 이후 불변
    10: }                                              <- commit1 도입, 이후 불변
"""

from __future__ import annotations

import subprocess

import pytest

from app.schemas.trace_selection import SelectionTraceRequest
from app.services.selection_git_service import (
    SelectionGitError,
    classify_blame_commit_change,
    git_blame_lines,
    git_log_line_history,
    group_blame_lines,
    resolve_repository_for_file,
)
from app.services.selection_trace_service import (
    SelectionValidationError,
    analyze_selected_code,
    validate_selection_request,
)

FILE = "FareCalc.c"


def _req(**kwargs):
    base = dict(
        equipment_id=1,
        file_path=FILE,
        start_line=6,
        end_line=6,
        selected_code="if (cardType == 2 || cardType == 3) {",
        enclosing_symbol="CalcFare",
        revision="HEAD",
    )
    base.update(kwargs)
    return SelectionTraceRequest(**base)


# --- validation -------------------------------------------------------------


def test_validation_rejects_start_after_end():
    with pytest.raises(SelectionValidationError):
        validate_selection_request(_req(start_line=10, end_line=5))


def test_validation_rejects_blank_selection():
    with pytest.raises(SelectionValidationError):
        validate_selection_request(_req(selected_code="   "))


def test_validation_rejects_missing_equipment():
    with pytest.raises(SelectionValidationError):
        validate_selection_request(_req(equipment_id=None))


def test_validation_rejects_oversized_range():
    with pytest.raises(SelectionValidationError):
        validate_selection_request(_req(start_line=1, end_line=10000))


# --- repository resolution ---------------------------------------------------


def test_repo_resolution_rejects_path_outside_repo(registered_device_a):
    equipment_id = registered_device_a["id"]
    with pytest.raises(SelectionGitError):
        resolve_repository_for_file(equipment_id, "not/a/real/file.c")


def test_repo_resolution_finds_tracked_file(registered_device_a):
    equipment_id = registered_device_a["id"]
    repo = resolve_repository_for_file(equipment_id, FILE)
    assert repo.rel_path == FILE
    assert repo.repo_path


# --- git blame ---------------------------------------------------------------


def test_single_line_blame_single_commit(registered_device_a):
    equipment_id = registered_device_a["id"]
    repo = resolve_repository_for_file(equipment_id, FILE)
    lines = git_blame_lines(repo.repo_path, repo.rel_path, 6, 6)
    groups = group_blame_lines(lines)
    assert len(groups) == 1
    assert groups[0].start_line == 6 and groups[0].end_line == 6
    assert not groups[0].is_uncommitted


def test_multi_line_same_commit_grouped(registered_device_a):
    equipment_id = registered_device_a["id"]
    repo = resolve_repository_for_file(equipment_id, FILE)
    lines = git_blame_lines(repo.repo_path, repo.rel_path, 7, 8)
    groups = group_blame_lines(lines)
    assert len(groups) == 1
    assert groups[0].start_line == 7 and groups[0].end_line == 8


def test_multi_line_multiple_commits_grouped(registered_device_a):
    equipment_id = registered_device_a["id"]
    repo = resolve_repository_for_file(equipment_id, FILE)
    lines = git_blame_lines(repo.repo_path, repo.rel_path, 5, 9)
    groups = group_blame_lines(lines)
    # Line 5 / 6 / 7-8 / 9 each trace to a different commit.
    assert len(groups) == 4
    hashes = {g.commit_hash for g in groups}
    assert len(hashes) == 4


def test_uncommitted_line_reported(registered_device_a, isolated_device_a_repo):
    equipment_id = registered_device_a["id"]
    repo_path = str(isolated_device_a_repo)
    farecalc = isolated_device_a_repo / "FareCalc.c"
    original = farecalc.read_text(encoding="utf-8")
    farecalc.write_text(original.replace("CHILD_FARE;", "CHILD_FARE; /* local edit */"), encoding="utf-8")
    try:
        repo = resolve_repository_for_file(equipment_id, FILE)
        lines = git_blame_lines(repo.repo_path, repo.rel_path, 7, 7)
        groups = group_blame_lines(lines)
        assert len(groups) == 1
        assert groups[0].is_uncommitted
    finally:
        farecalc.write_text(original, encoding="utf-8")


def test_boundary_commit_flagged(registered_device_a):
    equipment_id = registered_device_a["id"]
    repo = resolve_repository_for_file(equipment_id, FILE)
    lines = git_blame_lines(repo.repo_path, repo.rel_path, 1, 1)
    groups = group_blame_lines(lines)
    assert groups[0].boundary is True


def test_invalid_line_range_raises_selection_git_error(registered_device_a):
    equipment_id = registered_device_a["id"]
    repo = resolve_repository_for_file(equipment_id, FILE)
    with pytest.raises(SelectionGitError):
        git_blame_lines(repo.repo_path, repo.rel_path, 9000, 9001)


# --- git log -L ---------------------------------------------------------------


def test_git_log_line_history_succeeds_multi_commit(registered_device_a):
    equipment_id = registered_device_a["id"]
    repo = resolve_repository_for_file(equipment_id, FILE)
    entries = git_log_line_history(repo.repo_path, repo.rel_path, 9, 9)
    assert entries is not None
    assert len(entries) >= 2  # introduced in commit2, present in commit1 diff context too


def test_git_log_line_history_fails_gracefully_for_missing_file(registered_device_a):
    equipment_id = registered_device_a["id"]
    repo = resolve_repository_for_file(equipment_id, FILE)
    entries = git_log_line_history(repo.repo_path, "no_such_file.c", 1, 1)
    assert entries is None


# --- diff classification ------------------------------------------------------


def test_classify_added_line():
    diff = "+int new_line();\n"
    assert classify_blame_commit_change(diff, ["int new_line();"]) == "added"


def test_classify_modified_line():
    diff = "-old_call();\n+new_call();\n"
    assert classify_blame_commit_change(diff, ["new_call();"]) == "modified"


def test_classify_comment_only():
    diff = "+// comment only\n"
    assert classify_blame_commit_change(diff, ["// comment only"]) == "comment_only"


def test_classify_unknown_when_sample_not_in_diff():
    diff = "+something_else();\n"
    assert classify_blame_commit_change(diff, ["unrelated_line();"]) == "context_only"


def test_extract_overlapping_hunk_before_after():
    from app.services.selection_git_service import extract_overlapping_hunks

    diff = "\n".join(
        [
            "diff --git a/FareCalc.c b/FareCalc.c",
            "--- a/FareCalc.c",
            "+++ b/FareCalc.c",
            "@@ -4,7 +4,7 @@",
            " int CalcFare(int cardType) {",
            "-    if (cardType == 2) {",
            "+    if (cardType == 2 || cardType == 3) {",
            "         return CHILD_FARE;",
            "     }",
            "     return DEFAULT_FARE;",
            " }",
            "",
        ]
    )
    hunks = extract_overlapping_hunks(diff, start_line=5, end_line=5)
    assert len(hunks) == 1
    before = "\n".join(hunks[0].before_lines())
    after = "\n".join(hunks[0].after_lines())
    assert "cardType == 2)" in before or "cardType == 2" in before
    assert "cardType == 3" in after


def test_extract_hunk_skips_non_overlapping():
    from app.services.selection_git_service import extract_overlapping_hunks

    diff = "\n".join(
        [
            "@@ -100,3 +100,3 @@",
            "-old();",
            "+new();",
            " keep();",
            "",
        ]
    )
    assert extract_overlapping_hunks(diff, start_line=5, end_line=6) == []
    assert len(extract_overlapping_hunks(diff, start_line=100, end_line=101)) == 1


# --- end-to-end orchestration --------------------------------------------------


def test_analyze_selected_code_renders_markdown_sections(registered_device_a):
    equipment_id = registered_device_a["id"]
    req = _req(equipment_id=equipment_id, start_line=6, end_line=6)
    result = analyze_selected_code(req)
    assert result.answer_status == "ok"
    assert "# 선택 코드 변경 근거" in result.content
    assert "## 현재 라인의 Git 근거" in result.content
    assert "## 실제 변경 내용" in result.content
    assert "## line history" in result.content
    assert "## 관련 문서" in result.content
    assert "## 함수 전체 이력" in result.content
    assert len(result.blame_rows) == 1
    assert result.blame_rows[0].change_kind in {
        "added",
        "modified",
        "moved",
        "deleted",
        "context_only",
        "comment_only",
    }
    assert len(result.blame_rows[0].short_hash) == 8
    # Prefer real hunk / before-after over placeholder-only text
    row = result.blame_rows[0]
    assert row.diff_hunk or row.before_code or row.after_code or "변경 Commit" in result.content
    assert "Diff에서 확인된 변경입니다." not in result.content or row.diff_hunk


def test_analyze_selected_code_no_direct_document_message(registered_device_a):
    """PROJECT_SPEC v2.4 §7 — keyword/PPT candidate search must never surface an
    unrelated document as the representative evidence for a line selection when
    no equipment PPT documents exist at all."""
    equipment_id = registered_device_a["id"]
    req = _req(equipment_id=equipment_id, start_line=6, end_line=6)
    result = analyze_selected_code(req)
    assert result.document_links == []
    assert "관련 문서를 찾지 못했습니다." in result.content


def test_analyze_selected_code_multi_commit_range(registered_device_a):
    equipment_id = registered_device_a["id"]
    # Must match revision lines 5-9 (no placeholder ellipsis) so source-match passes.
    selected = "\n".join(
        [
            "int CalcFare(int cardType) {",
            "    if (cardType == 2 || cardType == 3) {",
            "        return CHILD_FARE;",
            "    }",
            "    return DEFAULT_FARE;",
        ]
    )
    req = _req(
        equipment_id=equipment_id,
        start_line=5,
        end_line=9,
        selected_code=selected,
    )
    result = analyze_selected_code(req)
    assert result.debug.get("source_match") is True
    assert len(result.blame_rows) == 4


def test_selection_source_match_committed_code(registered_device_a):
    """A — committed selection matching revision → normal blame evidence."""
    equipment_id = registered_device_a["id"]
    req = _req(equipment_id=equipment_id, start_line=6, end_line=6)
    result = analyze_selected_code(req)
    assert result.answer_status == "ok"
    assert result.debug.get("source_match") is True
    assert len(result.blame_rows) == 1
    assert "선택한 코드와 서버 Git 소스가 일치하지 않습니다" not in result.content
    assert "## 현재 라인의 Git 근거" in result.content
    assert result.blame_rows[0].short_hash


def test_selection_source_mismatch_local_only_code(registered_device_a):
    """B — local-only selected_code ≠ revision → no blame / past commits."""
    equipment_id = registered_device_a["id"]
    req = _req(
        equipment_id=equipment_id,
        start_line=6,
        end_line=6,
        selected_code="if (cardType == 2 || cardType == 99) { /* local only */",
    )
    result = analyze_selected_code(req)
    assert result.answer_status == "ok"
    assert result.debug.get("source_match") is False
    assert result.debug.get("blame_skipped") is True
    assert result.blame_rows == []
    assert result.line_history == []
    assert "선택한 코드와 서버 Git 소스가 일치하지 않습니다" in result.content
    assert "로컬 변경사항이 아직 Commit/반영되지 않았거나" in result.content
    # Must not surface a representative past commit hash table row.
    assert "| 행 범위 | Commit |" not in result.content


def test_selection_source_match_partial_line(registered_device_a):
    """C — substring of the revision line still matches."""
    equipment_id = registered_device_a["id"]
    req = _req(
        equipment_id=equipment_id,
        start_line=6,
        end_line=6,
        selected_code="cardType == 2",
    )
    result = analyze_selected_code(req)
    assert result.debug.get("source_match") is True
    assert len(result.blame_rows) == 1
    assert "선택한 코드와 서버 Git 소스가 일치하지 않습니다" not in result.content


def test_normalize_and_partial_containment_helpers():
    from app.services.selection_git_service import (
        normalize_selection_compare_text,
        selected_code_matches_server_block,
    )

    crlf_block = "    if (cardType == 2 || cardType == 3) {\r\n"
    assert normalize_selection_compare_text(crlf_block) == (
        "    if (cardType == 2 || cardType == 3) {"
    )
    assert selected_code_matches_server_block(
        "cardType == 3", "    if (cardType == 2 || cardType == 3) {"
    )
    assert not selected_code_matches_server_block(
        "cardType == 99", "    if (cardType == 2 || cardType == 3) {"
    )


def test_blame_commit_never_replaced_by_keyword_search(registered_device_a, monkeypatch):
    """PROJECT_SPEC v2.4 §6.4 — even if keyword/Evidence search is invoked for
    document discovery, it must never override which commit is shown as the
    representative Git evidence for the selected line."""
    equipment_id = registered_device_a["id"]

    def _boom(*a, **k):
        raise AssertionError("keyword evidence search must not run without enclosing_symbol")

    monkeypatch.setattr("app.services.evidence_service.build_evidence", _boom)
    req = _req(equipment_id=equipment_id, start_line=6, end_line=6, enclosing_symbol=None)
    result = analyze_selected_code(req)
    assert len(result.blame_rows) == 1
    assert result.document_links == []


def test_selection_api_end_to_end(client, registered_device_a):
    equipment_id = registered_device_a["id"]
    response = client.post(
        "/api/trace/selection",
        json={
            "equipment_id": equipment_id,
            "file_path": FILE,
            "start_line": 6,
            "end_line": 6,
            "selected_code": "if (cardType == 2 || cardType == 3) {",
            "enclosing_symbol": "CalcFare",
            "revision": "HEAD",
        },
    )
    assert response.status_code == 200
    data = response.json()
    assert data["answer_status"] == "ok"
    assert "# 선택 코드 변경 근거" in data["content"]
    assert len(data["blame_rows"]) == 1


def test_selection_api_validation_error_response(client, registered_device_a):
    equipment_id = registered_device_a["id"]
    response = client.post(
        "/api/trace/selection",
        json={
            "equipment_id": equipment_id,
            "file_path": FILE,
            "start_line": 10,
            "end_line": 2,
            "selected_code": "x",
        },
    )
    assert response.status_code == 200
    data = response.json()
    assert data["answer_status"] == "validation_error"


def test_selection_api_path_outside_repo(client, registered_device_a):
    equipment_id = registered_device_a["id"]
    response = client.post(
        "/api/trace/selection",
        json={
            "equipment_id": equipment_id,
            "file_path": "definitely/not/tracked.c",
            "start_line": 1,
            "end_line": 1,
            "selected_code": "x",
        },
    )
    assert response.status_code == 200
    data = response.json()
    assert data["answer_status"] == "git_error"
