"""STEP 7: Source path normalization + match-level tests (synthetic paths only)."""

from app.services.source_path_utils import (
    PathMatchLevel,
    normalize_source_path,
    source_path_match_level,
)


def test_normalize_backslash_to_forward_slash():
    assert normalize_source_path("src\\fare\\fare_calc.c") == "src/fare/fare_calc.c"


def test_normalize_collapses_duplicate_slashes():
    assert normalize_source_path("src//fare///fare_calc.c") == "src/fare/fare_calc.c"


def test_normalize_strips_leading_dot_slash():
    assert normalize_source_path("./src/fare_calc.c") == "src/fare_calc.c"


def test_normalize_lowercases():
    assert normalize_source_path("SRC/Fare_Calc.C") == "src/fare_calc.c"


def test_normalize_empty_and_none():
    assert normalize_source_path("") == ""
    assert normalize_source_path(None) == ""


def test_match_level_exact():
    level = source_path_match_level("src/fare/fare_calc.c", "src/fare/fare_calc.c")
    assert level == PathMatchLevel.EXACT


def test_match_level_exact_case_insensitive():
    level = source_path_match_level("SRC/Fare/FareCalc.c", "src/fare/farecalc.c")
    assert level == PathMatchLevel.EXACT


def test_match_level_separator_difference_is_exact():
    level = source_path_match_level("src\\fare\\fare_calc.c", "src/fare/fare_calc.c")
    assert level == PathMatchLevel.EXACT


def test_match_level_suffix():
    level = source_path_match_level(
        "fare/src/fare_calc.c", "subwaylib/fare/src/fare_calc.c"
    )
    assert level == PathMatchLevel.SUFFIX


def test_match_level_suffix_reversed_args():
    level = source_path_match_level(
        "subwaylib/fare/src/fare_calc.c", "fare/src/fare_calc.c"
    )
    assert level == PathMatchLevel.SUFFIX


def test_match_level_basename_only():
    level = source_path_match_level(
        "src/fare_calc.c", "subwaylib/other/fare_calc.c"
    )
    assert level == PathMatchLevel.BASENAME


def test_match_level_basename_with_unrelated_extension_no_match():
    level = source_path_match_level(
        "fare/fare_calc.c", "other/fare_calc.txt"
    )
    assert level == PathMatchLevel.NONE


def test_match_level_partial_substring_not_match():
    level = source_path_match_level(
        "fare/fare_calc.c", "fare/fare_calc_extended.c"
    )
    assert level == PathMatchLevel.NONE


def test_match_level_empty_path_none():
    assert source_path_match_level("", "src/fare_calc.c") == PathMatchLevel.NONE
    assert source_path_match_level("src/fare_calc.c", None) == PathMatchLevel.NONE
