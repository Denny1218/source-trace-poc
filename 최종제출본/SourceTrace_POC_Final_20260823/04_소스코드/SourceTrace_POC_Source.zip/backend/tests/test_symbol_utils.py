"""Symbol normalization + word-boundary matching tests (synthetic symbols only)."""

from app.services.symbol_utils import (
    is_valid_symbol,
    iter_symbol_candidates,
    normalize_symbol,
    symbol_appears_in_text,
    symbols_equivalent,
)

FN = "card_mif_post_check_valid_birthday_usertype"


def test_normalize_exact_symbol_unchanged():
    assert normalize_symbol("calculate_fare") == "calculate_fare"


def test_normalize_strips_trailing_parens():
    assert normalize_symbol("calculate_fare()") == "calculate_fare"


def test_normalize_strips_whitespace():
    assert normalize_symbol("  calculate_fare  ") == "calculate_fare"


def test_normalize_strips_whitespace_and_parens_combined():
    assert normalize_symbol("  calculate_fare ()  ") == "calculate_fare"


def test_normalize_single_space_inside_identifier():
    assert normalize_symbol("foo_ bar()") == "foo_bar"
    assert (
        normalize_symbol("card_mif_post_check_valid_birthday_ usertype()")
        == FN
    )


def test_normalize_multiple_spaces_inside_identifier():
    assert normalize_symbol("foo_   bar()") == "foo_bar"
    assert (
        normalize_symbol("card_mif_post_check_valid_birthday_   usertype()")
        == FN
    )


def test_normalize_newline_inside_identifier():
    assert normalize_symbol("foo_\nbar()") == "foo_bar"
    assert (
        normalize_symbol("card_mif_post_check_valid_birthday_\nusertype()")
        == FN
    )


def test_normalize_tab_inside_identifier():
    assert normalize_symbol("foo_\tbar()") == "foo_bar"
    assert (
        normalize_symbol("card_mif_post_check_valid_birthday_\tusertype()")
        == FN
    )


def test_symbols_equivalent_with_spaced_ppt_name():
    assert symbols_equivalent(
        "card_mif_post_check_valid_birthday_ usertype()",
        FN,
    )
    assert symbols_equivalent(
        "card_mif_post_check_valid_birthday_\nusertype()",
        FN,
    )
    assert symbols_equivalent(FN.upper(), FN)


def test_normalize_empty_and_none():
    assert normalize_symbol("") == ""
    assert normalize_symbol(None) == ""


def test_is_valid_symbol_true_for_identifier():
    assert is_valid_symbol("calculate_fare") is True


def test_is_valid_symbol_false_for_free_text():
    assert is_valid_symbol("이 함수가 왜 변경됐어") is False
    assert is_valid_symbol("calculate fare please") is False
    assert is_valid_symbol("") is False


def test_symbol_appears_exact_match():
    assert symbol_appears_in_text("calculate_fare", "int calculate_fare(int x) {") is True


def test_symbol_appears_spaced_form_in_haystack():
    assert (
        symbol_appears_in_text(
            FN,
            "see card_mif_post_check_valid_birthday_ usertype() in slide",
        )
        is True
    )
    assert (
        symbol_appears_in_text(
            FN,
            "see card_mif_post_check_valid_birthday_\nusertype() in slide",
        )
        is True
    )


def test_symbol_appears_case_insensitive_search():
    assert symbol_appears_in_text(FN, FN.upper() + "()") is True


def test_symbol_appears_spaced_ppt_name_in_clean_diff():
    assert (
        symbol_appears_in_text(
            "card_mif_post_check_valid_birthday_ usertype()",
            f"static int {FN}(void)",
        )
        is True
    )


def test_symbol_appears_not_matching_different_symbol():
    assert symbol_appears_in_text("calculate_fare", "int calculate_child_fare(int x) {") is False


def test_symbol_appears_substring_only_not_match():
    """`calculate_fare` must NOT match inside `calculate_fare_extended` (word boundary)."""
    assert symbol_appears_in_text("calculate_fare", "calculate_fare_extended()") is False


def test_symbol_appears_invalid_free_text_never_matches():
    assert symbol_appears_in_text("이 함수가 왜", "이 함수가 왜 변경됐는지") is False


def test_symbol_appears_empty_inputs():
    assert symbol_appears_in_text("", "some text") is False
    assert symbol_appears_in_text("calculate_fare", "") is False
    assert symbol_appears_in_text("calculate_fare", None) is False


def test_iter_symbol_candidates_recovers_spaced_call():
    cands = iter_symbol_candidates(
        "Card/mif_post/src/x.c - card_mif_post_check_valid_birthday_ usertype()",
        call_forms_only=True,
    )
    norms = [normalize_symbol(c) for c in cands]
    assert FN in norms


def test_iter_symbol_candidates_path_only_yields_no_stem():
    from app.services.symbol_utils import iter_call_symbol_candidates

    assert iter_call_symbol_candidates("Card/mif_post/src/card_mif_postpay.c") == []
    # Path-bearing text without call form must not invent stems.
    cands = iter_symbol_candidates("Card/mif_post/src/card_mif_postpay.c")
    norms = {normalize_symbol(c).lower() for c in cands}
    assert "card_mif_postpay" not in norms


def test_korean_sentence_spaces_not_stripped_by_normalize_on_hangul():
    # normalize_symbol only collapses WS between [A-Za-z0-9_]; Hangul stays.
    text = "청소년 후불카드 적용"
    assert normalize_symbol(text) == text
