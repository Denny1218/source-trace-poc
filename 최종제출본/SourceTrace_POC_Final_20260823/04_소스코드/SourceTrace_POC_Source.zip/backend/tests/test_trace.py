import pytest

from app.services.keyword_extractor import extract_keywords


@pytest.fixture
def synced_device_a(client, registered_device_a):
    equipment_id = registered_device_a["id"]
    response = client.post(f"/api/equipment/{equipment_id}/sync/git")
    assert response.status_code == 200
    return registered_device_a


def test_extract_keywords_from_query():
    keywords = extract_keywords("CalcFare 함수가 왜 변경됐어?", file_path="FareCalc.c")
    assert "CalcFare" in keywords
    assert "FareCalc.c" in keywords


def test_extract_keywords_korean():
    keywords = extract_keywords("어린이 카드 요금 변경")
    assert any("어린이" in k or "요금" in k for k in keywords)


def test_extract_keywords_from_selected_code():
    keywords = extract_keywords(
        "변경 이유",
        selected_code="if (cardType == TYPE_CHILD) { return CHILD_FARE; }",
    )
    assert "TYPE_CHILD" in keywords or "CHILD_FARE" in keywords


def test_trace_search_basic(synced_device_a, client):
    eid = synced_device_a["id"]
    response = client.post(
        "/api/trace/search",
        json={"equipment_id": eid, "query": "CHILD_FARE가 왜 추가됐어?"},
    )
    assert response.status_code == 200
    data = response.json()
    assert data["equipment_id"] == eid
    assert len(data["git_candidates"]) >= 1
    assert "search_context" in data
    assert "CHILD_FARE" in data["search_context"]["keywords"] or any(
        "CHILD" in k for k in data["search_context"]["keywords"]
    )


def test_trace_search_child_fare_in_top5(synced_device_a, client):
    eid = synced_device_a["id"]
    data = client.post(
        "/api/trace/search",
        json={"equipment_id": eid, "query": "CHILD_FARE가 왜 추가됐어?"},
    ).json()
    messages = " ".join(c["message"] + (c.get("file_path") or "") for c in data["git_candidates"])
    diffs_found = any(
        "CHILD_FARE" in c.get("file_path", "") or "CHILD_FARE" in c.get("message", "")
        for c in data["git_candidates"]
    )
    assert len(data["git_candidates"]) <= 5
    assert diffs_found or "CHILD_FARE" in str(data["search_context"]["keywords"])


def test_trace_search_calcfare(synced_device_a, client):
    eid = synced_device_a["id"]
    data = client.post(
        "/api/trace/search",
        json={"equipment_id": eid, "query": "CalcFare 함수 변경 이유"},
    ).json()
    assert len(data["git_candidates"]) >= 1
    top = data["git_candidates"][0]
    assert top["score"] > 0
    assert "match_reasons" in top


def test_trace_search_korean_query(synced_device_a, client):
    eid = synced_device_a["id"]
    data = client.post(
        "/api/trace/search",
        json={"equipment_id": eid, "query": "어린이 카드 요금 변경"},
    ).json()
    assert len(data["git_candidates"]) >= 1
    combined = " ".join(c["message"] for c in data["git_candidates"])
    assert "어린이" in combined or any("어린이" in k for k in data["search_context"]["keywords"])


def test_trace_search_with_file_path(synced_device_a, client):
    eid = synced_device_a["id"]
    data = client.post(
        "/api/trace/search",
        json={
            "equipment_id": eid,
            "query": "CalcFare 함수 변경",
            "file_path": "FareCalc.c",
        },
    ).json()
    assert any(c["file_path"] == "FareCalc.c" for c in data["git_candidates"])
    top_farecalc = next(c for c in data["git_candidates"] if c["file_path"] == "FareCalc.c")
    assert "file_path" in top_farecalc["match_reasons"]


def test_trace_search_with_selected_code(synced_device_a, client):
    eid = synced_device_a["id"]
    data = client.post(
        "/api/trace/search",
        json={
            "equipment_id": eid,
            "query": "변경 이유",
            "selected_code": "if (cardType == 2) { return CHILD_FARE; }",
        },
    ).json()
    assert "CHILD_FARE" in data["search_context"]["keywords"] or len(data["git_candidates"]) >= 1


def test_trace_search_context_symbols(synced_device_a, client):
    eid = synced_device_a["id"]
    data = client.post(
        "/api/trace/search",
        json={"equipment_id": eid, "query": "CHILD_FARE가 왜 추가됐어?"},
    ).json()
    ctx = data["search_context"]
    assert ctx["date_from"]
    assert ctx["date_to"]
    assert ctx["date_from"] <= ctx["date_to"]
    assert len(ctx["keywords"]) >= 1


def test_trace_search_match_reasons(synced_device_a, client):
    eid = synced_device_a["id"]
    data = client.post(
        "/api/trace/search",
        json={"equipment_id": eid, "query": "CHILD_FARE"},
    ).json()
    assert all(len(c["match_reasons"]) >= 1 for c in data["git_candidates"])


def test_trace_equipment_not_found(client):
    response = client.post(
        "/api/trace/search",
        json={"equipment_id": 99999, "query": "test"},
    )
    assert response.status_code == 404


def test_trace_no_git_data(client, registered_device_a):
    eid = registered_device_a["id"]
    response = client.post(
        "/api/trace/search",
        json={"equipment_id": eid, "query": "CHILD_FARE"},
    )
    assert response.status_code == 200
    assert response.json()["git_candidates"] == []
