"""Yona Git URL parsing and access policy tests."""

from unittest.mock import patch

import pytest

from app.services.git_url_utils import (
    YONA_DEFAULT_USERNAME_MISSING_MESSAGE,
    build_git_access_url,
    git_subprocess_env,
    parse_repository_url,
    require_yona_default_username,
    run_git_command,
)


YONA_URL_A = "http://user_a@git.example.local:9000/project-a/repository-a"
YONA_URL_B = "http://user_b@git.example.local:9000/project-a/repository-a"
CANONICAL = "http://git.example.local:9000/project-a/repository-a"


def test_parse_yona_url_username_and_canonical():
    parsed = parse_repository_url(YONA_URL_A)
    assert parsed.canonical_url == CANONICAL
    assert parsed.yona_username == "user_a"
    assert parsed.display_url == YONA_URL_A
    assert parsed.had_password is False


def test_same_canonical_different_username():
    a = parse_repository_url(YONA_URL_A)
    b = parse_repository_url(YONA_URL_B)
    assert a.canonical_url == b.canonical_url
    assert a.yona_username != b.yona_username


def test_password_stripped_from_display():
    parsed = parse_repository_url(
        "http://user:secret@git.example.local:9000/project-a/repository-a"
    )
    assert parsed.had_password is True
    assert "secret" not in parsed.display_url
    assert parsed.yona_username == "user"


def test_build_git_access_url_ignores_url_username(monkeypatch):
    monkeypatch.setattr("app.core.config.YONA_DEFAULT_USERNAME", "source_trace")
    access = build_git_access_url(CANONICAL, yona_username="user_a")
    assert access == "http://source_trace@git.example.local:9000/project-a/repository-a"


def test_build_git_access_url_default_username(monkeypatch):
    monkeypatch.setattr("app.core.config.YONA_DEFAULT_USERNAME", "source_trace")
    access = build_git_access_url(CANONICAL, yona_username=None)
    assert access == "http://source_trace@git.example.local:9000/project-a/repository-a"


def test_build_git_access_url_requires_default_username(monkeypatch):
    monkeypatch.setattr("app.core.config.YONA_DEFAULT_USERNAME", "")
    with pytest.raises(ValueError, match=YONA_DEFAULT_USERNAME_MISSING_MESSAGE):
        build_git_access_url(CANONICAL)


def test_require_yona_default_username(monkeypatch):
    monkeypatch.setattr("app.core.config.YONA_DEFAULT_USERNAME", "source_trace")
    assert require_yona_default_username() == "source_trace"


def test_parse_url_without_username_uses_default(monkeypatch):
    url = "http://git.example.local:9000/project-a/repository-a"
    parsed = parse_repository_url(url)
    assert parsed.yona_username is None
    monkeypatch.setattr("app.core.config.YONA_DEFAULT_USERNAME", "source_trace")
    access = build_git_access_url(parsed.canonical_url, yona_username=parsed.yona_username)
    assert access == "http://source_trace@git.example.local:9000/project-a/repository-a"


def test_git_subprocess_env_terminal_prompt_disabled():
    env = git_subprocess_env()
    assert env["GIT_TERMINAL_PROMPT"] == "0"


def test_run_git_command_sets_terminal_prompt(monkeypatch):
    captured: dict = {}

    def fake_run(*args, **kwargs):
        captured["env"] = kwargs.get("env", {})
        return type("R", (), {"returncode": 0, "stdout": "", "stderr": ""})()

    monkeypatch.setattr("app.services.git_url_utils.subprocess.run", fake_run)
    run_git_command(["git", "--version"])
    assert captured["env"].get("GIT_TERMINAL_PROMPT") == "0"


def test_validate_remote_without_default_username(client, device_a_paths, monkeypatch):
    monkeypatch.setattr("app.core.config.YONA_DEFAULT_USERNAME", "")
    response = client.post(
        "/api/repositories/validate/remote",
        json={"repository_url": YONA_URL_A},
    )
    assert response.status_code == 200
    body = response.json()
    assert body["valid"] is False
    assert "Yona 기본 계정" in body["message"]


def test_duplicate_canonical_same_equipment(client, device_a_paths):
    equipment = client.post("/api/equipment", json={
        "name": "YONA_DUP",
        "document_path": device_a_paths["document_path"],
    }).json()

    with patch(
        "app.services.git_repository_service.validate_remote_repository_url",
        return_value=(True, "ok", parse_repository_url(YONA_URL_A)),
    ), patch("app.services.git_repository_service._clone_remote"):
        r1 = client.post(
            f"/api/equipment/{equipment['id']}/repositories",
            json={"name": "card", "source_type": "remote", "repository_url": YONA_URL_A},
        )
        assert r1.status_code == 201

        r2 = client.post(
            f"/api/equipment/{equipment['id']}/repositories",
            json={"name": "card2", "source_type": "remote", "repository_url": YONA_URL_B},
        )
        assert r2.status_code == 409
        assert "URL" in r2.json()["detail"]


def test_username_only_update_preserves_commits(
    client, registered_device_a, synced_device_a, monkeypatch
):
    monkeypatch.setattr("app.core.config.YONA_DEFAULT_USERNAME", "source_trace")
    equipment_id = registered_device_a["id"]
    conn_commits_before = client.get(
        f"/api/equipment/{equipment_id}/git/commits"
    ).json()["total"]

    repos = client.get(f"/api/equipment/{equipment_id}/repositories").json()
    repo_id = repos[0]["id"]

    conn = __import__("app.db.database", fromlist=["get_connection"]).get_connection()
    try:
        conn.execute(
            """
            UPDATE git_repository
            SET source_type = 'remote',
                repository_url = ?,
                canonical_repository_url = ?,
                yona_username = NULL,
                local_path = ?,
                status = 'ready'
            WHERE id = ?
            """,
            (CANONICAL, CANONICAL, repos[0]["local_path"], repo_id),
        )
        conn.commit()
    finally:
        conn.close()

    with patch(
        "app.services.git_repository_service.validate_remote_repository_url",
    ) as mock_validate, patch(
        "app.services.git_repository_service._set_remote_origin"
    ) as mock_origin, patch(
        "app.services.git_repository_service._clone_remote"
    ) as mock_clone:
        response = client.put(
            f"/api/repositories/{repo_id}",
            json={"name": repos[0]["name"], "repository_url": YONA_URL_B},
        )
        assert response.status_code == 200
        body = response.json()
        assert body["yona_username"] is None
        assert body["repository_url"] == CANONICAL
        mock_validate.assert_not_called()
        mock_origin.assert_not_called()
        mock_clone.assert_not_called()

    commits_after = client.get(
        f"/api/equipment/{equipment_id}/git/commits"
    ).json()["total"]
    assert commits_after == conn_commits_before


def test_validate_remote_uses_default_username_in_ls_remote(
    client, monkeypatch, device_a_paths
):
    monkeypatch.setattr("app.core.config.YONA_DEFAULT_USERNAME", "source_trace")
    captured: dict = {}

    def fake_run(args, timeout=60):
        captured["args"] = args
        return type("R", (), {"returncode": 0, "stdout": "", "stderr": ""})()

    monkeypatch.setattr("app.services.git_repository_service._run_git_command", fake_run)

    response = client.post(
        "/api/repositories/validate/remote",
        json={"repository_url": YONA_URL_A},
    )
    assert response.status_code == 200
    assert captured["args"][0:2] == ["git", "ls-remote"]
    assert captured["args"][2].startswith("http://source_trace@")
    assert "user_a" not in captured["args"][2]
