# -*- coding: utf-8 -*-
"""Export Cursor agent transcripts as STEP-based conversation archives.

규칙:
- 사용자 Prompt / 어시스턴트 응답을 시각적으로 확실히 구분
- 어시스턴트 응답·완료보고: 요약하지 않음 (원문)
- 진행 과정(도구 호출이 긴 경우)만 요약
- 프로젝트 마무리: STEP 0~10 및 STEP 외 대화를 모두 저장
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from pathlib import Path

TRANSCRIPT_ROOT = Path(
    r"C:\Users\denny\.cursor\projects\c-sourcechangeTrace\agent-transcripts"
)
OUT_DIR = Path(r"c:\sourcechangeTrace\산출물\대화기록")

MAIN_CHAT_ID = "ae5ad5ce-4518-486d-966a-bbcfeee7ba50"
# STEP 10(마지막 단계)에 이어 붙일 후속 대화 — IDE·운영 검증 등
STEP10_EXTRA_CHATS = {
    "05b29092-d53b-45c6-a774-97743fa4ac7e": "IDE·운영 추가 검증 (후속 대화)",
}
MISC_CHATS = {
    "adbdeb12-bf57-4f69-90d6-72c9143a0374": "package.json 구문 오류 문의",
}

STEP_TITLES = {
    0: "프로젝트 기본 실행 환경 구축",
    1: "장비 관리",
    2: "Git 변경 이력 수집",
    3: "Git 변경 이력 조회",
    4: "변경 추적 요청 API 및 Trace 흐름 구축",
    5: "Git 기반 PPT 후보 탐색",
    6: "PPT On-demand 분석 및 Cache",
    7: "Git-PPT 근거 연계",
    8: "Ollama 근거 기반 변경 사유 분석",
    9: "VSCode Continue 연계 및 Extension",
    10: "운영환경 배포 및 단계별 검증",
}

# 메인 대화 user turn(1-based) → STEP 경계
STEP_RANGES: list[tuple[int, int, int]] = [
    (0, 1, 1),
    (1, 2, 2),
    (2, 3, 3),
    (3, 4, 4),
    (4, 5, 5),
    (5, 6, 7),
    (6, 8, 47),
    (7, 48, 65),
    (8, 66, 71),
    (9, 72, 119),
    (10, 120, 10_000),
]
SKIP_PROMPT_MARKERS = (
    "You have access to tools through dynamic namespaces",
    "<dynamic_tools>",
    "Start multitasking",
    "Perform any necessary follow-up actions in response to the subagent",
)

USER_QUERY_RE = re.compile(
    r"<timestamp>(.*?)</timestamp>\s*<user_query>\s*(.*?)\s*</user_query>",
    re.DOTALL,
)

# 도구와 함께 나온 짧은 안내는 과정으로만 취급
PROCESS_WITH_TOOLS_MAX = 400


@dataclass
class AssistantChunk:
    text: str
    with_tools: bool
    tools: list[str] = field(default_factory=list)


@dataclass
class Turn:
    chat_id: str
    chat_title: str
    index: int
    timestamp: str
    user_prompt: str
    chunks: list[AssistantChunk] = field(default_factory=list)
    all_tools: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)
    step: int | None = None


def clean_text(text: str) -> str:
    text = text.replace("[REDACTED]", "")
    text = re.sub(r"[ \t]+\n", "\n", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def extract_text_parts(content) -> tuple[list[str], list[str]]:
    texts: list[str] = []
    tools: list[str] = []
    if content is None:
        return texts, tools
    if isinstance(content, str):
        cleaned = clean_text(content)
        if cleaned:
            texts.append(cleaned)
        return texts, tools
    if not isinstance(content, list):
        return texts, tools
    for item in content:
        if not isinstance(item, dict):
            continue
        t = item.get("type")
        if t == "text":
            cleaned = clean_text(item.get("text") or "")
            if cleaned:
                texts.append(cleaned)
        elif t == "tool_use":
            tools.append(item.get("name") or "tool")
    return texts, tools


def parse_user_message(text: str) -> tuple[str, str]:
    m = USER_QUERY_RE.search(text)
    if m:
        return m.group(1).strip(), m.group(2).strip()
    cleaned = re.sub(r"</?timestamp>.*?</timestamp>", "", text, flags=re.DOTALL)
    cleaned = re.sub(r"</?user_query>", "", cleaned)
    return "", cleaned.strip()


def load_turns_from_jsonl(path: Path, chat_id: str, chat_title: str) -> list[Turn]:
    turns: list[Turn] = []
    current: Turn | None = None

    def close_current() -> None:
        nonlocal current
        if current is not None:
            turns.append(current)
            current = None

    with path.open(encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
            except json.JSONDecodeError:
                continue

            role = obj.get("role")
            if role == "turn_ended":
                status = obj.get("status")
                err = obj.get("error")
                if current is not None and (status or err):
                    current.errors.append(f"{status or ''}: {err or ''}".strip(": "))
                continue

            msg = obj.get("message") or {}
            texts, tools = extract_text_parts(msg.get("content"))

            if role == "user":
                close_current()
                raw = "\n".join(texts)
                ts, prompt = parse_user_message(raw)
                current = Turn(
                    chat_id=chat_id,
                    chat_title=chat_title,
                    index=len(turns) + 1,
                    timestamp=ts or "(시각 없음)",
                    user_prompt=prompt or raw.strip(),
                )
                continue

            if role == "assistant" and current is not None:
                current.all_tools.extend(tools)
                joined = "\n\n".join(texts).strip()
                if joined:
                    current.chunks.append(
                        AssistantChunk(
                            text=joined,
                            with_tools=bool(tools),
                            tools=list(tools),
                        )
                    )
                elif tools:
                    # tool-only message: track tools only
                    pass

    close_current()
    return turns


def split_response_and_process(
    turn: Turn,
) -> tuple[list[str], list[str], str]:
    """Return (response_texts_full, process_narrations, tool_summary)."""
    responses: list[str] = []
    process_notes: list[str] = []

    for chunk in turn.chunks:
        # 도구와 함께 나온 짧은 안내는 과정 요약용
        if chunk.with_tools and len(chunk.text) <= PROCESS_WITH_TOOLS_MAX:
            one = re.sub(r"\s+", " ", chunk.text.replace("\n", " ")).strip()
            if one and one not in process_notes:
                process_notes.append(one)
            continue
        # 그 외(도구 없는 응답, 긴 안내, 완료보고)는 전부 원문 응답
        responses.append(chunk.text)

    tool_summary = ""
    if turn.all_tools:
        seen: set[str] = set()
        uniq: list[str] = []
        for n in turn.all_tools:
            if n not in seen:
                seen.add(n)
                uniq.append(n)
        counts = {n: turn.all_tools.count(n) for n in uniq}
        desc = ", ".join(
            f"{n}×{counts[n]}" if counts[n] > 1 else n for n in uniq[:30]
        )
        if len(uniq) > 30:
            desc += f" 외 {len(uniq) - 30}개"
        tool_summary = f"사용 도구: {desc} (총 {len(turn.all_tools)}회)"

    return responses, process_notes[:8], tool_summary


def should_skip_prompt(prompt: str) -> bool:
    return any(marker in prompt for marker in SKIP_PROMPT_MARKERS)


def assign_main_steps(turns: list[Turn]) -> tuple[list[Turn], int]:
    saved: list[Turn] = []
    excluded = 0
    for turn in turns:
        if should_skip_prompt(turn.user_prompt):
            excluded += 1
            continue
        if not turn.user_prompt.strip():
            excluded += 1
            continue
        step = None
        for s, start, end in STEP_RANGES:
            if start <= turn.index <= end:
                step = s
                break
        if step is None:
            excluded += 1
            continue
        turn.step = step
        saved.append(turn)
    return saved, excluded


def render_turn(global_idx: int, turn: Turn) -> str:
    responses, process_notes, tool_summary = split_response_and_process(turn)
    step_label = (
        f"STEP {turn.step} — {STEP_TITLES.get(turn.step, '')}"
        if turn.step is not None
        else "기타"
    )

    lines: list[str] = []
    lines.append("=" * 80)
    lines.append(f"Turn {global_idx}  |  {step_label}")
    lines.append(f"시각: {turn.timestamp}")
    lines.append(f"대화: {turn.chat_title}  |  transcript 내 #{turn.index}")
    lines.append("=" * 80)
    lines.append("")

    # ---- USER ----
    lines.append("█" * 80)
    lines.append("█  [사용자 Prompt]  — 원문 (요약 없음)")
    lines.append("█" * 80)
    lines.append("")
    lines.append("```text")
    lines.append(turn.user_prompt)
    lines.append("```")
    lines.append("")

    # ---- ASSISTANT RESPONSE ----
    lines.append("█" * 80)
    lines.append("█  [어시스턴트 응답]  — 원문 (완료보고·답변 요약 없음)")
    lines.append("█" * 80)
    lines.append("")
    if responses:
        for i, text in enumerate(responses, 1):
            if len(responses) > 1:
                lines.append(f"----- 응답 메시지 {i}/{len(responses)} -----")
                lines.append("")
            lines.append(text)
            lines.append("")
    else:
        lines.append("(이 턴에서 도구 없는 최종 응답 텍스트가 transcript에 없음)")
        lines.append("")

    # ---- PROCESS ----
    lines.append("░" * 80)
    lines.append("░  [진행 과정 요약]  — 도구 호출·짧은 중간 안내만 요약")
    lines.append("░" * 80)
    lines.append("")
    if process_notes:
        for note in process_notes:
            lines.append(f"- {note}")
        lines.append("")
    if tool_summary:
        lines.append(tool_summary)
        lines.append("")
    if not process_notes and not tool_summary:
        lines.append("(도구 호출 없음)")
        lines.append("")
    if turn.errors:
        lines.append(f"- 턴 종료 상태: {'; '.join(turn.errors)}")
        lines.append("")

    lines.append("")
    return "\n".join(lines)


def write_step_file(step: int, turns: list[Turn], global_start: int) -> tuple[list[tuple[str, Path, int, int]], int]:
    title = STEP_TITLES[step]
    max_chars = 380_000
    parts: list[list[Turn]] = []
    current: list[Turn] = []
    size = 0
    for turn in turns:
        est = len(turn.user_prompt) + sum(len(c.text) for c in turn.chunks) + 1200
        if current and size + est > max_chars:
            parts.append(current)
            current = []
            size = 0
        current.append(turn)
        size += est
    if current:
        parts.append(current)

    written: list[tuple[str, Path, int, int]] = []
    idx = global_start
    total_parts = len(parts)
    for part_i, part_turns in enumerate(parts, 1):
        suffix = f"_Part{part_i:02d}" if total_parts > 1 else ""
        fname = f"STEP_{step:02d}_{_safe_name(title)}{suffix}.md"
        out = OUT_DIR / fname
        start_t = part_turns[0].index
        end_t = part_turns[-1].index
        heading = f"# STEP {step}. {title}"
        if total_parts > 1:
            heading += f" (Part {part_i}/{total_parts})"
        # 메인 대화 index와 후속 대화 index가 섞일 수 있음 → 출처별로 표기
        main_idxs = [t.index for t in part_turns if "후속" not in (t.chat_title or "")]
        extra_n = sum(1 for t in part_turns if "후속" in (t.chat_title or ""))
        range_note = f"- 포함 transcript turn: #{start_t} ~ #{end_t}"
        if main_idxs:
            range_note = (
                f"- 메인 대화 turn 범위(해당 Part 내): "
                f"#{min(main_idxs)} ~ #{max(main_idxs)}"
            )
        body: list[str] = [
            heading,
            "",
            range_note,
            f"- 포함 turn 수: {len(part_turns)}"
            + (f" (그중 IDE·운영 후속 {extra_n})" if extra_n else ""),
            "",
            "## 읽는 방법",
            "",
            "- `█ [사용자 Prompt]` : 사용자 입력 원문",
            "- `█ [어시스턴트 응답]` : 답변·완료보고 원문 (요약하지 않음)",
            "- `░ [진행 과정 요약]` : 긴 도구 호출 과정만 요약",
            "",
            "---",
            "",
        ]
        for turn in part_turns:
            body.append(render_turn(idx, turn))
            idx += 1
        out.write_text("\n".join(body), encoding="utf-8")
        written.append((f"STEP {step}", out, start_t, end_t))
    return written, idx


def write_misc_file(turns: list[Turn], global_start: int) -> tuple[Path | None, int]:
    if not turns:
        return None, global_start
    out = OUT_DIR / "기타_STEP외_대화.md"
    body: list[str] = [
        "# 기타 (STEP 외 대화)",
        "",
        "메인 STEP 진행과 별도로 발생한 짧은 대화입니다.",
        "",
        "- `█ [사용자 Prompt]` / `█ [어시스턴트 응답]` / `░ [진행 과정 요약]`",
        "",
        "---",
        "",
    ]
    idx = global_start
    for turn in turns:
        turn.step = None
        body.append(render_turn(idx, turn))
        idx += 1
    out.write_text("\n".join(body), encoding="utf-8")
    return out, idx


def _safe_name(title: str) -> str:
    name = re.sub(r'[\\/:*?"<>|]', "", title)
    name = re.sub(r"\s+", "_", name.strip())
    return name[:60]


def clear_old_archives() -> list[str]:
    removed: list[str] = []
    if not OUT_DIR.exists():
        return removed
    for p in OUT_DIR.iterdir():
        if not p.is_file():
            continue
        name = p.name
        if (
            name.startswith("대화기록_Part")
            or name.startswith("STEP_")
            or name.startswith("기타_")
            or name == "00_인덱스.md"
        ):
            p.unlink()
            removed.append(name)
    return removed


def main() -> None:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    removed = clear_old_archives()

    main_path = TRANSCRIPT_ROOT / MAIN_CHAT_ID / f"{MAIN_CHAT_ID}.jsonl"
    main_turns = load_turns_from_jsonl(
        main_path, MAIN_CHAT_ID, "메인 개발 대화 (STEP 0~)"
    )
    saved_main, excluded = assign_main_steps(main_turns)

    by_step: dict[int, list[Turn]] = {s: [] for s, _, _ in STEP_RANGES}
    for t in saved_main:
        assert t.step is not None
        by_step[t.step].append(t)

    # IDE·운영 후속 대화 → STEP 10 말미에 추가
    step10_extra_saved = 0
    step10_extra_excluded = 0
    for chat_id, title in STEP10_EXTRA_CHATS.items():
        path = TRANSCRIPT_ROOT / chat_id / f"{chat_id}.jsonl"
        if not path.exists():
            continue
        for turn in load_turns_from_jsonl(path, chat_id, title):
            if should_skip_prompt(turn.user_prompt) or not turn.user_prompt.strip():
                step10_extra_excluded += 1
                continue
            turn.step = 10
            by_step[10].append(turn)
            step10_extra_saved += 1

    written: list[tuple[str, Path, int, int]] = []
    global_idx = 1
    for step, _, _ in STEP_RANGES:
        turns = by_step[step]
        if not turns:
            continue
        extra, global_idx = write_step_file(step, turns, global_idx)
        written.extend(extra)

    misc_turns: list[Turn] = []
    for chat_id, title in MISC_CHATS.items():
        path = TRANSCRIPT_ROOT / chat_id / f"{chat_id}.jsonl"
        if path.exists():
            for turn in load_turns_from_jsonl(path, chat_id, title):
                if should_skip_prompt(turn.user_prompt) or not turn.user_prompt.strip():
                    continue
                misc_turns.append(turn)
    misc_path, global_idx = write_misc_file(misc_turns, global_idx)
    if misc_path:
        written.append(("기타", misc_path, 0, 0))

    # quality check: STEP 0 response must include full report, not only next-step line
    step0 = by_step[0][0] if by_step[0] else None
    if step0:
        responses, _, _ = split_response_and_process(step0)
        joined = "\n".join(responses)
        assert "STEP 0 완료 보고" in joined, "STEP 0 완료보고 누락"
        assert len(joined) > 1500, f"STEP 0 응답이 너무 짧음: {len(joined)}"

    index_lines = [
        "# sourcechangeTrace 대화 Prompt 아카이브 (STEP별)",
        "",
        "메인 개발 대화를 **STEP 단위**로 나눠 저장한 기록입니다.",
        "",
        "## 구분 표시",
        "",
        "| 표시 | 의미 | 요약 여부 |",
        "|------|------|-----------|",
        "| `█ [사용자 Prompt]` | 사용자 입력 | **원문 (요약 없음)** |",
        "| `█ [어시스턴트 응답]` | 답변·완료보고 | **원문 (요약 없음)** |",
        "| `░ [진행 과정 요약]` | 도구 호출·짧은 중간 안내 | 요약 |",
        "",
        "## 저장 규칙",
        "",
        "- 사용자 Prompt와 어시스턴트 응답은 블록 헤더로 확실히 구분",
        "- 완료보고·최종 답변은 길어도 원문 유지",
        "- 도구 호출이 긴 진행 과정만 요약",
        "- STEP 0~10 및 STEP 외 대화를 모두 저장 (프로젝트 마무리)",
        "- 재생성: `python scripts/export_conversation_archive.py`",
        "",
        "## STEP 경계 (메인 대화 turn 기준)",
        "",
        "| STEP | 제목 | 메인 turn 범위 |",
        "|------|------|----------------|",
    ]
    last_by_step: dict[int, int] = {}
    for t in saved_main:
        if t.step is not None:
            last_by_step[t.step] = t.index
    for step, start, end in STEP_RANGES:
        actual_end = last_by_step.get(step, end)
        index_lines.append(
            f"| {step} | {STEP_TITLES[step]} | #{start} ~ #{actual_end} |"
        )
    index_lines.extend(
        [
            "",
            "## 포함 / 제외",
            "",
            f"- 메인 대화 전체 user turn: **{len(main_turns)}**",
            f"- 저장(메인 → STEP 0~10): **{len(saved_main)}**",
            f"- STEP 10 후속(IDE·운영) 추가: **{step10_extra_saved}** "
            f"(제외 {step10_extra_excluded})",
            f"- 제외(시스템 주입 등, 메인): **{excluded}**",
            f"- 기타 대화: **{len(misc_turns)}**",
            "",
            "## 파일 목록",
            "",
        ]
    )
    for label, path, start, end in written:
        size = path.stat().st_size
        if label == "기타":
            index_lines.append(f"- [{path.name}]({path.name}) — {size:,} bytes")
        else:
            index_lines.append(
                f"- [{path.name}]({path.name}) — 메인 turn #{start}~#{end}, "
                f"{size:,} bytes"
            )
    index_lines.extend(
        [
            "",
            "## 상태",
            "",
            "- 프로젝트 마무리: STEP 0~10 대화기록 저장 완료",
            "- STEP 9: Continue 연동 + VS Code Extension(9-2) + lifecycle 보완 (turn #72~#119)",
            "- STEP 10: 운영 배포·검증 + Eclipse/Visual Studio Adapter + 최종 제출 패키지 "
            "(메인 turn #120~) + IDE·운영 후속 대화 추가",
            "",
        ]
    )
    if removed:
        index_lines.append("## 이번 재생성에서 삭제한 이전 파일")
        index_lines.append("")
        for name in removed:
            index_lines.append(f"- `{name}`")
        index_lines.append("")

    index_path = OUT_DIR / "00_인덱스.md"
    index_path.write_text("\n".join(index_lines), encoding="utf-8")

    print(f"OUT_DIR={OUT_DIR}")
    print(f"saved_main={len(saved_main)} excluded={excluded}")
    for label, path, start, end in written:
        # response length check for early steps
        text = path.read_text(encoding="utf-8")
        resp_marker = text.count("[어시스턴트 응답]")
        user_marker = text.count("[사용자 Prompt]")
        print(
            f"  {path.name}: {path.stat().st_size:,} bytes "
            f"user_blocks={user_marker} asst_blocks={resp_marker}"
        )


if __name__ == "__main__":
    main()
