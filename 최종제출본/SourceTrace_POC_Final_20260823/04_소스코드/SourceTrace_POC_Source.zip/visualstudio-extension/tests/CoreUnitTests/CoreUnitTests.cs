using System;
using System.IO;
using Atec.SourceTrace.Core;

namespace Atec.SourceTrace.Tests;

internal static class CoreUnitTests
{
    private static int _passed;
    private static int _failed;

    public static int Main(string[] args)
    {
        Run("serverUrl_normalize", ServerUrlNormalize);
        Run("repoRelative_posix", RepoRelativePosix);
        Run("repoRelative_reject_outside_root", RepoRelativeRejectOutsideRoot);
        Run("symbol_extract", SymbolExtract);
        Run("symbol_multiline", SymbolMultiline);
        Run("symbol_call_site_not_only_keyword", SymbolCallSite);
        Run("enclosing_function", EnclosingFunction);
        Run("report_request_json", ReportRequestJson);
        Run("report_body_non_empty", ReportBodyNonEmpty);
        Run("report_equipment_id_number", ReportEquipmentIdNumber);
        Run("selection_request_json", SelectionRequestJson);
        Run("selection_body_non_empty", SelectionBodyNonEmpty);
        Run("line_numbers_1based", LineNumbers1Based);
        Run("pick_markdown", PickMarkdown);
        Run("json_escape_korean", JsonEscapeKorean);
        Run("ambiguity_detect", AmbiguityDetect);
        Run("normalize_json_body", NormalizeJsonBody);
        Run("fastapi_422_parser", FastApi422Parser);
        Run("vsct_icon_policy", VsctIconPolicy);
        Run("icon16_is_sixteen", Icon16IsSixteen);
        Run("equipment_name_display_with_id", EquipmentNameDisplayWithId);
        Run("equipment_id_not_browsable_in_options", EquipmentIdNotBrowsable);

        Console.WriteLine();
        Console.WriteLine($"RESULT passed={_passed} failed={_failed}");
        return _failed > 0 ? 1 : 0;
    }

    private static void Run(string name, Action test)
    {
        try
        {
            test();
            _passed++;
            Console.WriteLine("OK  " + name);
        }
        catch (Exception ex)
        {
            _failed++;
            Console.WriteLine("FAIL " + name + " — " + ex.Message);
            Console.WriteLine(ex);
        }
    }

    private static void AssertTrue(bool condition, string message)
    {
        if (!condition)
        {
            throw new InvalidOperationException(message);
        }
    }

    private static void AssertEq<T>(T a, T b)
    {
        if (!Equals(a, b))
        {
            throw new InvalidOperationException($"expected={b} actual={a}");
        }
    }

    private static void ServerUrlNormalize()
    {
        var n = ServerUrlUtil.NormalizeServerUrl("192.168.1.1:8010");
        AssertTrue(n.Ok, n.Error ?? "fail");
        AssertEq(n.Url, "http://192.168.1.1:8010");
        n = ServerUrlUtil.NormalizeServerUrl("http://host:8010/api/trace/report");
        AssertTrue(n.Ok, n.Error ?? "fail");
        AssertEq(n.Url, "http://host:8010");
        n = ServerUrlUtil.NormalizeServerUrl("");
        AssertTrue(!n.Ok, "empty should fail");
    }

    private static void RepoRelativePosix()
    {
        AssertEq(RepoPathResolver.ToRepoRelativePath("D:/workspace/gate", "D:/workspace/gate/src/fare_calc.c"), "src/fare_calc.c");
        AssertEq(RepoPathResolver.ToRepoRelativePath("D:\\workspace\\gate", "D:\\workspace\\gate\\src\\fare_calc.c"), "src/fare_calc.c");
    }

    private static void RepoRelativeRejectOutsideRoot()
    {
        try
        {
            RepoPathResolver.ToRepoRelativePath("D:/workspace/gate", "D:/other/file.c");
            throw new InvalidOperationException("should throw");
        }
        catch (RepoPathResolver.ResolveError)
        {
            // expected
        }
    }

    private static void SymbolExtract()
    {
        AssertEq(SymbolExtractor.ExtractDetectedSymbol("fare_is_xfer"), "fare_is_xfer");
        AssertEq(SymbolExtractor.ExtractDetectedSymbol("static int foo(void) {"), "foo");
        AssertEq(SymbolExtractor.ExtractDetectedSymbol("if"), null);
    }

    private static void SymbolMultiline()
    {
        AssertEq(SymbolExtractor.ExtractDetectedSymbol("int calc_fare(int x)\n{"), "calc_fare");
    }

    private static void SymbolCallSite()
    {
        AssertEq(SymbolExtractor.ExtractDetectedSymbol("result = do_work(arg);"), "do_work");
    }

    private static void EnclosingFunction()
    {
        var lines = new[]
        {
            "int outer(void)",
            "{",
            "  if (x) {",
            "    return 1;",
            "  }",
            "  return 0;",
            "}"
        };
        AssertEq(SymbolExtractor.FindEnclosingFunctionSymbol(lines, 3), "outer");
    }

    private static void ReportRequestJson()
    {
        var built = TraceRequestBuilder.BuildReportRequest(
            3, "선택한 코드가 왜 변경됐는지 알려줘", "src/a.c", "fare_is_xfer", "fare_is_xfer",
            "selection_symbol", false, 4000);
        AssertTrue(built.JsonBody.Contains("\"equipment_id\":3"), built.JsonBody);
        AssertTrue(built.JsonBody.Contains("\"detected_symbol\":\"fare_is_xfer\""), built.JsonBody);
        AssertTrue(built.JsonBody.Contains("\"file_path\":\"src/a.c\""), built.JsonBody);
        AssertTrue(built.JsonBody.Contains("\"use_ollama\":false"), built.JsonBody);
    }

    private static void ReportBodyNonEmpty()
    {
        var built = TraceRequestBuilder.BuildReportRequest(
            1, "q", "src/x.c", "sym", "sym", "cursor_word", false, 4000);
        AssertTrue(!string.IsNullOrWhiteSpace(built.JsonBody), "blank");
        AssertTrue(built.JsonBody.StartsWith("{", StringComparison.Ordinal), built.JsonBody);
        AssertTrue(built.JsonBody.Contains("\"selected_code\""), built.JsonBody);
    }

    private static void ReportEquipmentIdNumber()
    {
        var built = TraceRequestBuilder.BuildReportRequest(
            42, "q", "f.c", "a", "a", "cursor_word", false, 4000);
        AssertTrue(built.JsonBody.Contains("\"equipment_id\":42"), "numeric id");
        AssertTrue(!built.JsonBody.Contains("\"equipment_id\":\"42\""), "must not quote id");
    }

    private static void SelectionRequestJson()
    {
        var built = TraceRequestBuilder.BuildSelectionRequest(
            3, "src/a.c", 12, "D:/w/src/a.c", 10, 12, "x = 1;", "outer", 4000, "HEAD");
        AssertTrue(built.JsonBody.Contains("\"repo_relative_path\":\"src/a.c\""), built.JsonBody);
        AssertTrue(built.JsonBody.Contains("\"start_line\":10"), built.JsonBody);
        AssertTrue(built.JsonBody.Contains("\"end_line\":12"), built.JsonBody);
        AssertTrue(built.JsonBody.Contains("\"repo_id_hint\":12"), built.JsonBody);
        AssertTrue(built.JsonBody.Contains("\"revision\":\"HEAD\""), built.JsonBody);
    }

    private static void SelectionBodyNonEmpty()
    {
        var built = TraceRequestBuilder.BuildSelectionRequest(
            1, "src/a.c", null, null, 1, 1, "int x;", null, 4000, "HEAD");
        AssertTrue(built.JsonBody.Contains("\"equipment_id\":1"), built.JsonBody);
        AssertTrue(built.JsonBody.Contains("\"selected_code\""), built.JsonBody);
    }

    private static void LineNumbers1Based()
    {
        const int start0 = 9;
        const int end0 = 11;
        AssertEq(start0 + 1, 10);
        AssertEq(end0 + 1, 12);
    }

    private static void PickMarkdown()
    {
        const string json = "{\"content\":\"# hello\",\"answer\":\"ignored\"}";
        AssertEq(TraceRequestBuilder.PickResultMarkdown(json), "# hello");
    }

    private static void JsonEscapeKorean()
    {
        var q = JsonUtil.Quote("한글\n테스트");
        AssertTrue(q.Contains("한글"), q);
        AssertTrue(q.Contains("\\n"), q);
    }

    private static void AmbiguityDetect()
    {
        AssertTrue(TraceRequestBuilder.LooksLikeAmbiguity(
            "동일한 파일 경로가 여러 장비 Repository에서 확인되어 하나를 결정할 수 없습니다"), "detect");
    }

    private static void NormalizeJsonBody()
    {
        AssertEq(TraceHttpClient.NormalizeJsonBody(null), "{}");
        AssertEq(TraceHttpClient.NormalizeJsonBody("  "), "{}");
        AssertEq(TraceHttpClient.NormalizeJsonBody("{\"a\":1}"), "{\"a\":1}");
    }

    private static void FastApi422Parser()
    {
        const string body = "{\"detail\":[{\"type\":\"missing\",\"loc\":[\"body\"],\"msg\":\"Field required\",\"input\":null}]}";
        var items = FastApiErrorParser.ParseDetail(body);
        AssertTrue(items.Count > 0, "items");
        AssertEq(items[0].Type, "missing");
        AssertEq(items[0].Loc, "body");
        var msg = FastApiErrorParser.FormatUserMessage("함수 변경 이력 조회", 422, body);
        AssertTrue(msg.Contains("HTTP 422"), msg);
        AssertTrue(msg.Contains("body"), msg);
    }

    private static void VsctIconPolicy()
    {
        var vsct = FindVsctPath();
        var text = File.ReadAllText(vsct);
        AssertTrue(!text.Contains("ExtensionIcon128"), "no large icon in vsct");
        AssertTrue(text.Contains("icon16.png"), "context 16x16");
        AssertTrue(!text.Contains("ToolWindowToolbar"), "no toolbar");
        var mainIdx = text.IndexOf("AtecSubMenuMain", StringComparison.Ordinal);
        AssertTrue(mainIdx > 0, "main menu");
        var mainSection = text.Substring(mainIdx, Math.Min(400, text.Length - mainIdx));
        AssertTrue(mainSection.IndexOf("<Icon", StringComparison.OrdinalIgnoreCase) < 0, "main menu text-only");
    }

    private static void Icon16IsSixteen()
    {
        var png = Path.Combine(FindIconsDir(), "icon16.png");
        AssertTrue(File.Exists(png), "icon16 missing");
        var all = File.ReadAllBytes(png);
        AssertTrue(all.Length > 24, "too small");
        var w = ((all[16] & 0xff) << 24) | ((all[17] & 0xff) << 16) | ((all[18] & 0xff) << 8) | (all[19] & 0xff);
        var h = ((all[20] & 0xff) << 24) | ((all[21] & 0xff) << 16) | ((all[22] & 0xff) << 8) | (all[23] & 0xff);
        AssertEq(w, 16);
        AssertEq(h, 16);
    }

    private static void EquipmentNameDisplayWithId()
    {
        var optionsPath = FindVs2022OptionsPath();
        var text = File.ReadAllText(optionsPath);
        AssertTrue(text.Contains("(ID: "), "EquipmentName must include (ID: n) format");
        AssertTrue(text.Contains("(선택 안 됨)"), "EquipmentName must show not-selected state");
    }

    private static void EquipmentIdNotBrowsable()
    {
        var optionsPath = FindVs2022OptionsPath();
        var text = File.ReadAllText(optionsPath);
        AssertTrue(text.Contains("[Browsable(false)]"), "EquipmentId must be hidden from Options grid");
        AssertTrue(!text.Contains("[DisplayName(\"Equipment ID\")]"), "EquipmentId must not be displayed to user");
    }

    private static string FindVs2022OptionsPath()
    {
        var candidates = new[]
        {
            Path.Combine(AppContext.BaseDirectory, "..", "..", "..", "..", "src", "Atec.SourceTrace.VisualStudio", "Options", "SourceTraceOptionsPage.cs"),
            @"c:\sourcechangeTrace\visualstudio-extension\src\Atec.SourceTrace.VisualStudio\Options\SourceTraceOptionsPage.cs",
        };
        foreach (var c in candidates)
        {
            var p = Path.GetFullPath(c);
            if (File.Exists(p)) return p;
        }
        throw new FileNotFoundException("SourceTraceOptionsPage.cs not found");
    }

    private static string FindVsctPath()
    {
        var candidates = new[]
        {
            Path.Combine(AppContext.BaseDirectory, "..", "..", "..", "..", "src", "Atec.SourceTrace.VisualStudio", "AtecSourceTrace.vsct"),
            @"c:\sourcechangeTrace\visualstudio-extension\src\Atec.SourceTrace.VisualStudio\AtecSourceTrace.vsct",
        };
        foreach (var c in candidates)
        {
            var p = Path.GetFullPath(c);
            if (File.Exists(p))
            {
                return p;
            }
        }

        throw new FileNotFoundException("AtecSourceTrace.vsct not found");
    }

    private static string FindIconsDir()
    {
        var vsct = FindVsctPath();
        return Path.Combine(Path.GetDirectoryName(vsct)!, "Icons");
    }
}
