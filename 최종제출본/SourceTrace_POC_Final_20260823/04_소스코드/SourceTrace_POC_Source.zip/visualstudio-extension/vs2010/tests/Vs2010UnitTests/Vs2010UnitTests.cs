using System;
using System.IO;
using Atec.SourceTrace.Core;

namespace Atec.SourceTrace.Tests
{
    internal static class Vs2010UnitTests
    {
        private static int _passed;
        private static int _failed;

        public static int Main(string[] args)
        {
            Run("serverUrl_normalize", ServerUrlNormalize);
            Run("equipment_id_numeric_json", ReportEquipmentIdNumber);
            Run("report_body_non_empty", ReportBodyNonEmpty);
            Run("report_content_type", ReportContentType);
            Run("selection_body_non_empty", SelectionBodyNonEmpty);
            Run("selection_1based_line", LineNumbers1Based);
            Run("repo_relative_path_normalize", RepoRelativePosix);
            Run("path_traversal_rejected", RepoRelativeRejectOutsideRoot);
            Run("git_root_to_relative_path", GitRootToRelative);
            Run("symbol_extract", SymbolExtract);
            Run("symbol_multiline", SymbolMultiline);
            Run("symbol_call_site_not_only_keyword", SymbolCallSite);
            Run("utf8_korean_json", JsonEscapeKorean);
            Run("fastapi_422_parser", FastApi422Parser);
            Run("pick_response_content", PickMarkdown);
            Run("icon16_is_sixteen", Icon16IsSixteen);
            Run("vsct_no_toolbar", VsctIconPolicy);
            Run("vsct_button_parents_are_groups", VsctButtonParentsAreGroups);
            Run("manifest_vsix10_target_10", ManifestVsix10);
            Run("equipment_name_display_with_id", EquipmentNameDisplayWithId);
            Run("equipment_name_display_no_selection", EquipmentNameDisplayNoSelection);
            Run("equipment_id_not_browsable_in_options", EquipmentIdNotBrowsable);

            Console.WriteLine();
            Console.WriteLine("RESULT passed=" + _passed + " failed=" + _failed);
            return _failed > 0 ? 1 : 0;
        }

        private static void Run(string name, Action test)
        {
            try
            {
                test();
                _passed++;
                Console.WriteLine("OK  " + name);
            }
            catch (Exception ex)
            {
                _failed++;
                Console.WriteLine("FAIL " + name + " — " + ex.Message);
                Console.WriteLine(ex);
            }
        }

        private static void AssertTrue(bool condition, string message)
        {
            if (!condition)
            {
                throw new InvalidOperationException(message);
            }
        }

        private static void AssertEq<T>(T a, T b)
        {
            if (!Equals(a, b))
            {
                throw new InvalidOperationException("expected=" + b + " actual=" + a);
            }
        }

        private static void ServerUrlNormalize()
        {
            var n = ServerUrlUtil.NormalizeServerUrl("192.168.1.1:8010");
            AssertTrue(n.Ok, n.Error ?? "fail");
            AssertEq(n.Url, "http://192.168.1.1:8010");
        }

        private static void RepoRelativePosix()
        {
            AssertEq(RepoPathResolver.ToRepoRelativePath("D:/workspace/gate", "D:/workspace/gate/src/fare_calc.c"), "src/fare_calc.c");
        }

        private static void RepoRelativeRejectOutsideRoot()
        {
            try
            {
                RepoPathResolver.ToRepoRelativePath("D:/workspace/gate", "D:/other/file.c");
                throw new InvalidOperationException("should throw");
            }
            catch (RepoPathResolver.ResolveError)
            {
            }
        }

        private static void GitRootToRelative()
        {
            AssertEq(RepoPathResolver.ToRepoRelativePath("C:/work/gate", "C:/work/gate/src/fare_calc.c"), "src/fare_calc.c");
        }

        private static void SymbolExtract()
        {
            AssertEq(SymbolExtractor.ExtractDetectedSymbol("fare_is_xfer"), "fare_is_xfer");
            AssertEq(SymbolExtractor.ExtractDetectedSymbol("static int foo(void) {"), "foo");
        }

        private static void SymbolMultiline()
        {
            AssertEq(SymbolExtractor.ExtractDetectedSymbol("int calc_fare(int x)\n{"), "calc_fare");
        }

        private static void SymbolCallSite()
        {
            AssertEq(SymbolExtractor.ExtractDetectedSymbol("result = do_work(arg);"), "do_work");
        }

        private static void ReportBodyNonEmpty()
        {
            var built = TraceRequestBuilder.BuildReportRequest(
                1, "q", "src/x.c", "sym", "sym", "cursor_word", false, 4000);
            AssertTrue(built.JsonBody.StartsWith("{", StringComparison.Ordinal), built.JsonBody);
            AssertTrue(built.JsonBody.Contains("\"selected_code\""), built.JsonBody);
        }

        private static void ReportEquipmentIdNumber()
        {
            var built = TraceRequestBuilder.BuildReportRequest(
                42, "q", "f.c", "a", "a", "cursor_word", false, 4000);
            AssertTrue(built.JsonBody.Contains("\"equipment_id\":42"), "numeric id");
            AssertTrue(!built.JsonBody.Contains("\"equipment_id\":\"42\""), "must not quote id");
        }

        private static void ReportContentType()
        {
            var httpPath = Path.Combine(FindExtRoot(), "src", "Atec.SourceTrace.Core", "TraceHttpClient.cs");
            var text = File.ReadAllText(httpPath);
            AssertTrue(text.Contains("application/json; charset=utf-8"), "json charset");
            AssertTrue(text.Contains("ContentLength"), "fixed length POST");
        }

        private static void SelectionBodyNonEmpty()
        {
            var built = TraceRequestBuilder.BuildSelectionRequest(
                1, "src/a.c", null, null, 1, 1, "int x;", null, 4000, "HEAD");
            AssertTrue(built.JsonBody.Contains("\"start_line\":1"), built.JsonBody);
            AssertTrue(built.JsonBody.Contains("\"end_line\":1"), built.JsonBody);
        }

        private static void LineNumbers1Based()
        {
            var built = TraceRequestBuilder.BuildSelectionRequest(
                3, "src/a.c", null, null, 10, 12, "x", "outer", 4000, "HEAD");
            AssertTrue(built.JsonBody.Contains("\"start_line\":10"), built.JsonBody);
            AssertTrue(built.JsonBody.Contains("\"end_line\":12"), built.JsonBody);
        }

        private static void PickMarkdown()
        {
            AssertEq(TraceRequestBuilder.PickResultMarkdown("{\"content\":\"# hello\",\"answer\":\"ignored\"}"), "# hello");
        }

        private static void JsonEscapeKorean()
        {
            var q = JsonUtil.Quote("한글\n테스트");
            AssertTrue(q.Contains("한글"), q);
        }

        private static void FastApi422Parser()
        {
            const string body = "{\"detail\":[{\"type\":\"missing\",\"loc\":[\"body\"],\"msg\":\"Field required\",\"input\":null}]}";
            var msg = FastApiErrorParser.FormatUserMessage("함수 변경 이력 조회", 422, body);
            AssertTrue(msg.Contains("HTTP 422"), msg);
            AssertTrue(msg.Contains("body"), msg);
        }

        private static void VsctIconPolicy()
        {
            var text = File.ReadAllText(Path.Combine(FindVs2010ProjectDir(), "AtecSourceTrace.vsct"));
            AssertTrue(!text.Contains("ExtensionIcon128"), "no large icon in vsct");
            AssertTrue(text.Contains("icon16.png"), "context 16x16");
            AssertTrue(!text.Contains("ToolWindowToolbar"), "no toolbar");
            AssertTrue(text.Contains("IDM_VS_MENU_TOOLS"), "Tools root");
            var mainIdx = text.IndexOf("<Menu guid=\"guidAtecSourceTraceCmdSet\" id=\"AtecSubMenuMain\"", StringComparison.Ordinal);
            AssertTrue(mainIdx > 0, "main menu element");
            var mainEnd = text.IndexOf("</Menu>", mainIdx, StringComparison.Ordinal);
            AssertTrue(mainEnd > mainIdx, "main menu close");
            var mainSection = text.Substring(mainIdx, mainEnd - mainIdx);
            AssertTrue(mainSection.IndexOf("<Icon", StringComparison.OrdinalIgnoreCase) < 0, "main menu text-only");
        }

        private static void VsctButtonParentsAreGroups()
        {
            var text = File.ReadAllText(Path.Combine(FindVs2010ProjectDir(), "AtecSourceTrace.vsct"));
            AssertTrue(text.Contains("id=\"AtecSubMenuGroup\""), "context submenu group");
            AssertTrue(text.Contains("id=\"AtecSubMenuMainGroup\""), "tools submenu group");
            AssertTrue(!text.Contains("IDG_VS_MM_TOOLSADDINS"), "must not use Tools ADDINS group");

            var groupIds = new System.Collections.Generic.HashSet<string>(StringComparer.Ordinal);
            var idx = 0;
            while (true)
            {
                var g = text.IndexOf("<Group ", idx, StringComparison.Ordinal);
                if (g < 0) break;
                var end = text.IndexOf(">", g, StringComparison.Ordinal);
                groupIds.Add(ExtractAttr(text.Substring(g, end - g + 1), "id"));
                idx = end + 1;
            }

            var menuIds = new System.Collections.Generic.HashSet<string>(StringComparer.Ordinal);
            idx = 0;
            while (true)
            {
                var m = text.IndexOf("<Menu ", idx, StringComparison.Ordinal);
                if (m < 0) break;
                var end = text.IndexOf(">", m, StringComparison.Ordinal);
                menuIds.Add(ExtractAttr(text.Substring(m, end - m + 1), "id"));
                idx = end + 1;
            }

            var buttonCount = 0;
            idx = 0;
            while (true)
            {
                var b = text.IndexOf("<Button ", idx, StringComparison.Ordinal);
                if (b < 0) break;
                var close = text.IndexOf("</Button>", b, StringComparison.Ordinal);
                var block = text.Substring(b, close - b);
                var p = block.IndexOf("<Parent ", StringComparison.Ordinal);
                var pe = block.IndexOf("/>", p, StringComparison.Ordinal);
                var parentId = ExtractAttr(block.Substring(p, pe - p + 2), "id");
                AssertTrue(groupIds.Contains(parentId), "Button parent must be Group: " + parentId);
                AssertTrue(!menuIds.Contains(parentId), "Button must not parent Menu: " + parentId);
                buttonCount++;
                idx = close + 1;
            }

            AssertTrue(buttonCount >= 6, "button count");
            var pkgdef = File.ReadAllText(Path.Combine(FindVs2010ProjectDir(), "Atec.SourceTrace.VisualStudio2010.pkgdef"));
            AssertTrue(pkgdef.Contains("Menus.ctmenu, 2"), "pkgdef menu version 2");
            var pkg = File.ReadAllText(Path.Combine(FindVs2010ProjectDir(), "AtecSourceTracePackage.cs"));
            AssertTrue(pkg.Contains("ProvideMenuResource(\"Menus.ctmenu\", 2)"), "ProvideMenuResource version 2");
        }

        private static string ExtractAttr(string tag, string name)
        {
            var key = " " + name + "=\"";
            var i = tag.IndexOf(key, StringComparison.Ordinal);
            if (i < 0) return null;
            i += key.Length;
            var j = tag.IndexOf('"', i);
            return j < 0 ? null : tag.Substring(i, j - i);
        }

        private static void Icon16IsSixteen()
        {
            var png = Path.Combine(FindVs2010ProjectDir(), "Icons", "icon16.png");
            var all = File.ReadAllBytes(png);
            var w = ((all[16] & 0xff) << 24) | ((all[17] & 0xff) << 16) | ((all[18] & 0xff) << 8) | (all[19] & 0xff);
            var h = ((all[20] & 0xff) << 24) | ((all[21] & 0xff) << 16) | ((all[22] & 0xff) << 8) | (all[23] & 0xff);
            AssertEq(w, 16);
            AssertEq(h, 16);
        }

        private static void ManifestVsix10()
        {
            var text = File.ReadAllText(Path.Combine(FindVs2010ProjectDir(), "source.extension.vsixmanifest"));
            AssertTrue(text.Contains("Version=\"1.0.0\""), "VSIX 1.0");
            AssertTrue(text.Contains("Version=\"10.0\""), "VS2010");
            AssertTrue(!text.Contains("PackageManifest"), "must not use VSIX 2.0 PackageManifest");
            AssertTrue(!text.Contains("amd64"), "no amd64");
            AssertTrue(text.Contains("Atec.SourceTrace.VisualStudio2010.d0c19e45"), "distinct identity");
            AssertTrue(!text.Contains("7c8f3a21"), "must not reuse VS2022 identity");
            AssertTrue(!text.Contains("e4b17c90"), "must not reuse VS2017 identity");
        }

        private static void EquipmentNameDisplayWithId()
        {
            var text = File.ReadAllText(Path.Combine(FindVs2010ProjectDir(), "Options", "SourceTraceOptionsPage.cs"));
            AssertTrue(text.Contains("(ID: "), "EquipmentName must include (ID: n) format");
            AssertTrue(text.Contains("(선택 안 됨)"), "EquipmentName must show not-selected state");
        }

        private static void EquipmentNameDisplayNoSelection()
        {
            var text = File.ReadAllText(Path.Combine(FindVs2010ProjectDir(), "Options", "SourceTraceOptionsPage.cs"));
            AssertTrue(!text.Contains("[DisplayName(\"Equipment ID\")]"), "EquipmentId must not be displayed to user");
        }

        private static void EquipmentIdNotBrowsable()
        {
            var text = File.ReadAllText(Path.Combine(FindVs2010ProjectDir(), "Options", "SourceTraceOptionsPage.cs"));
            AssertTrue(text.Contains("[Browsable(false)]"), "EquipmentId must be hidden from Options grid");
        }

        private static string FindExtRoot()
        {
            return Path.GetFullPath(Path.Combine(FindVs2010ProjectDir(), "..", "..", ".."));
        }

        private static string FindVs2010ProjectDir()
        {
            var candidates = new[]
            {
                Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "..", "..", "..", "..", "src", "Atec.SourceTrace.VisualStudio2010"),
                @"c:\sourcechangeTrace\visualstudio-extension\vs2010\src\Atec.SourceTrace.VisualStudio2010",
            };
            foreach (var c in candidates)
            {
                var p = Path.GetFullPath(c);
                if (File.Exists(Path.Combine(p, "AtecSourceTrace.vsct")))
                {
                    return p;
                }
            }

            throw new FileNotFoundException("VS2010 project dir not found");
        }
    }
}
