using System;
using System.IO;
using Atec.SourceTrace.Core;

namespace Atec.SourceTrace.Tests
{
    internal static class Vs2017UnitTests
    {
        private static int _passed;
        private static int _failed;

        public static int Main(string[] args)
        {
            Run("serverUrl_normalize", ServerUrlNormalize);
            Run("equipment_id_numeric_json", ReportEquipmentIdNumber);
            Run("report_body_non_empty", ReportBodyNonEmpty);
            Run("report_content_type", ReportContentType);
            Run("selection_body_non_empty", SelectionBodyNonEmpty);
            Run("selection_1based_line", LineNumbers1Based);
            Run("repo_relative_path_normalize", RepoRelativePosix);
            Run("path_traversal_rejected", RepoRelativeRejectOutsideRoot);
            Run("git_root_to_relative_path", GitRootToRelative);
            Run("symbol_extract", SymbolExtract);
            Run("symbol_multiline", SymbolMultiline);
            Run("symbol_call_site_not_only_keyword", SymbolCallSite);
            Run("enclosing_function", EnclosingFunction);
            Run("utf8_korean_json", JsonEscapeKorean);
            Run("fastapi_422_parser", FastApi422Parser);
            Run("pick_response_content", PickMarkdown);
            Run("icon16_is_sixteen", Icon16IsSixteen);
            Run("vsct_no_toolbar", VsctIconPolicy);
            Run("vsct_button_parents_are_groups", VsctButtonParentsAreGroups);
            Run("manifest_installationtarget_15x", ManifestTarget15);
            Run("equipment_name_display_with_id", EquipmentNameDisplayWithId);
            Run("equipment_id_not_browsable_in_options", EquipmentIdNotBrowsable);

            Console.WriteLine();
            Console.WriteLine("RESULT passed=" + _passed + " failed=" + _failed);
            return _failed > 0 ? 1 : 0;
        }

        private static void Run(string name, Action test)
        {
            try
            {
                test();
                _passed++;
                Console.WriteLine("OK  " + name);
            }
            catch (Exception ex)
            {
                _failed++;
                Console.WriteLine("FAIL " + name + " — " + ex.Message);
                Console.WriteLine(ex);
            }
        }

        private static void AssertTrue(bool condition, string message)
        {
            if (!condition)
            {
                throw new InvalidOperationException(message);
            }
        }

        private static void AssertEq<T>(T a, T b)
        {
            if (!Equals(a, b))
            {
                throw new InvalidOperationException("expected=" + b + " actual=" + a);
            }
        }

        private static void ServerUrlNormalize()
        {
            var n = ServerUrlUtil.NormalizeServerUrl("192.168.1.1:8010");
            AssertTrue(n.Ok, n.Error ?? "fail");
            AssertEq(n.Url, "http://192.168.1.1:8010");
            n = ServerUrlUtil.NormalizeServerUrl("http://host:8010/api/trace/report");
            AssertTrue(n.Ok, n.Error ?? "fail");
            AssertEq(n.Url, "http://host:8010");
            n = ServerUrlUtil.NormalizeServerUrl("");
            AssertTrue(!n.Ok, "empty should fail");
        }

        private static void RepoRelativePosix()
        {
            AssertEq(RepoPathResolver.ToRepoRelativePath("D:/workspace/gate", "D:/workspace/gate/src/fare_calc.c"), "src/fare_calc.c");
            AssertEq(RepoPathResolver.ToRepoRelativePath("D:\\workspace\\gate", "D:\\workspace\\gate\\src\\fare_calc.c"), "src/fare_calc.c");
        }

        private static void RepoRelativeRejectOutsideRoot()
        {
            try
            {
                RepoPathResolver.ToRepoRelativePath("D:/workspace/gate", "D:/other/file.c");
                throw new InvalidOperationException("should throw");
            }
            catch (RepoPathResolver.ResolveError)
            {
            }
        }

        private static void GitRootToRelative()
        {
            var rel = RepoPathResolver.ToRepoRelativePath("C:/work/gate", "C:/work/gate/src/fare_calc.c");
            AssertEq(rel, "src/fare_calc.c");
            AssertTrue(rel.IndexOf('\\') < 0, "posix separator");
            AssertTrue(rel.IndexOf("..", StringComparison.Ordinal) < 0, "no traversal");
        }

        private static void SymbolExtract()
        {
            AssertEq(SymbolExtractor.ExtractDetectedSymbol("fare_is_xfer"), "fare_is_xfer");
            AssertEq(SymbolExtractor.ExtractDetectedSymbol("static int foo(void) {"), "foo");
            AssertEq(SymbolExtractor.ExtractDetectedSymbol("if"), null);
        }

        private static void SymbolMultiline()
        {
            AssertEq(SymbolExtractor.ExtractDetectedSymbol("int calc_fare(int x)\n{"), "calc_fare");
        }

        private static void SymbolCallSite()
        {
            AssertEq(SymbolExtractor.ExtractDetectedSymbol("result = do_work(arg);"), "do_work");
        }

        private static void EnclosingFunction()
        {
            var lines = new[]
            {
                "int outer(void)",
                "{",
                "  if (x) {",
                "    return 1;",
                "  }",
                "  return 0;",
                "}"
            };
            AssertEq(SymbolExtractor.FindEnclosingFunctionSymbol(lines, 3), "outer");
        }

        private static void ReportBodyNonEmpty()
        {
            var built = TraceRequestBuilder.BuildReportRequest(
                1, "q", "src/x.c", "sym", "sym", "cursor_word", false, 4000);
            AssertTrue(!string.IsNullOrWhiteSpace(built.JsonBody), "blank");
            AssertTrue(built.JsonBody.StartsWith("{", StringComparison.Ordinal), built.JsonBody);
            AssertTrue(built.JsonBody.Contains("\"selected_code\""), built.JsonBody);
            AssertTrue(built.JsonBody.Contains("\"query\""), built.JsonBody);
            AssertTrue(built.JsonBody.Contains("\"file_path\""), built.JsonBody);
        }

        private static void ReportEquipmentIdNumber()
        {
            var built = TraceRequestBuilder.BuildReportRequest(
                42, "q", "f.c", "a", "a", "cursor_word", false, 4000);
            AssertTrue(built.JsonBody.Contains("\"equipment_id\":42"), "numeric id");
            AssertTrue(!built.JsonBody.Contains("\"equipment_id\":\"42\""), "must not quote id");
        }

        private static void ReportContentType()
        {
            var httpPath = Path.Combine(FindRepoRoot(), "src", "Atec.SourceTrace.Core", "TraceHttpClient.cs");
            var text = File.ReadAllText(httpPath);
            AssertTrue(text.Contains("application/json; charset=utf-8"), "json charset");
            AssertTrue(text.Contains("Accept = \"application/json\""), "accept json");
            AssertTrue(text.Contains("ContentLength"), "fixed length POST");
        }

        private static void SelectionBodyNonEmpty()
        {
            var built = TraceRequestBuilder.BuildSelectionRequest(
                1, "src/a.c", null, null, 1, 1, "int x;", null, 4000, "HEAD");
            AssertTrue(built.JsonBody.Contains("\"equipment_id\":1"), built.JsonBody);
            AssertTrue(built.JsonBody.Contains("\"selected_code\""), built.JsonBody);
            AssertTrue(built.JsonBody.Contains("\"start_line\":1"), built.JsonBody);
            AssertTrue(built.JsonBody.Contains("\"end_line\":1"), built.JsonBody);
        }

        private static void LineNumbers1Based()
        {
            const int start0 = 9;
            const int end0 = 11;
            AssertEq(start0 + 1, 10);
            AssertEq(end0 + 1, 12);
            var built = TraceRequestBuilder.BuildSelectionRequest(
                3, "src/a.c", null, null, start0 + 1, end0 + 1, "x", "outer", 4000, "HEAD");
            AssertTrue(built.JsonBody.Contains("\"start_line\":10"), built.JsonBody);
            AssertTrue(built.JsonBody.Contains("\"end_line\":12"), built.JsonBody);
        }

        private static void PickMarkdown()
        {
            const string json = "{\"content\":\"# hello\",\"answer\":\"ignored\"}";
            AssertEq(TraceRequestBuilder.PickResultMarkdown(json), "# hello");
        }

        private static void JsonEscapeKorean()
        {
            var q = JsonUtil.Quote("한글\n테스트");
            AssertTrue(q.Contains("한글"), q);
            AssertTrue(q.Contains("\\n"), q);
            var built = TraceRequestBuilder.BuildReportRequest(
                1, "한글 쿼리", "src/가.c", "코드", "fn", "selection", false, 4000);
            AssertTrue(built.JsonBody.Contains("한글"), built.JsonBody);
        }

        private static void FastApi422Parser()
        {
            const string body = "{\"detail\":[{\"type\":\"missing\",\"loc\":[\"body\"],\"msg\":\"Field required\",\"input\":null}]}";
            var items = FastApiErrorParser.ParseDetail(body);
            AssertTrue(items.Count > 0, "items");
            AssertEq(items[0].Type, "missing");
            AssertEq(items[0].Loc, "body");
            var msg = FastApiErrorParser.FormatUserMessage("함수 변경 이력 조회", 422, body);
            AssertTrue(msg.Contains("HTTP 422"), msg);
            AssertTrue(msg.Contains("body"), msg);
            AssertTrue(!msg.StartsWith("{", StringComparison.Ordinal), "must not dump raw json only");
        }

        private static void VsctIconPolicy()
        {
            var vsct = FindVsctPath();
            var text = File.ReadAllText(vsct);
            AssertTrue(!text.Contains("ExtensionIcon128"), "no large icon in vsct");
            AssertTrue(text.Contains("icon16.png"), "context 16x16");
            AssertTrue(!text.Contains("ToolWindowToolbar"), "no toolbar");
            AssertTrue(!text.Contains("IDM_VS_TOOL_MAINMENU"), "no extra toolbar host");
            var mainIdx = text.IndexOf("<Menu guid=\"guidAtecSourceTraceCmdSet\" id=\"AtecSubMenuMain\"", StringComparison.Ordinal);
            AssertTrue(mainIdx > 0, "main menu element");
            var mainEnd = text.IndexOf("</Menu>", mainIdx, StringComparison.Ordinal);
            AssertTrue(mainEnd > mainIdx, "main menu close");
            var mainSection = text.Substring(mainIdx, mainEnd - mainIdx);
            AssertTrue(mainSection.IndexOf("<Icon", StringComparison.OrdinalIgnoreCase) < 0, "main menu text-only");
        }

        /// <summary>
        /// Official VSCT rule: Button/Combo Parent may only be a Group (never a Menu).
        /// </summary>
        private static void VsctButtonParentsAreGroups()
        {
            var text = File.ReadAllText(FindVsctPath());
            AssertTrue(text.Contains("IDM_VS_MENU_TOOLS"), "Tools top parent");
            AssertTrue(text.Contains("id=\"AtecSubMenuGroup\""), "context submenu group");
            AssertTrue(text.Contains("id=\"AtecSubMenuMainGroup\""), "tools submenu group");

            var groupIds = new System.Collections.Generic.HashSet<string>(StringComparer.Ordinal);
            var groupIdx = 0;
            while (true)
            {
                var g = text.IndexOf("<Group ", groupIdx, StringComparison.Ordinal);
                if (g < 0) break;
                var end = text.IndexOf(">", g, StringComparison.Ordinal);
                var tag = text.Substring(g, end - g + 1);
                var id = ExtractAttr(tag, "id");
                AssertTrue(!string.IsNullOrEmpty(id), "group id");
                groupIds.Add(id);
                groupIdx = end + 1;
            }

            var menuIds = new System.Collections.Generic.HashSet<string>(StringComparer.Ordinal);
            var menuIdx = 0;
            while (true)
            {
                var m = text.IndexOf("<Menu ", menuIdx, StringComparison.Ordinal);
                if (m < 0) break;
                var end = text.IndexOf(">", m, StringComparison.Ordinal);
                var tag = text.Substring(m, end - m + 1);
                var id = ExtractAttr(tag, "id");
                AssertTrue(!string.IsNullOrEmpty(id), "menu id");
                menuIds.Add(id);
                menuIdx = end + 1;
            }

            var buttonCount = 0;
            var idx = 0;
            while (true)
            {
                var b = text.IndexOf("<Button ", idx, StringComparison.Ordinal);
                if (b < 0) break;
                var close = text.IndexOf("</Button>", b, StringComparison.Ordinal);
                AssertTrue(close > b, "button close");
                var block = text.Substring(b, close - b);
                var parentLineStart = block.IndexOf("<Parent ", StringComparison.Ordinal);
                AssertTrue(parentLineStart >= 0, "button missing Parent");
                var parentEnd = block.IndexOf("/>", parentLineStart, StringComparison.Ordinal);
                var parentTag = block.Substring(parentLineStart, parentEnd - parentLineStart + 2);
                var parentId = ExtractAttr(parentTag, "id");
                AssertTrue(!string.IsNullOrEmpty(parentId), "button parent id");
                AssertTrue(groupIds.Contains(parentId), "Button parent must be a Group, got: " + parentId);
                AssertTrue(!menuIds.Contains(parentId), "Button must not parent directly to Menu: " + parentId);
                buttonCount++;
                idx = close + 1;
            }

            AssertTrue(buttonCount >= 6, "expected Tools+Context buttons, got " + buttonCount);
            var pkg = File.ReadAllText(Path.Combine(FindVs2017ProjectDir(), "AtecSourceTracePackage.cs"));
            AssertTrue(pkg.Contains("ProvideMenuResource(\"Menus.ctmenu\", 3)"), "ProvideMenuResource version 3");
        }

        private static string ExtractAttr(string tag, string name)
        {
            // Prefer space-prefixed attr so "id=" is not matched inside "guid=".
            var key = " " + name + "=\"";
            var i = tag.IndexOf(key, StringComparison.Ordinal);
            if (i < 0)
            {
                key = name + "=\"";
                if (!tag.TrimStart().StartsWith(key, StringComparison.Ordinal))
                {
                    return null;
                }

                i = tag.IndexOf(key, StringComparison.Ordinal);
            }

            i += key.Length;
            var j = tag.IndexOf('"', i);
            if (j < 0) return null;
            return tag.Substring(i, j - i);
        }

        private static void Icon16IsSixteen()
        {
            var png = Path.Combine(FindIconsDir(), "icon16.png");
            AssertTrue(File.Exists(png), "icon16 missing");
            var all = File.ReadAllBytes(png);
            AssertTrue(all.Length > 24, "too small");
            var w = ((all[16] & 0xff) << 24) | ((all[17] & 0xff) << 16) | ((all[18] & 0xff) << 8) | (all[19] & 0xff);
            var h = ((all[20] & 0xff) << 24) | ((all[21] & 0xff) << 16) | ((all[22] & 0xff) << 8) | (all[23] & 0xff);
            AssertEq(w, 16);
            AssertEq(h, 16);
        }

        private static void ManifestTarget15()
        {
            var manifest = Path.Combine(FindVs2017ProjectDir(), "source.extension.vsixmanifest");
            var text = File.ReadAllText(manifest);
            AssertTrue(text.Contains("Version=\"[15.0,16.0)\""), "15.x range");
            AssertTrue(!text.Contains("17.0"), "must not target 17.x");
            AssertTrue(!text.Contains("amd64"), "no amd64 ProductArchitecture");
            AssertTrue(text.Contains("Atec.SourceTrace.VisualStudio2017.e4b17c90"), "distinct identity");
            AssertTrue(text.Contains("Version=\"0.1.3\""), "official 0.1.3");
            AssertTrue(!text.Contains("DIAGNOSTIC"), "not a diagnostic probe");
            AssertTrue(!text.Contains("7c8f3a21"), "must not reuse VS2022 identity");
        }

        private static void EquipmentNameDisplayWithId()
        {
            var text = File.ReadAllText(Path.Combine(FindVs2017ProjectDir(), "Options", "SourceTraceOptionsPage.cs"));
            AssertTrue(text.Contains("(ID: "), "EquipmentName must include (ID: n) format");
            AssertTrue(text.Contains("(선택 안 됨)"), "EquipmentName must show not-selected state");
        }

        private static void EquipmentIdNotBrowsable()
        {
            var text = File.ReadAllText(Path.Combine(FindVs2017ProjectDir(), "Options", "SourceTraceOptionsPage.cs"));
            AssertTrue(text.Contains("[Browsable(false)]"), "EquipmentId must be hidden from Options grid");
            AssertTrue(!text.Contains("[DisplayName(\"Equipment ID\")]"), "EquipmentId must not be displayed to user");
        }

        private static string FindRepoRoot()
        {
            return Path.GetFullPath(Path.Combine(FindVs2017ProjectDir(), "..", "..", ".."));
        }

        private static string FindVs2017ProjectDir()
        {
            var candidates = new[]
            {
                Path.Combine(AppContext.BaseDirectory, "..", "..", "..", "..", "src", "Atec.SourceTrace.VisualStudio2017"),
                @"c:\sourcechangeTrace\visualstudio-extension\vs2017\src\Atec.SourceTrace.VisualStudio2017",
            };
            foreach (var c in candidates)
            {
                var p = Path.GetFullPath(c);
                if (File.Exists(Path.Combine(p, "AtecSourceTrace.vsct")))
                {
                    return p;
                }
            }

            throw new FileNotFoundException("VS2017 project dir not found");
        }

        private static string FindVsctPath()
        {
            return Path.Combine(FindVs2017ProjectDir(), "AtecSourceTrace.vsct");
        }

        private static string FindIconsDir()
        {
            return Path.Combine(FindVs2017ProjectDir(), "Icons");
        }
    }
}
